import React, { useEffect, useState } from 'react';
import {
  X,
  ExternalLink,
  CheckCircle2,
  Maximize2,
  Minimize2,
  ZoomIn,
  ZoomOut,
  Download,
  Image as ImageIcon
} from 'lucide-react';
import { ProjectItem } from '../data/portfolioData';

interface ProjectLightboxModalProps {
  project: ProjectItem | null;
  onClose: () => void;
}

export const ProjectLightboxModal: React.FC<ProjectLightboxModalProps> = ({ project, onClose }) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isZoomed, setIsZoomed] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (project) {
      window.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [project, onClose]);

  // Reset zoom state on new project selection
  useEffect(() => {
    setIsZoomed(false);
  }, [project?.id]);

  if (!project) return null;

  const handleDownload = () => {
    const a = document.createElement('a');
    a.href = project.image;
    a.download = `${project.title.replace(/\s+/g, '_')}_artwork.jpg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleOpenRaw = () => {
    window.open(project.image, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-slate-950/90 dark:bg-slate-950/90 light-theme:bg-slate-950/85 backdrop-blur-xl overflow-y-auto animate-in fade-in duration-200">
      {/* Background click to close */}
      <div className="fixed inset-0" onClick={onClose} aria-hidden="true" />

      {/* Modal Dialog Card */}
      <div
        className={`relative w-full ${
          isFullscreen ? 'max-w-[98vw] h-[96vh]' : 'max-w-5xl max-h-[92vh]'
        } bg-slate-900/95 light-theme:bg-white/95 border border-cyan-500/30 rounded-3xl shadow-2xl shadow-black/80 overflow-hidden z-10 my-auto flex flex-col transition-all duration-300`}
      >
        
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-slate-800 light-theme:border-slate-200 bg-slate-950/70 light-theme:bg-slate-50 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="text-xs font-semibold uppercase tracking-wider text-cyan-400 bg-cyan-950/80 light-theme:bg-cyan-100 px-2.5 py-1 rounded-lg border border-cyan-800/40 light-theme:border-cyan-300 shrink-0">
              {project.badge || project.category || 'Brand Identity'}
            </span>
            <span className="text-xs sm:text-sm font-semibold text-slate-200 light-theme:text-slate-800 truncate">
              {project.title}
            </span>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
            {/* Zoom Toggle */}
            <button
              onClick={() => setIsZoomed(!isZoomed)}
              className={`p-2 rounded-xl transition-colors cursor-pointer text-xs flex items-center gap-1 ${
                isZoomed
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'text-slate-400 hover:text-white light-theme:hover:text-slate-900 hover:bg-slate-800 light-theme:hover:bg-slate-200'
              }`}
              title={isZoomed ? 'Reset to Fit Screen' : 'View Full 100% Scale'}
            >
              {isZoomed ? <ZoomOut className="w-4 h-4" /> : <ZoomIn className="w-4 h-4" />}
              <span className="hidden md:inline text-[11px]">{isZoomed ? 'Fit Screen' : '100% Zoom'}</span>
            </button>

            {/* Open Raw in New Tab */}
            <button
              onClick={handleOpenRaw}
              className="p-2 rounded-xl text-slate-400 hover:text-white light-theme:hover:text-slate-900 hover:bg-slate-800 light-theme:hover:bg-slate-200 transition-colors cursor-pointer hidden sm:block"
              title="Open full resolution image in new tab"
            >
              <ExternalLink className="w-4 h-4" />
            </button>

            {/* Download Artwork */}
            <button
              onClick={handleDownload}
              className="p-2 rounded-xl text-slate-400 hover:text-white light-theme:hover:text-slate-900 hover:bg-slate-800 light-theme:hover:bg-slate-200 transition-colors cursor-pointer hidden sm:block"
              title="Download high-res artwork"
            >
              <Download className="w-4 h-4" />
            </button>

            {/* Expand Fullscreen */}
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 rounded-xl text-slate-400 hover:text-white light-theme:hover:text-slate-900 hover:bg-slate-800 light-theme:hover:bg-slate-200 transition-colors cursor-pointer"
              title={isFullscreen ? 'Exit Full Screen' : 'Expand Full Screen'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            {/* Close */}
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white light-theme:hover:text-slate-900 hover:bg-slate-800 light-theme:hover:bg-slate-200 transition-colors cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body with Natural Uncropped Artwork Presentation */}
        <div className="overflow-y-auto p-3 sm:p-6 md:p-8 space-y-6 flex-1">
          
          {/* True Natural Aspect-Ratio Image Frame (Uncropped, Full Proportions) */}
          <div
            className={`relative rounded-2xl overflow-hidden border border-slate-800 light-theme:border-slate-200 bg-slate-950 light-theme:bg-slate-100 flex items-center justify-center p-2 sm:p-4 ${
              isZoomed ? 'overflow-auto max-h-[78vh]' : 'min-h-[260px]'
            }`}
          >
            <img
              src={project.image}
              alt={project.title}
              onClick={() => setIsZoomed(!isZoomed)}
              className={`rounded-xl shadow-2xl transition-all duration-200 cursor-pointer ${
                isZoomed
                  ? 'max-h-none max-w-none w-auto cursor-zoom-out'
                  : `${isFullscreen ? 'max-h-[72vh]' : 'max-h-[58vh]'} w-auto max-w-full object-contain cursor-zoom-in`
              }`}
            />

            {/* Interactive Zoom Indicator Pill */}
            <div className="absolute bottom-3 right-3 bg-slate-950/80 light-theme:bg-white/90 backdrop-blur-md px-2.5 py-1 rounded-full text-[11px] font-semibold text-slate-300 light-theme:text-slate-700 border border-slate-700/80 light-theme:border-slate-300 pointer-events-none flex items-center gap-1.5 shadow-md">
              <ImageIcon className="w-3 h-3 text-cyan-400" />
              <span>{isZoomed ? '100% Actual Scale · Tap to Fit' : 'Full Uncropped Aspect · Tap to Zoom'}</span>
            </div>
          </div>

          {/* Project Narrative & Details */}
          <div className="space-y-4">
            <div>
              <h3 className="text-xl sm:text-2xl font-extrabold text-white light-theme:text-slate-900 tracking-tight mb-2">
                {project.title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 light-theme:text-slate-600 leading-relaxed">
                {project.description}
              </p>
            </div>

            {/* Quick Metadata Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-950/60 light-theme:bg-slate-50 border border-slate-800/80 light-theme:border-slate-200">
              <div>
                <span className="text-[11px] text-slate-500 font-medium uppercase block">Classification</span>
                <span className="text-xs sm:text-sm font-semibold text-slate-200 light-theme:text-slate-800">
                  {project.badge || 'Brand Identity'}
                </span>
              </div>
              <div>
                <span className="text-[11px] text-slate-500 font-medium uppercase block">Software &amp; Tools</span>
                <span className="text-xs sm:text-sm font-semibold text-cyan-400 light-theme:text-cyan-600">
                  {project.tags && project.tags.length > 0 ? project.tags.join(', ') : 'Adobe Illustrator & Photoshop'}
                </span>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <span className="text-[11px] text-slate-500 font-medium uppercase block">External Showcase</span>
                {project.link && project.link !== '#' ? (
                  <a
                    href={project.link}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs sm:text-sm font-semibold text-cyan-400 hover:underline inline-flex items-center gap-1"
                  >
                    <span>View Project</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                ) : (
                  <span className="text-xs text-slate-400">Master Brand Portfolio</span>
                )}
              </div>
            </div>

            {/* Tags / Deliverables */}
            {project.tags && project.tags.length > 0 && (
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 light-theme:text-slate-700 mb-2 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Production Deliverables &amp; Formats</span>
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {project.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg bg-slate-950/70 light-theme:bg-slate-100 border border-slate-800 light-theme:border-slate-200 text-xs text-slate-300 light-theme:text-slate-700"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3 border-t border-slate-800 light-theme:border-slate-200 bg-slate-950/70 light-theme:bg-slate-50 shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownload}
              className="sm:hidden flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-cyan-400 bg-slate-900 border border-slate-800"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>
            <span className="text-xs text-slate-500 hidden sm:inline">
              Original full-aspect vector artwork display
            </span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl text-xs font-semibold text-slate-200 light-theme:text-slate-800 bg-slate-800 light-theme:bg-slate-200 hover:bg-slate-700 transition-colors cursor-pointer"
          >
            Close Viewer
          </button>
        </div>

      </div>
    </div>
  );
};
