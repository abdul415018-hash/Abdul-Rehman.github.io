import React from 'react';
import { ArrowUp, Lock } from 'lucide-react';

interface FooterProps {
  branding: {
    name: string;
    initials: string;
  };
  footer: {
    copyrightName: string;
    year: string;
  };
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ branding, footer, onOpenAdmin }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="border-t border-slate-900 light-theme:border-slate-200 bg-[#050914] light-theme:bg-slate-100 py-10 relative transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
          
          {/* Brand mark matching reference */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center font-bold text-xs text-white shadow-md shadow-cyan-500/20">
              {branding.initials || 'AT'}
            </div>
            <span className="font-bold text-sm text-white light-theme:text-slate-900">
              {branding.name}
            </span>
          </div>

          {/* Copyright text */}
          <div className="text-xs text-slate-500 light-theme:text-slate-500 text-center">
            &copy; {footer.year || '2024'} {footer.copyrightName || branding.name}. All rights reserved.
          </div>

          {/* Navigation, Admin Login & Back to Top */}
          <div className="flex items-center gap-4 sm:gap-6">
            <div className="hidden md:flex items-center gap-4 text-xs font-medium text-slate-400 light-theme:text-slate-600">
              <a href="#home" className="hover:text-cyan-400 light-theme:hover:text-cyan-600 transition-colors">Home</a>
              <a href="#about" className="hover:text-cyan-400 light-theme:hover:text-cyan-600 transition-colors">About</a>
              <a href="#projects" className="hover:text-cyan-400 light-theme:hover:text-cyan-600 transition-colors">Projects</a>
              <a href="#contact" className="hover:text-cyan-400 light-theme:hover:text-cyan-600 transition-colors">Contact</a>
            </div>

            {/* Clear Admin Portal Link for Owner */}
            <button
              onClick={onOpenAdmin}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-400 light-theme:text-slate-600 hover:text-cyan-400 light-theme:hover:text-cyan-600 hover:bg-slate-900/80 light-theme:hover:bg-slate-200 border border-slate-800/80 light-theme:border-slate-300 hover:border-cyan-500/40 transition-all cursor-pointer"
              title="Owner Admin Control Panel (Password Protected)"
            >
              <Lock className="w-3.5 h-3.5 text-cyan-400 light-theme:text-cyan-600" />
              <span>Admin Portal</span>
            </button>

            {/* Back to top */}
            <button
              onClick={scrollToTop}
              className="w-9 h-9 rounded-xl bg-slate-900 light-theme:bg-white border border-slate-800 light-theme:border-slate-300 hover:border-cyan-500/40 text-slate-300 light-theme:text-slate-700 hover:text-cyan-400 light-theme:hover:text-cyan-600 flex items-center justify-center transition-all cursor-pointer shadow-sm"
              aria-label="Scroll back to top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>

        </div>
      </div>
    </footer>
  );
};
