import React, { useRef, useState, useCallback } from 'react';

interface Spatial3DTiltCardProps {
  children: React.ReactNode;
  className?: string;
  maxTilt?: number;
  perspective?: number;
  glowColor?: string;
  onClick?: () => void;
  dataCursor?: 'view' | 'drag' | 'tilt' | 'zoom';
}

export const Spatial3DTiltCard: React.FC<Spatial3DTiltCardProps> = ({
  children,
  className = '',
  maxTilt = 12,
  perspective = 1000,
  glowColor = 'rgba(6, 182, 212, 0.25)',
  onClick,
  dataCursor,
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [glarePos, setGlarePos] = useState({ x: 50, y: 50 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (!cardRef.current) return;
      const rect = cardRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      const normX = (x / rect.width) * 2 - 1; // -1 to 1
      const normY = (y / rect.height) * 2 - 1; // -1 to 1

      // tiltX is rotated around horizontal axis by normY, tiltY is rotated around vertical axis by normX
      setTilt({
        x: -normY * maxTilt,
        y: normX * maxTilt,
      });

      setGlarePos({
        x: (x / rect.width) * 100,
        y: (y / rect.height) * 100,
      });
    },
    [maxTilt]
  );

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setTilt({ x: 0, y: 0 });
    setGlarePos({ x: 50, y: 50 });
  };

  return (
    <div
      ref={cardRef}
      onClick={onClick}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      data-cursor={dataCursor}
      className={`relative transition-all duration-300 ease-out will-change-transform ${className}`}
      style={{
        perspective: `${perspective}px`,
        transformStyle: 'preserve-3d',
      }}
    >
      <div
        className="w-full h-full relative rounded-3xl transition-transform duration-200 ease-out"
        style={{
          transform: isHovered
            ? `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg) scale3d(1.025, 1.025, 1.025)`
            : 'rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)',
          transformStyle: 'preserve-3d',
        }}
      >
        {children}

        {/* Dynamic Holographic Specular Sheen (Reacts to cursor coordinates) */}
        <div
          className="pointer-events-none absolute inset-0 rounded-3xl transition-opacity duration-300 overflow-hidden mix-blend-overlay"
          style={{
            opacity: isHovered ? 0.85 : 0,
            background: `radial-gradient(circle 380px at ${glarePos.x}% ${glarePos.y}%, rgba(255, 255, 255, 0.45) 0%, ${glowColor} 45%, transparent 75%)`,
          }}
        />

        {/* Prismatic perimeter edge shimmer on tilt */}
        <div
          className="pointer-events-none absolute -inset-[1px] rounded-3xl transition-opacity duration-300 opacity-0 group-hover:opacity-100"
          style={{
            opacity: isHovered ? 1 : 0,
            background: `linear-gradient(${tilt.y * 12 + 135}deg, rgba(6, 182, 212, 0.6), rgba(168, 85, 247, 0.5), rgba(244, 63, 94, 0.4), transparent)`,
            mask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
            maskComposite: 'exclude',
            WebkitMaskComposite: 'xor',
            padding: '1.5px',
          }}
        />
      </div>
    </div>
  );
};
