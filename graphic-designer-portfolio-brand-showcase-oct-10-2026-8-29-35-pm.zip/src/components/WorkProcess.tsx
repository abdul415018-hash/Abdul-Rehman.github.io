import React from 'react';
import { Search, Compass, PenTool, Sparkles, Layers, Rocket } from 'lucide-react';
import { ProcessStep } from '../data/portfolioData';

interface WorkProcessProps {
  processTitle: string;
  process: ProcessStep[];
}

export const WorkProcess: React.FC<WorkProcessProps> = ({ processTitle, process }) => {
  const getIcon = (idx: number) => {
    switch (idx) {
      case 0:
        return <Search className="w-5 h-5 text-cyan-400 light-theme:text-cyan-600" />;
      case 1:
        return <Compass className="w-5 h-5 text-cyan-400 light-theme:text-cyan-600" />;
      case 2:
        return <PenTool className="w-5 h-5 text-cyan-400 light-theme:text-cyan-600" />;
      case 3:
        return <Sparkles className="w-5 h-5 text-cyan-400 light-theme:text-cyan-600" />;
      case 4:
        return <Layers className="w-5 h-5 text-cyan-400 light-theme:text-cyan-600" />;
      case 5:
      default:
        return <Rocket className="w-5 h-5 text-cyan-400 light-theme:text-cyan-600" />;
    }
  };

  return (
    <section id="process" className="py-16 sm:py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex items-center gap-3 mb-8 sm:mb-10">
          <div className="w-9 h-9 rounded-xl bg-cyan-950/80 light-theme:bg-cyan-100 border border-cyan-500/30 light-theme:border-cyan-300 flex items-center justify-center text-cyan-400 light-theme:text-cyan-700">
            <Layers className="w-4 h-4" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white light-theme:text-slate-900 tracking-tight">
            {processTitle}
          </h2>
        </div>

        {/* 6-step Grid matching reference image */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4 sm:gap-5 relative">
          {process.map((item, idx) => (
            <div
              key={idx}
              className="glow-card glow-card-hover p-5 rounded-2xl border border-cyan-500/20 light-theme:border-cyan-500/30 flex flex-col items-center text-center relative group"
            >
              {/* Step Icon with Glowing Ring */}
              <div className="w-12 h-12 rounded-full bg-cyan-950/80 light-theme:bg-cyan-100 border border-cyan-500/40 light-theme:border-cyan-300 flex items-center justify-center mb-4 group-hover:scale-110 group-hover:border-cyan-400 transition-all duration-300 shadow-md shadow-cyan-950/40 light-theme:shadow-cyan-500/10">
                {getIcon(idx)}
              </div>

              {/* Step Index Number */}
              <div className="text-xs font-extrabold text-cyan-400 light-theme:text-cyan-600 tabular-nums uppercase tracking-widest mb-1">
                {item.step}
              </div>

              {/* Step Title */}
              <h3 className="text-sm font-bold text-white light-theme:text-slate-900 mb-2 group-hover:text-cyan-300 light-theme:group-hover:text-cyan-600 transition-colors">
                {item.title}
              </h3>

              {/* Step Description */}
              <p className="text-xs text-slate-400 light-theme:text-slate-600 leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
