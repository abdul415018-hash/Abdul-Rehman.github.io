import React, { useState } from 'react';
import {
  Sparkles,
  Zap,
  CheckCircle2,
  Clock,
  RotateCcw,
  Package,
  MessageCircle,
  Copy,
  Check,
  Send,
  X,
  Tag,
  Star,
  ChevronRight,
  ShieldCheck,
  Award
} from 'lucide-react';
import { ServiceItem, ServicesConfig } from '../data/templates';
import { Spatial3DTiltCard } from './Spatial3DTiltCard';

interface ServicesSectionProps {
  servicesConfig: ServicesConfig;
  services: ServiceItem[];
  primaryAccent?: string;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  servicesConfig,
  services,
  primaryAccent = '#06b6d4',
}) => {
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [deliverySpeed, setDeliverySpeed] = useState<'standard' | 'express'>('standard');
  const [clientName, setClientName] = useState('');
  const [projectNotes, setProjectNotes] = useState('');
  const [isCopied, setIsCopied] = useState(false);

  const categories = [
    { id: 'all', label: 'All Services' },
    { id: 'branding', label: 'Brand & Identity' },
    { id: 'packaging', label: 'Packaging & CAD' },
    { id: 'social', label: 'Social Media' },
    { id: 'print', label: 'Print & Editorial' },
    { id: 'logo', label: 'Logo & Vector' },
  ];

  const filteredServices = services.filter((srv) => {
    if (selectedFilter === 'all') return true;
    return srv.category === selectedFilter;
  });

  const handleOpenOrderModal = (service: ServiceItem, defaultSpeed: 'standard' | 'express' = 'standard') => {
    setSelectedService(service);
    setDeliverySpeed(defaultSpeed);
    setIsCopied(false);
  };

  const cleanWhatsAppNumber = (servicesConfig.whatsappNumber || '+923101234567').replace(/[^0-9]/g, '');

  const generateWhatsAppMessage = () => {
    if (!selectedService) return '';
    const speedLabel = deliverySpeed === 'express' ? '⚡ Express Delivery' : '⏱ Standard Delivery';
    const price = deliverySpeed === 'express' ? selectedService.expressPrice : selectedService.standardPrice;
    const days = deliverySpeed === 'express' ? selectedService.expressDays : selectedService.standardDays;
    
    let msg = `*Assalam-o-Alaikum / Hello Abdul Tariq!*\n\n`;
    msg += `I would like to order a Graphic Design Package through your portfolio:\n\n`;
    msg += `📌 *Package:* ${selectedService.title}\n`;
    msg += `🚀 *Speed:* ${speedLabel} (${days})\n`;
    msg += `💰 *Budget / Price:* ${price}\n`;
    msg += `🔄 *Revisions:* ${selectedService.revisions}\n`;
    msg += `📦 *Deliverables:* ${selectedService.deliverablesCount}\n`;
    if (clientName.trim()) {
      msg += `👤 *My Name:* ${clientName.trim()}\n`;
    }
    if (projectNotes.trim()) {
      msg += `📝 *Project Brief:* ${projectNotes.trim()}\n`;
    }
    msg += `\nPlease confirm availability and next steps to start!`;
    return msg;
  };

  const handleLaunchWhatsApp = () => {
    const text = encodeURIComponent(generateWhatsAppMessage());
    const url = `https://wa.me/${cleanWhatsAppNumber}?text=${text}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleCopyQuotation = () => {
    navigator.clipboard.writeText(generateWhatsAppMessage()).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2200);
    });
  };

  return (
    <section id="services" className="relative py-24 sm:py-32 overflow-hidden">
      {/* Background radial accent glow */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[600px] rounded-full blur-[160px] pointer-events-none -z-10 opacity-15"
        style={{ backgroundColor: primaryAccent }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/25 text-cyan-400 light-theme:text-cyan-700 text-xs font-mono font-semibold tracking-wider uppercase mb-4 shadow-[0_0_15px_rgba(6,182,212,0.15)]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>High-Impact Graphic Design Offerings</span>
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-white light-theme:text-slate-900 mb-4">
            {servicesConfig.sectionTitle}
          </h2>

          <p className="text-sm sm:text-base text-slate-400 light-theme:text-slate-600 leading-relaxed font-body">
            {servicesConfig.sectionSubtitle}
          </p>

          {/* Optional User-Created Promo Banner (Strictly controlled by Admin) */}
          {servicesConfig.promoBannerEnabled && servicesConfig.promoBannerText && (
            <div className="mt-6 inline-flex items-center gap-3 px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500/15 via-emerald-500/15 to-cyan-500/15 border border-amber-500/30 text-amber-300 light-theme:text-amber-800 text-xs sm:text-sm font-medium shadow-lg backdrop-blur-md">
              <Tag className="w-4 h-4 text-amber-400 shrink-0 animate-bounce" />
              <span>{servicesConfig.promoBannerText}</span>
            </div>
          )}
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center justify-center gap-2 flex-wrap mb-12">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedFilter(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold tracking-wider transition-all cursor-pointer ${
                selectedFilter === cat.id
                  ? 'bg-gradient-to-r from-cyan-500 to-purple-600 text-white shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                  : 'bg-slate-900/60 light-theme:bg-white text-slate-400 light-theme:text-slate-600 border border-slate-800 light-theme:border-slate-300 hover:text-white light-theme:hover:text-slate-900'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Services Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredServices.map((service) => (
            <Spatial3DTiltCard
              key={service.id}
              className="h-full"
              maxTilt={7}
            >
              <div className="h-full rounded-2xl bg-slate-900/80 light-theme:bg-white border border-slate-800/90 light-theme:border-slate-200/90 p-6 flex flex-col justify-between relative overflow-hidden group shadow-xl">
                {/* Popular or Special Badge */}
                {service.isPopular && (
                  <div className="absolute top-0 right-0 bg-gradient-to-l from-amber-500 to-orange-500 text-slate-950 text-[10px] font-black uppercase tracking-wider px-3 py-1 rounded-bl-xl shadow-md flex items-center gap-1">
                    <Star className="w-3 h-3 fill-slate-950" />
                    <span>Most Popular</span>
                  </div>
                )}

                <div>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <span className="text-[11px] font-mono tracking-wider uppercase px-2.5 py-1 rounded-lg bg-cyan-500/10 text-cyan-400 light-theme:text-cyan-700 border border-cyan-500/20">
                      {service.category.toUpperCase()}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-white light-theme:text-slate-900 group-hover:text-cyan-400 light-theme:group-hover:text-cyan-600 transition-colors mb-2">
                    {service.title}
                  </h3>

                  <p className="text-xs text-slate-400 light-theme:text-slate-600 line-clamp-2 mb-5 leading-relaxed font-body">
                    {service.shortDesc}
                  </p>

                  {/* Dual Speed Pricing Matrix */}
                  <div className="grid grid-cols-2 gap-2 p-3 rounded-xl bg-slate-950/60 light-theme:bg-slate-50 border border-slate-800/60 light-theme:border-slate-200/70 mb-5">
                    {/* Standard Speed */}
                    <div className="p-2 rounded-lg bg-slate-900/50 light-theme:bg-white/80 border border-slate-800/40">
                      <div className="flex items-center gap-1 text-[10px] text-slate-400 light-theme:text-slate-500 font-medium">
                        <Clock className="w-3 h-3 text-cyan-400" />
                        <span>Standard</span>
                      </div>
                      <div className="font-extrabold text-sm text-white light-theme:text-slate-900 mt-1">
                        {service.standardPrice}
                      </div>
                      <div className="text-[10px] font-mono text-cyan-400 light-theme:text-cyan-600">
                        {service.standardDays}
                      </div>
                    </div>

                    {/* Express Speed */}
                    <div className="p-2 rounded-lg bg-amber-500/5 border border-amber-500/25">
                      <div className="flex items-center gap-1 text-[10px] text-amber-400 light-theme:text-amber-700 font-semibold">
                        <Zap className="w-3 h-3 text-amber-400" />
                        <span>Express ⚡</span>
                      </div>
                      <div className="font-extrabold text-sm text-amber-300 light-theme:text-amber-800 mt-1">
                        {service.expressPrice}
                      </div>
                      <div className="text-[10px] font-mono text-amber-400 light-theme:text-amber-700">
                        {service.expressDays}
                      </div>
                    </div>
                  </div>

                  {/* Service Meta Specs */}
                  <div className="flex items-center justify-between text-[11px] text-slate-400 light-theme:text-slate-600 py-2 border-y border-slate-800/60 light-theme:border-slate-200/70 mb-4 font-mono">
                    <span className="flex items-center gap-1">
                      <RotateCcw className="w-3 h-3 text-purple-400" />
                      {service.revisions}
                    </span>
                    <span className="flex items-center gap-1">
                      <Package className="w-3 h-3 text-emerald-400" />
                      {service.deliverablesCount}
                    </span>
                  </div>

                  {/* Highlights Bullet List */}
                  <ul className="space-y-1.5 mb-5">
                    {service.features.slice(0, 4).map((feat, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs text-slate-300 light-theme:text-slate-700">
                        <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 light-theme:text-cyan-600 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Special Offer Ribbon if attached */}
                  {service.specialOffer && (
                    <div className="mb-5 p-3 rounded-xl bg-gradient-to-r from-purple-500/10 via-pink-500/10 to-amber-500/10 border border-purple-500/30">
                      <div className="flex items-center gap-1.5 text-[11px] font-bold text-purple-300 light-theme:text-purple-700">
                        <Award className="w-3.5 h-3.5" />
                        <span>{service.specialOffer.title}</span>
                      </div>
                      <p className="text-[11px] text-slate-300 light-theme:text-slate-600 mt-1">
                        {service.specialOffer.description}
                      </p>
                    </div>
                  )}
                </div>

                {/* Actions: Direct WhatsApp Order CTA */}
                <div className="pt-2 flex items-center gap-2">
                  <button
                    onClick={() => handleOpenOrderModal(service, 'standard')}
                    className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs tracking-wide shadow-[0_0_15px_rgba(16,185,129,0.3)] transition-all cursor-pointer group/btn"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Order via WhatsApp</span>
                  </button>

                  <button
                    onClick={() => handleOpenOrderModal(service, 'express')}
                    className="p-2.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-400 transition-colors cursor-pointer"
                    title="Express Rush Order"
                  >
                    <Zap className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </Spatial3DTiltCard>
          ))}
        </div>
      </div>

      {/* WhatsApp Order Modal Dialog */}
      {selectedService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-xl rounded-2xl bg-[#090d1a] light-theme:bg-white border border-cyan-500/30 light-theme:border-slate-300 shadow-[0_20px_50px_rgba(0,0,0,0.8)] p-6 sm:p-7 overflow-hidden max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-3 pb-4 border-b border-slate-800 light-theme:border-slate-200">
              <div>
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 light-theme:text-emerald-700 text-[10px] font-mono uppercase tracking-wider mb-1.5">
                  <MessageCircle className="w-3 h-3" />
                  <span>Direct WhatsApp Checkout</span>
                </div>
                <h3 className="text-xl font-bold text-white light-theme:text-slate-900">
                  {selectedService.title}
                </h3>
              </div>
              <button
                onClick={() => setSelectedService(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white light-theme:text-slate-500 light-theme:hover:text-slate-900 hover:bg-slate-800 light-theme:hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Select Delivery Speed Toggle */}
            <div className="my-5">
              <label className="block text-xs font-semibold text-slate-300 light-theme:text-slate-700 mb-2">
                Select Turnaround Timeline & Pricing:
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setDeliverySpeed('standard')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    deliverySpeed === 'standard'
                      ? 'bg-cyan-500/10 border-cyan-500 text-white light-theme:text-slate-900 shadow-[0_0_15px_rgba(6,182,212,0.2)]'
                      : 'bg-slate-900/50 light-theme:bg-slate-50 border-slate-800 light-theme:border-slate-200 text-slate-400 light-theme:text-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-semibold mb-1">
                    <span>⏱ Standard Pace</span>
                    {deliverySpeed === 'standard' && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                  </div>
                  <div className="text-base font-extrabold text-cyan-400 light-theme:text-cyan-700">
                    {selectedService.standardPrice}
                  </div>
                  <div className="text-[10px] font-mono text-slate-400 light-theme:text-slate-500">
                    Delivered in {selectedService.standardDays}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setDeliverySpeed('express')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    deliverySpeed === 'express'
                      ? 'bg-amber-500/15 border-amber-500 text-white light-theme:text-slate-900 shadow-[0_0_15px_rgba(245,158,11,0.25)]'
                      : 'bg-slate-900/50 light-theme:bg-slate-50 border-slate-800 light-theme:border-slate-200 text-slate-400 light-theme:text-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-semibold text-amber-400 mb-1">
                    <span>⚡ Rush Express</span>
                    {deliverySpeed === 'express' && <Check className="w-3.5 h-3.5 text-amber-400" />}
                  </div>
                  <div className="text-base font-extrabold text-amber-400 light-theme:text-amber-800">
                    {selectedService.expressPrice}
                  </div>
                  <div className="text-[10px] font-mono text-amber-300 light-theme:text-amber-700">
                    Priority {selectedService.expressDays}
                  </div>
                </button>
              </div>
            </div>

            {/* Quick Details Inputs */}
            <div className="space-y-3 mb-5">
              <div>
                <label className="block text-[11px] font-medium text-slate-300 light-theme:text-slate-700 mb-1">
                  Your Name / Company:
                </label>
                <input
                  type="text"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="e.g. Bilal Ahmed / Apex Studio"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950/80 light-theme:bg-white border border-slate-800 light-theme:border-slate-300 text-xs text-white light-theme:text-slate-900 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-300 light-theme:text-slate-700 mb-1">
                  Brief Project Requirements (Optional):
                </label>
                <textarea
                  rows={2}
                  value={projectNotes}
                  onChange={(e) => setProjectNotes(e.target.value)}
                  placeholder="e.g. Logo for real estate business in minimalist geometric style..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-950/80 light-theme:bg-white border border-slate-800 light-theme:border-slate-300 text-xs text-white light-theme:text-slate-900 focus:outline-none focus:border-cyan-500 resize-none"
                />
              </div>
            </div>

            {/* Live Message Preview */}
            <div className="p-3 rounded-xl bg-slate-950/90 light-theme:bg-slate-100 border border-slate-800 light-theme:border-slate-200 mb-5">
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 light-theme:text-slate-500 mb-1">
                <span>PREVIEW OF WHATSAPP MESSAGE:</span>
                <span className="text-emerald-400">Ready to Send</span>
              </div>
              <pre className="text-[11px] text-slate-300 light-theme:text-slate-800 font-mono whitespace-pre-wrap leading-tight max-h-24 overflow-y-auto">
                {generateWhatsAppMessage()}
              </pre>
            </div>

            {/* Actions: Send to WhatsApp + Copy Message */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={handleLaunchWhatsApp}
                className="flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs tracking-wide shadow-[0_0_20px_rgba(16,185,129,0.4)] transition-all cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Open in WhatsApp</span>
              </button>

              <button
                type="button"
                onClick={handleCopyQuotation}
                className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 light-theme:bg-slate-200 light-theme:hover:bg-slate-300 text-slate-200 light-theme:text-slate-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Copy Quotation to Clipboard"
              >
                {isCopied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
