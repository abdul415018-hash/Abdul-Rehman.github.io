import React, { useState } from 'react';
import { Send, Mail, Phone, MapPin, Clock, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { ContactConfig, ContactMessage } from '../data/portfolioData';

interface ContactSectionProps {
  contact: ContactConfig;
  onNewMessage: (message: ContactMessage) => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ contact, onNewMessage }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: 'Project Inquiry & Collaboration',
    message: '',
  });

  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setStatus('error');
      setErrorMessage('Please fill out all required fields.');
      return;
    }

    setStatus('submitting');
    setErrorMessage('');

    setTimeout(() => {
      // Record message into inbox
      const newMsg: ContactMessage = {
        id: `msg_${Date.now()}`,
        name: formData.name.trim(),
        email: formData.email.trim(),
        subject: formData.subject.trim(),
        message: formData.message.trim(),
        date: new Date().toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }),
        read: false,
      };

      onNewMessage(newMsg);

      setStatus('success');
      setFormData({
        name: '',
        email: '',
        subject: 'Project Inquiry & Collaboration',
        message: '',
      });
      setTimeout(() => setStatus('idle'), 6000);
    }, 1000);
  };

  return (
    <section id="contact" className="py-16 sm:py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Card Container matching reference image */}
        <div className="glow-card rounded-3xl p-6 sm:p-10 lg:p-12 border border-cyan-500/25">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
            
            {/* Left Column: Direct Coordinates */}
            <div className="lg:col-span-5 flex flex-col justify-between h-full">
              <div>
                <h2 className="text-3xl sm:text-4xl font-extrabold text-white light-theme:text-slate-900 tracking-tight leading-tight mb-4 flex items-center gap-3">
                  <span className="text-cyan-400 light-theme:text-cyan-600">
                    <Send className="w-7 h-7 inline-block -mt-1" />
                  </span>
                  <span>{contact.title}</span>
                </h2>

                <p className="text-sm sm:text-base text-slate-300 light-theme:text-slate-600 leading-relaxed mb-8">
                  {contact.description}
                </p>

                {/* Direct info items */}
                <div className="space-y-4 mb-8">
                  <div className="flex items-start gap-3.5 p-3 rounded-xl bg-slate-950/50 light-theme:bg-slate-100/80 border border-slate-800 light-theme:border-slate-200">
                    <div className="w-8 h-8 rounded-lg bg-cyan-950/80 light-theme:bg-cyan-100 border border-cyan-500/30 light-theme:border-cyan-300 flex items-center justify-center text-cyan-400 light-theme:text-cyan-700 shrink-0">
                      <Mail className="w-4 h-4" />
                    </div>
                    <div className="overflow-hidden">
                      <span className="text-[11px] text-slate-400 light-theme:text-slate-500 block font-medium">Email</span>
                      <a
                        href={`mailto:${contact.email}`}
                        className="text-sm font-semibold text-slate-200 light-theme:text-slate-800 hover:text-cyan-400 light-theme:hover:text-cyan-600 transition-colors truncate block"
                      >
                        {contact.email}
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3.5 p-3 rounded-xl bg-slate-950/50 light-theme:bg-slate-100/80 border border-slate-800 light-theme:border-slate-200">
                    <div className="w-8 h-8 rounded-lg bg-blue-950/80 light-theme:bg-sky-100 border border-blue-500/30 light-theme:border-sky-300 flex items-center justify-center text-blue-400 light-theme:text-sky-700 shrink-0">
                      <Phone className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 light-theme:text-slate-500 block font-medium">Phone</span>
                      <a
                        href={`tel:${contact.phone}`}
                        className="text-sm font-semibold text-slate-200 light-theme:text-slate-800 hover:text-cyan-400 light-theme:hover:text-cyan-600 transition-colors"
                      >
                        {contact.phone}
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3.5 p-3 rounded-xl bg-slate-950/50 light-theme:bg-slate-100/80 border border-slate-800 light-theme:border-slate-200">
                    <div className="w-8 h-8 rounded-lg bg-slate-900 light-theme:bg-slate-200 border border-slate-800 light-theme:border-slate-300 flex items-center justify-center text-cyan-400 light-theme:text-cyan-700 shrink-0">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 light-theme:text-slate-500 block font-medium">Location</span>
                      <span className="text-sm font-semibold text-slate-200 light-theme:text-slate-800">
                        {contact.location}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-start gap-3.5 p-3 rounded-xl bg-slate-950/50 light-theme:bg-slate-100/80 border border-slate-800 light-theme:border-slate-200">
                    <div className="w-8 h-8 rounded-lg bg-emerald-950/80 light-theme:bg-emerald-100 border border-emerald-500/30 light-theme:border-emerald-300 flex items-center justify-center text-emerald-400 light-theme:text-emerald-700 shrink-0">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 light-theme:text-slate-500 block font-medium">Availability</span>
                      <span className="text-xs font-semibold text-emerald-400 light-theme:text-emerald-600 flex items-center gap-1.5 mt-0.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        <span>{contact.availability}</span>
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Direct Mail Prompt */}
              <div className="pt-2">
                <a
                  href={`mailto:${contact.email}`}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 transition-colors shadow-md shadow-cyan-500/20"
                >
                  <span>Send Message Directly</span>
                  <span>&rarr;</span>
                </a>
              </div>
            </div>

            {/* Right Column: Contact Inquiry Form */}
            <div className="lg:col-span-7 bg-slate-950/60 light-theme:bg-slate-50 p-6 sm:p-8 rounded-2xl border border-slate-800/80 light-theme:border-slate-200">
              <form onSubmit={handleSubmit} className="space-y-4">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name field */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 light-theme:text-slate-700 mb-1.5" htmlFor="c-name">
                      Your Name
                    </label>
                    <input
                      id="c-name"
                      type="text"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Your Name"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 light-theme:bg-white border border-slate-800 light-theme:border-slate-300 text-sm text-slate-100 light-theme:text-slate-900 placeholder-slate-500 light-theme:placeholder-slate-400 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-colors"
                    />
                  </div>

                  {/* Email field */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 light-theme:text-slate-700 mb-1.5" htmlFor="c-email">
                      Your Email
                    </label>
                    <input
                      id="c-email"
                      type="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="Your Email"
                      className="w-full px-4 py-2.5 rounded-xl bg-slate-900 light-theme:bg-white border border-slate-800 light-theme:border-slate-300 text-sm text-slate-100 light-theme:text-slate-900 placeholder-slate-500 light-theme:placeholder-slate-400 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-colors"
                    />
                  </div>
                </div>

                {/* Subject field */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 light-theme:text-slate-700 mb-1.5" htmlFor="c-subject">
                    Subject
                  </label>
                  <input
                    id="c-subject"
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    placeholder="Subject"
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900 light-theme:bg-white border border-slate-800 light-theme:border-slate-300 text-sm text-slate-100 light-theme:text-slate-900 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-colors"
                  />
                </div>

                {/* Message field */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 light-theme:text-slate-700 mb-1.5" htmlFor="c-msg">
                    Your Message
                  </label>
                  <textarea
                    id="c-msg"
                    name="message"
                    rows={4}
                    required
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Your Message"
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900 light-theme:bg-white border border-slate-800 light-theme:border-slate-300 text-sm text-slate-100 light-theme:text-slate-900 placeholder-slate-500 light-theme:placeholder-slate-400 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-colors resize-none"
                  />
                </div>

                {/* Error Banner */}
                {status === 'error' && (
                  <div className="flex items-center gap-2 p-2.5 rounded-xl bg-rose-950/60 light-theme:bg-rose-50 border border-rose-800/80 light-theme:border-rose-300 text-rose-300 light-theme:text-rose-700 text-xs">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMessage || 'Please fill in all required fields.'}</span>
                  </div>
                )}

                {/* Success Banner */}
                {status === 'success' && (
                  <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-950/70 light-theme:bg-emerald-50 border border-emerald-700/80 light-theme:border-emerald-300 text-emerald-300 light-theme:text-emerald-700 text-xs animate-in fade-in">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>Message sent successfully! Thank you for reaching out.</span>
                  </div>
                )}

                {/* Submit button matching reference image */}
                <button
                  type="submit"
                  disabled={status === 'submitting'}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-bold text-sm text-slate-950 bg-gradient-to-r from-cyan-400 to-cyan-300 hover:from-cyan-300 hover:to-white shadow-lg shadow-cyan-500/25 transition-all duration-200 cursor-pointer disabled:opacity-50"
                >
                  {status === 'submitting' ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Sending Message...</span>
                    </>
                  ) : (
                    <>
                      <span>{contact.submitBtnText || 'Send Message'}</span>
                      <Send className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
