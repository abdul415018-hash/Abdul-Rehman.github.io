import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, BarChart3, Star, Users, FolderCheck, Award } from 'lucide-react';
import { TestimonialItem, StatItem } from '../data/portfolioData';

interface TestimonialsAndNumbersProps {
  testimonialsTitle: string;
  testimonials: TestimonialItem[];
  statsTitle: string;
  stats: StatItem[];
}

export const TestimonialsAndNumbers: React.FC<TestimonialsAndNumbersProps> = ({
  testimonialsTitle,
  testimonials,
  statsTitle,
  stats,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const prevReview = () => {
    setCurrentIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1));
  };

  const nextReview = () => {
    setCurrentIndex((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1));
  };

  const currentTestimonial = testimonials[currentIndex] || testimonials[0];

  return (
    <section id="testimonials" className="py-16 sm:py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left Card: What Clients Say */}
          <div className="lg:col-span-7 glow-card p-6 sm:p-8 rounded-3xl border border-cyan-500/25 flex flex-col justify-between">
            <div>
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-cyan-950/80 light-theme:bg-cyan-100 border border-cyan-500/30 light-theme:border-cyan-300 flex items-center justify-center text-cyan-400 light-theme:text-cyan-700 font-bold text-lg">
                    &ldquo;&rdquo;
                  </div>
                  <h3 className="text-xl font-bold text-white light-theme:text-slate-900 tracking-tight">{testimonialsTitle}</h3>
                </div>

                {/* Rating Stars */}
                <div className="flex items-center gap-1 text-amber-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400" />
                  ))}
                </div>
              </div>

              {/* Quote Body */}
              {currentTestimonial && (
                <blockquote className="text-base sm:text-lg text-slate-200 light-theme:text-slate-700 font-medium italic leading-relaxed mb-8 min-h-[90px]">
                  &ldquo;{currentTestimonial.quote}&rdquo;
                </blockquote>
              )}
            </div>

            {/* Client Signature & Controls */}
            {currentTestimonial && (
              <div className="pt-6 border-t border-slate-800/80 light-theme:border-slate-200 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <div className="w-11 h-11 rounded-full overflow-hidden bg-slate-800 border-2 border-cyan-400/40 shrink-0">
                    <img
                      src={currentTestimonial.avatar}
                      alt={currentTestimonial.clientName}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white light-theme:text-slate-900 leading-tight">
                      &ndash; {currentTestimonial.clientName}
                    </h4>
                    <p className="text-xs text-slate-400 light-theme:text-slate-500 font-medium">
                      {currentTestimonial.role}, {currentTestimonial.company}
                    </p>
                  </div>
                </div>

                {/* Navigation Arrows */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={prevReview}
                    className="w-8 h-8 rounded-lg bg-slate-900 light-theme:bg-slate-100 border border-slate-800 light-theme:border-slate-300 hover:border-cyan-500/40 text-slate-300 light-theme:text-slate-700 hover:text-white light-theme:hover:text-slate-900 flex items-center justify-center transition-all cursor-pointer"
                    aria-label="Previous review"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <div className="flex gap-1.5 px-1">
                    {testimonials.map((_, i) => (
                      <button
                        key={i}
                        onClick={() => setCurrentIndex(i)}
                        className={`w-2 h-2 rounded-full transition-all ${
                          currentIndex === i ? 'bg-cyan-400 w-4' : 'bg-slate-700 light-theme:bg-slate-300'
                        }`}
                        aria-label={`Go to slide ${i + 1}`}
                      />
                    ))}
                  </div>
                  <button
                    onClick={nextReview}
                    className="w-8 h-8 rounded-lg bg-slate-900 light-theme:bg-slate-100 border border-slate-800 light-theme:border-slate-300 hover:border-cyan-500/40 text-slate-300 light-theme:text-slate-700 hover:text-white light-theme:hover:text-slate-900 flex items-center justify-center transition-all cursor-pointer"
                    aria-label="Next review"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Right Card: By The Numbers */}
          <div className="lg:col-span-5 glow-card p-6 sm:p-8 rounded-3xl border border-cyan-500/25 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-blue-950/80 light-theme:bg-sky-100 border border-blue-500/30 light-theme:border-sky-300 flex items-center justify-center text-blue-400 light-theme:text-sky-700">
                  <BarChart3 className="w-5 h-5" />
                </div>
                <h3 className="text-xl font-bold text-white light-theme:text-slate-900 tracking-tight">{statsTitle}</h3>
              </div>

              {/* 2x2 Stat Cards Grid matching reference image */}
              <div className="grid grid-cols-2 gap-4">
                {stats.map((stat, idx) => (
                  <div
                    key={stat.id || idx}
                    className="p-4 rounded-2xl bg-slate-950/60 light-theme:bg-slate-100/80 border border-slate-800/80 light-theme:border-slate-200 flex flex-col items-center text-center"
                  >
                    <div className="text-2xl sm:text-3xl font-extrabold text-cyan-400 light-theme:text-cyan-600 tabular-nums tracking-tight">
                      {stat.value}
                    </div>
                    <div className="text-xs text-slate-400 light-theme:text-slate-600 font-medium mt-1">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
