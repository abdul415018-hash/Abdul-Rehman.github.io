import React from 'react';
import { TemplateMotionConfig } from '../../data/templates';

interface Props {
  motionConfig: TemplateMotionConfig;
}

export const LuxuryGoldOverlay: React.FC<Props> = ({ motionConfig }) => {
  if (!motionConfig.enabled) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden" aria-hidden="true">
      {/* 1. TOP DUAL-TIER GOLD CORD & DIAMOND HAIRLINE ACCENTS */}
      {motionConfig.showGarland && (
        <div className="absolute top-0 left-0 right-0 pointer-events-none">
          {/* Top shimmering gold foil hairline */}
          <div className="h-[2px] bg-gradient-to-r from-transparent via-amber-300 to-transparent opacity-80" />
          <div className="h-[1px] bg-gradient-to-r from-transparent via-yellow-200/50 to-transparent mt-[2px]" />
          
          {/* Subtle center diamond hallmark */}
          <div className="absolute top-1 left-1/2 -translate-x-1/2 flex items-center gap-2">
            <span className="w-8 h-[1px] bg-gradient-to-r from-transparent to-amber-300/80" />
            <div className="w-2 h-2 rotate-45 border border-amber-300 bg-amber-400/30 shadow-[0_0_10px_rgba(251,191,36,0.6)]" />
            <span className="w-8 h-[1px] bg-gradient-to-l from-transparent to-amber-300/80" />
          </div>
        </div>
      )}

      {/* 2. FLOATING 24K GOLD LEAF BOKEH & STARLET PARTICLES */}
      {motionConfig.showParticles && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {Array.from({ length: 24 }).map((_, i) => {
            const left = (i * 4.3 + 1.5) % 96;
            const size = 4 + (i % 5) * 3;
            const duration = 18 + (i % 6) * 4;
            const delay = (i * 0.75).toFixed(1);

            return (
              <div
                key={i}
                className="absolute"
                style={{
                  left: `${left}%`,
                  bottom: '-35px',
                  width: `${size}px`,
                  height: `${size}px`,
                  animation: `floatUpwards ${duration}s linear infinite`,
                  animationDelay: `${delay}s`,
                }}
              >
                {/* 24K Gold Leaf Flake with subtle luminous aura */}
                <div
                  className="w-full h-full rounded-full bg-gradient-to-tr from-amber-600 via-amber-300 to-yellow-100 shadow-[0_0_10px_rgba(245,158,11,0.7)]"
                  style={{
                    opacity: 0.4 + (i % 4) * 0.18,
                    transform: `rotate(${i * 42}deg)`,
                  }}
                />
              </div>
            );
          })}
        </div>
      )}

      {/* 3. FLOATING HAUTE COUTURE ATELIER SEAL */}
      {motionConfig.showFloatingMotif && (
        <aside
          aria-label="Haute Couture Atelier Monograph"
          className="fixed top-24 right-4 sm:right-8 pointer-events-auto z-40 hidden sm:block"
        >
          <div className="px-3.5 py-1.5 rounded-full bg-stone-950/90 border border-amber-400/60 shadow-[0_6px_24px_rgba(212,175,55,0.25)] flex items-center gap-2 backdrop-blur-md">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse shadow-[0_0_8px_rgba(251,191,36,0.9)]" />
            <span className="font-serif italic text-xs text-amber-200 tracking-wider">
              Haute Couture Atelier // № 01
            </span>
          </div>
        </aside>
      )}
    </div>
  );
};
