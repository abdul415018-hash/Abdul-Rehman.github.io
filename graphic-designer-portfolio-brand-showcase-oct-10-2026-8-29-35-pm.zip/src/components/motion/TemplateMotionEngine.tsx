import React from 'react';
import { TemplateTheme, TemplateMotionConfig } from '../../data/templates';
import { PakistanIndependenceOverlay } from './PakistanIndependenceOverlay';
import { EidAdhaOverlay } from './EidAdhaOverlay';
import { EidFitrOverlay } from './EidFitrOverlay';
import { RamadanOverlay } from './RamadanOverlay';
import { LuxuryGoldOverlay } from './LuxuryGoldOverlay';
import { BauhausFloaterOverlay } from './BauhausFloaterOverlay';
import { CyberFutureOverlay } from './CyberFutureOverlay';
import { SwissStudioOverlay } from './SwissStudioOverlay';
import { ExecutiveSlateOverlay } from './ExecutiveSlateOverlay';

interface Props {
  activeTemplate: TemplateTheme;
  motionConfig: TemplateMotionConfig;
}

export const TemplateMotionEngine: React.FC<Props> = ({
  activeTemplate,
  motionConfig,
}) => {
  if (!motionConfig?.enabled) return null;

  switch (activeTemplate.motionType) {
    case 'independence':
      return <PakistanIndependenceOverlay motionConfig={motionConfig} />;
    case 'eid-adha':
      return <EidAdhaOverlay motionConfig={motionConfig} />;
    case 'eid-fitr':
      return <EidFitrOverlay motionConfig={motionConfig} />;
    case 'ramadan':
      return <RamadanOverlay motionConfig={motionConfig} />;
    case 'luxury-gold':
      return <LuxuryGoldOverlay motionConfig={motionConfig} />;
    case 'bauhaus':
      return <BauhausFloaterOverlay motionConfig={motionConfig} />;
    case 'swiss':
      return <SwissStudioOverlay motionConfig={motionConfig} />;
    case 'executive':
      return <ExecutiveSlateOverlay motionConfig={motionConfig} />;
    case 'cyber':
    default:
      return <CyberFutureOverlay motionConfig={motionConfig} />;
  }
};
