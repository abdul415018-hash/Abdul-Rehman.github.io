import React from 'react';
import { TemplateMotionConfig } from '../../data/templates';

interface Props {
  motionConfig: TemplateMotionConfig;
}

export const SwissStudioOverlay: React.FC<Props> = ({ motionConfig }) => {
  if (!motionConfig.enabled) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-40 overflow-hidden">
      {/* Top Architectural Alignment Frieze */}
      {motionConfig.showGarland && (
        <div className="absolute top-0 left-0 right-0 h-9 flex items-center justify-between px-6 bg-slate-900/[0.04] backdrop-blur-xs border-b border-slate-300/80 font-mono text-[10px] text-slate-600 select-none">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 font-bold text-slate-900 tracking-wider">
              <span className="w-2 h-2 bg-blue-600 rounded-[1px] animate-pulse" />
              SWISS GRID // MOD. 1957
            </span>
            <span className="hidden sm:inline text-slate-400">|</span>
            <span className="hidden sm:inline text-slate-500">ISO 216 / A-SERIES SCALE</span>
          </div>

          <div className="flex items-center gap-3 text-slate-500 font-medium">
            <span className="text-blue-700 font-bold">X: 1920</span>
            <span className="text-slate-300">•</span>
            <span className="text-red-600 font-bold">Y: 1080</span>
            <span className="hidden md:inline px-2 py-0.5 rounded bg-slate-200 text-slate-800 text-[9px] font-bold">
              HELVETICA RIGID
            </span>
          </div>
        </div>
      )}

      {/* Subtle Floating Swiss Cross Badge */}
      {motionConfig.showFloatingMotif && (
        <div className="absolute top-16 right-5 sm:right-10 flex flex-col items-center gap-1.5 animate-[bounce_6s_ease-in-out_infinite]">
          <div className="relative w-12 h-12 rounded-xl bg-white border-2 border-black shadow-[4px_4px_0px_#000000] flex items-center justify-center p-2">
            {/* Swiss Cross */}
            <div className="relative w-6 h-6 flex items-center justify-center">
              <div className="absolute w-6 h-2 bg-red-600 rounded-[1px]" />
              <div className="absolute w-2 h-6 bg-red-600 rounded-[1px]" />
            </div>
          </div>
          <span className="px-2 py-0.5 rounded bg-black text-white text-[9px] font-mono font-bold tracking-widest shadow-sm">
            ZRH / BSL
          </span>
        </div>
      )}

      {/* Floating Modernist Micro-Particles / Grid Dots */}
      {motionConfig.showParticles && (
        <div className="absolute inset-0 pointer-events-none">
          {/* Subtle vertical alignment hairline on left */}
          <div className="absolute top-24 bottom-12 left-8 w-[1px] bg-slate-300/40 hidden xl:block" />
          {/* Subtle vertical alignment hairline on right */}
          <div className="absolute top-24 bottom-12 right-8 w-[1px] bg-slate-300/40 hidden xl:block" />

          {/* Drifting precision grid ticks */}
          <div
            className="absolute top-1/4 left-[8%] w-2 h-2 border border-blue-600/60 rounded-[1px] animate-[spin_12s_linear_infinite]"
            style={{ animationDuration: motionConfig.speed === 'fast' ? '6s' : motionConfig.speed === 'slow' ? '18s' : '12s' }}
          />
          <div
            className="absolute top-1/2 right-[12%] w-2.5 h-2.5 bg-blue-600/15 rounded-full animate-pulse"
          />
          <div
            className="absolute top-3/4 left-[15%] w-3 h-[1px] bg-red-600/60"
          />
          <div
            className="absolute top-2/3 right-[20%] w-[1px] h-3 bg-slate-900/40"
          />
        </div>
      )}
    </div>
  );
};
