import React from 'react';
import { TemplateMotionConfig } from '../../data/templates';

interface Props {
  motionConfig: TemplateMotionConfig;
}

// Bezier curve calculations for realistic catenary sag physics
interface CurveSegment {
  x0: number;
  y0: number;
  cx: number;
  cy: number;
  x1: number;
  y1: number;
}

const SEGMENTS: CurveSegment[] = [
  { x0: 0, y0: 16, cx: 180, cy: 115, x1: 360, y1: 22 },
  { x0: 360, y0: 22, cx: 540, cy: 138, x1: 720, y1: 26 },
  { x0: 720, y0: 26, cx: 900, cy: 138, x1: 1080, y1: 22 },
  { x0: 1080, y0: 22, cx: 1260, cy: 115, x1: 1440, y1: 16 },
];

function getPointOnGarland(tx: number) {
  const x = tx * 1440;
  // find segment
  const seg = SEGMENTS.find((s) => x >= s.x0 && x <= s.x1) || SEGMENTS[SEGMENTS.length - 1];
  const t = Math.max(0, Math.min(1, (x - seg.x0) / (seg.x1 - seg.x0)));
  const oneMinusT = 1 - t;

  // Bezier point y
  const y =
    oneMinusT * oneMinusT * seg.y0 +
    2 * oneMinusT * t * seg.cy +
    t * t * seg.y1;

  // Tangent slope for natural flag tilt
  const dy = 2 * oneMinusT * (seg.cy - seg.y0) + 2 * t * (seg.y1 - seg.cy);
  const dx = 2 * oneMinusT * (seg.cx - seg.x0) + 2 * t * (seg.x1 - seg.cx);
  const angle = (Math.atan2(dy, dx) * 180) / Math.PI;

  return { x, y, angle };
}

export const PakistanIndependenceOverlay: React.FC<Props> = ({ motionConfig }) => {
  if (!motionConfig.enabled) return null;

  const totalFlags = 28;

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden" aria-hidden="true">
      {/* 1. DEEP-SAG HANGING BUNTING GARLANDS (JHANDIYAN) DRAPED OVER HEADER */}
      {motionConfig.showGarland && (
        <div className="absolute top-0 left-0 right-0 w-full overflow-hidden select-none">
          {/* Main Garland Banner Stage with Increased Sag Depth */}
          <div className="relative w-full h-36 sm:h-44 md:h-52">
            {/* SVG Background Hanging Ropes (Dual-layered for depth) */}
            <svg
              className="absolute inset-0 w-full h-full"
              viewBox="0 0 1440 180"
              preserveAspectRatio="none"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient id="pakGoldRope" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.75" />
                  <stop offset="25%" stopColor="#fef08a" stopOpacity="0.9" />
                  <stop offset="50%" stopColor="#f59e0b" stopOpacity="0.85" />
                  <stop offset="75%" stopColor="#fef08a" stopOpacity="0.9" />
                  <stop offset="100%" stopColor="#f59e0b" stopOpacity="0.75" />
                </linearGradient>

                <linearGradient id="pakAccentRope" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#10b981" stopOpacity="0.4" />
                  <stop offset="50%" stopColor="#34d399" stopOpacity="0.6" />
                  <stop offset="100%" stopColor="#10b981" stopOpacity="0.4" />
                </linearGradient>
              </defs>

              {/* Secondary upper decorative hanging strand */}
              <path
                d="M0,8 Q180,68 360,12 Q540,82 720,14 Q900,82 1080,12 Q1260,68 1440,8"
                stroke="url(#pakAccentRope)"
                strokeWidth="1.25"
                strokeDasharray="6 3"
              />

              {/* Main heavy sagging rope thread (Deep catenary curve) */}
              <path
                d="M0,16 Q180,115 360,22 Q540,138 720,26 Q900,138 1080,22 Q1260,115 1440,16"
                stroke="url(#pakGoldRope)"
                strokeWidth="2.5"
                className="drop-shadow-[0_2px_4px_rgba(0,0,0,0.45)]"
              />

              {/* Decorative Rosette Knots at Tie Points */}
              {[
                { x: 0, y: 16 },
                { x: 360, y: 22 },
                { x: 720, y: 26 },
                { x: 1080, y: 22 },
                { x: 1440, y: 16 },
              ].map((knot, kIdx) => (
                <g key={kIdx} transform={`translate(${knot.x}, ${knot.y})`}>
                  {/* Rosette ribbon ring */}
                  <circle cx="0" cy="0" r="6" fill="#00401A" stroke="#fbbf24" strokeWidth="2" />
                  <circle cx="0" cy="0" r="2.5" fill="#fef08a" />
                  {/* Hanging tie ribbons */}
                  <path d="M-3,5 L-5,22 L-1,18 L0,24 L3,18 L4,22 L2,5 Z" fill="#10b981" opacity="0.85" />
                </g>
              ))}
            </svg>

            {/* Alternating Green & White Bunting Flags Hanging Directly Along the Sagging Rope */}
            <div className="absolute inset-0 pointer-events-none">
              {Array.from({ length: totalFlags }).map((_, i) => {
                const tx = (i + 0.5) / totalFlags;
                const { y, angle } = getPointOnGarland(tx);
                const isGreen = i % 2 === 0;
                const isAlt = i % 3 === 0;
                const swayDelay = (i * 0.16).toFixed(2);
                const leftPercent = (tx * 100).toFixed(2);

                return (
                  <div
                    key={i}
                    className="absolute flex flex-col items-center origin-top -translate-x-1/2"
                    style={{
                      left: `${leftPercent}%`,
                      top: `${(y / 180) * 100}%`,
                      animation: `buntingSway ${
                        motionConfig.speed === 'slow'
                          ? '4.8s'
                          : motionConfig.speed === 'fast'
                          ? '2.2s'
                          : '3.4s'
                      } ease-in-out infinite alternate`,
                      animationDelay: `${swayDelay}s`,
                      transform: `rotate(${angle * 0.45}deg)`,
                    }}
                  >
                    {/* Hanging String Pin & Suspension Thread extending flag lower */}
                    <div className="w-[1.5px] h-3 sm:h-4 bg-gradient-to-b from-yellow-300 to-yellow-500 opacity-90 shadow-sm" />

                    {/* Pennant Flag with Deep Drop Shadow */}
                    <svg
                      width="30"
                      height="46"
                      viewBox="0 0 30 46"
                      className="drop-shadow-[0_6px_10px_rgba(0,0,0,0.5)] transition-transform hover:scale-110"
                    >
                      {/* Flag Body Triangle */}
                      <polygon
                        points="0,0 30,0 15,46"
                        fill={isGreen ? '#00401A' : '#ffffff'}
                        stroke={isGreen ? '#10b981' : '#cbd5e1'}
                        strokeWidth="1"
                      />

                      {/* Crescent & Star on dark green flags */}
                      {isGreen && (
                        <g transform="translate(15, 17) scale(0.65)">
                          {/* Moon Disc */}
                          <circle cx="0" cy="0" r="7.5" fill="#ffffff" />
                          <circle cx="2.2" cy="-1.8" r="6" fill="#00401A" />
                          {/* Five-pointed star */}
                          <polygon
                            points="3.5,-4 4.5,-1 8,-1 5,1 6,4.5 3.5,2.5 1,4.5 2,1 -1,-1 2.5,-1"
                            fill="#ffffff"
                            transform="scale(0.7) translate(3, -3)"
                          />
                        </g>
                      )}

                      {/* Emerald Star motif on white flags */}
                      {!isGreen && (
                        <g transform="translate(15, 15) scale(0.55)">
                          <polygon
                            points="0,-9 2.8,-2.8 9,-2.8 4,1.8 6,8 0,4 -6,8 -4,1.8 -9,-2.8 -2.8,-2.8"
                            fill={isAlt ? '#00401A' : '#059669'}
                          />
                        </g>
                      )}

                      {/* Subtle Top Stitching Line */}
                      <line x1="0" y1="2" x2="30" y2="2" stroke="rgba(251,191,36,0.6)" strokeWidth="1" />
                    </svg>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* 2. LIVE WAVING PAKISTANI FLAG MOTION BADGE */}
      {motionConfig.showFloatingMotif && (
        <aside
          aria-label="Pakistan National Flag Badge"
          className="fixed top-24 sm:top-28 right-3 sm:right-6 pointer-events-auto z-40 group"
        >
          <div className="relative flex items-center gap-2 p-1.5 sm:p-2 rounded-xl bg-emerald-950/85 backdrop-blur-md border border-emerald-500/40 shadow-[0_8px_25px_rgba(0,64,26,0.5)] hover:border-emerald-400 transition-all duration-300">
            {/* Waving Animated Flag Canvas / SVG */}
            <div className="relative w-14 h-9 sm:w-18 sm:h-11 rounded overflow-hidden shadow-inner flex border border-emerald-400/40">
              {/* White Hoist Bar (1/4th width) */}
              <div className="w-[28%] h-full bg-white relative z-10 shadow-[inset_-2px_0_4px_rgba(0,0,0,0.15)]" />

              {/* Dark Green Field (3/4th width) with Crescent and 5-Pointed Star */}
              <div className="w-[72%] h-full bg-[#00401A] relative flex items-center justify-center overflow-hidden">
                {/* Crescent & Star */}
                <svg viewBox="0 0 100 100" className="w-7 h-7 sm:w-9 sm:h-9 relative z-10">
                  {/* Moon Disc */}
                  <circle cx="50" cy="50" r="28" fill="#ffffff" />
                  {/* Moon Shadow cutout */}
                  <circle cx="59" cy="42" r="23" fill="#00401A" />
                  {/* Five-pointed star tilted towards corner */}
                  <g transform="translate(64, 40) rotate(-22)">
                    <polygon
                      points="0,-12 3.5,-3.5 12,-3.5 5,2 7.5,10 0,5 -7.5,10 -5,2 -12,-3.5 -3.5,-3.5"
                      fill="#ffffff"
                    />
                  </g>
                </svg>

                {/* Animated Wave Displacement Shimmer Overlay */}
                <div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-black/25 mix-blend-overlay"
                  style={{
                    animation: 'flagRipple 2.4s ease-in-out infinite',
                    backgroundSize: '200% 100%',
                  }}
                />
              </div>

              {/* Top and Bottom Flag Edge Folds */}
              <div className="absolute inset-0 pointer-events-none shadow-[inset_0_1px_1px_rgba(255,255,255,0.4),inset_0_-1px_2px_rgba(0,0,0,0.6)]" />
            </div>

            {/* Elegant Tag label */}
            <div className="hidden sm:flex flex-col pr-1.5">
              <span className="text-[10px] font-bold text-emerald-300 tracking-wider uppercase flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping inline-block" />
                14 August
              </span>
              <span className="text-[11px] font-semibold text-white tracking-tight">
                Pakistan Zindabad
              </span>
            </div>
          </div>
        </aside>
      )}

      {/* 3. FLOATING EMERALD CRESCENT & STAR AMBIENT PARTICLES */}
      {motionConfig.showParticles && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {Array.from({ length: 14 }).map((_, i) => {
            const left = (i * 7 + 4) % 96;
            const size = 12 + (i % 4) * 4;
            const duration = 12 + (i % 6) * 3;
            const delay = (i * 1.3).toFixed(1);

            return (
              <div
                key={i}
                className="absolute text-emerald-400/35"
                style={{
                  left: `${left}%`,
                  bottom: '-30px',
                  width: `${size}px`,
                  height: `${size}px`,
                  animation: `floatUpwards ${duration}s linear infinite`,
                  animationDelay: `${delay}s`,
                }}
              >
                {i % 2 === 0 ? (
                  <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full opacity-60">
                    <path d="M12 2a10 10 0 1 0 10 10 7.5 7.5 0 0 1-10-10z" />
                  </svg>
                ) : (
                  <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full opacity-70">
                    <polygon points="12 2 15 9 22 9 17 14 19 21 12 17 5 21 7 14 2 9 9 9" />
                  </svg>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
