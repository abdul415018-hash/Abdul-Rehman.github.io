import React from 'react';
import { TemplateMotionConfig } from '../../data/templates';

interface Props {
  motionConfig: TemplateMotionConfig;
}

export const ExecutiveSlateOverlay: React.FC<Props> = ({ motionConfig }) => {
  if (!motionConfig.enabled) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-40 overflow-hidden">
      {/* Top Polished Titanium Shimmer Hairline */}
      {motionConfig.showGarland && (
        <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-75 shadow-[0_1px_12px_rgba(56,189,248,0.6)] animate-pulse" />
      )}

      {/* Floating Executive Monogram Stamp */}
      {motionConfig.showFloatingMotif && (
        <div className="absolute top-6 right-5 sm:right-10 flex flex-col items-end gap-1 pointer-events-none">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-700/80 shadow-[0_8px_20px_rgba(0,0,0,0.5)] backdrop-blur-md">
            <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#38bdf8] animate-ping" />
            <span className="text-[11px] font-mono font-bold text-slate-100 tracking-wider">
              EXECUTIVE // PRIME
            </span>
          </div>
          <span className="text-[9px] font-mono text-cyan-400/80 tracking-widest px-1">
            VERIFIED STUDIO 2026
          </span>
        </div>
      )}

      {/* Ambient Cool Steel Floating Specks */}
      {motionConfig.showParticles && (
        <div className="absolute inset-0 pointer-events-none">
          <div
            className="absolute top-1/3 left-[6%] w-1.5 h-1.5 rounded-full bg-cyan-400/30 blur-[1px] animate-[pulse_4s_ease-in-out_infinite]"
          />
          <div
            className="absolute top-2/3 right-[8%] w-2 h-2 rounded-full bg-indigo-400/25 blur-[1px] animate-[pulse_5s_ease-in-out_infinite]"
          />
          <div
            className="absolute bottom-1/4 left-[14%] w-1 h-1 rounded-full bg-slate-300/40"
          />
        </div>
      )}
    </div>
  );
};
