import React from 'react';
import { TemplateMotionConfig } from '../../data/templates';

interface Props {
  motionConfig: TemplateMotionConfig;
}

export const CyberFutureOverlay: React.FC<Props> = ({ motionConfig }) => {
  if (!motionConfig.enabled) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden" aria-hidden="true">
      {/* 1. TOP NEON SCANNING LASER BEAM */}
      {motionConfig.showGarland && (
        <div className="absolute top-0 left-0 right-0 h-[2.5px] bg-cyan-900/40 overflow-hidden">
          <div
            className="w-2/5 h-full bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_12px_#22d3ee]"
            style={{ animation: 'scanBeam 3s ease-in-out infinite alternate' }}
          />
        </div>
      )}

      {/* 2. HUD CORNER BRACKETS & SYSTEM STATUS */}
      {motionConfig.showFloatingMotif && (
        <div className="hidden lg:block">
          {/* Top-Right HUD Bracket */}
          <div className="absolute top-20 right-8 w-16 h-16 border-t-2 border-r-2 border-cyan-400/60 pointer-events-none shadow-[0_0_15px_rgba(6,182,212,0.3)]">
            <span className="absolute top-1 right-2 text-[9px] font-mono text-cyan-400 tracking-widest">
              HUD // 01
            </span>
          </div>

          {/* Bottom-Left HUD Bracket */}
          <div className="absolute bottom-12 left-8 w-16 h-16 border-b-2 border-l-2 border-purple-500/60 pointer-events-none shadow-[0_0_15px_rgba(168,85,247,0.3)]">
            <span className="absolute bottom-1 left-2 text-[9px] font-mono text-purple-400 tracking-widest">
              SYS // OK
            </span>
          </div>

          {/* Corner Tech Indicator Badge */}
          <aside
            aria-label="Cyber Spatial Protocol Badge"
            className="fixed top-24 right-12 pointer-events-auto z-40 hidden xl:block"
          >
            <div className="px-3 py-1 rounded bg-slate-950/80 border border-cyan-400/50 shadow-[0_0_15px_rgba(6,182,212,0.3)] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span className="text-[10px] font-mono text-cyan-300 tracking-widest">
                CYBER-DEPTH // ONLINE
              </span>
            </div>
          </aside>
        </div>
      )}

      {/* 3. CYBER KINETIC PARTICLES */}
      {motionConfig.showParticles && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {Array.from({ length: 16 }).map((_, i) => {
            const left = (i * 6.5 + 2) % 96;
            const size = 3 + (i % 3) * 2;
            const duration = 11 + (i % 4) * 3;
            const delay = (i * 0.9).toFixed(1);

            return (
              <div
                key={i}
                className="absolute rounded-full bg-cyan-400 shadow-[0_0_10px_#22d3ee]"
                style={{
                  left: `${left}%`,
                  bottom: '-25px',
                  width: `${size}px`,
                  height: `${size}px`,
                  animation: `floatUpwards ${duration}s linear infinite`,
                  animationDelay: `${delay}s`,
                }}
              />
            );
          })}
        </div>
      )}
    </div>
  );
};
