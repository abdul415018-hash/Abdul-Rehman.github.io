import React from 'react';
import { TemplateMotionConfig } from '../../data/templates';

interface Props {
  motionConfig: TemplateMotionConfig;
}

export const EidFitrOverlay: React.FC<Props> = ({ motionConfig }) => {
  if (!motionConfig.enabled) return null;

  const swingDuration =
    motionConfig.speed === 'slow' ? '5.5s' : motionConfig.speed === 'fast' ? '2.5s' : '3.8s';

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden" aria-hidden="true">
      {/* 1. HANGING CELESTIAL TURQUOISE & GOLD LANTERNS */}
      {motionConfig.showGarland && (
        <div className="absolute top-0 left-0 right-0 w-full flex justify-between px-6 sm:px-20 select-none">
          {[
            { left: '12%', chainHeight: 125, size: 48, delay: '0s' },
            { left: '35%', chainHeight: 90, size: 40, delay: '1.2s' },
            { left: '65%', chainHeight: 150, size: 52, delay: '0.6s' },
            { left: '88%', chainHeight: 105, size: 44, delay: '1.5s' },
          ].map((lantern, idx) => (
            <div
              key={idx}
              className="flex flex-col items-center"
              style={{
                transformOrigin: 'top center',
                animation: `lanternSwing ${swingDuration} ease-in-out infinite alternate`,
                animationDelay: lantern.delay,
              }}
            >
              <div
                className="w-[1px] bg-gradient-to-b from-teal-300 to-yellow-400 opacity-70"
                style={{ height: `${lantern.chainHeight}px` }}
              />
              <svg
                width={lantern.size}
                height={lantern.size * 1.3}
                viewBox="0 0 50 65"
                className="drop-shadow-[0_6px_14px_rgba(45,212,191,0.5)]"
              >
                <circle cx="25" cy="5" r="3.5" fill="none" stroke="#facc15" strokeWidth="2" />
                <path d="M16 10 L34 10 L30 18 L20 18 Z" fill="#0d9488" stroke="#facc15" strokeWidth="1" />
                <path d="M12 18 L38 18 L42 30 L8 30 Z" fill="#042f2e" stroke="#2dd4bf" strokeWidth="1.2" />
                <rect x="12" y="30" width="26" height="22" rx="3" fill="#0f766e" stroke="#facc15" strokeWidth="1.2" />
                <circle cx="25" cy="41" r="5" fill="#fef08a" className="animate-pulse" />
                <circle cx="25" cy="41" r="9" fill="#2dd4bf" opacity="0.35" />
                <path d="M16 52 L34 52 L28 60 L22 60 Z" fill="#0d9488" stroke="#facc15" strokeWidth="1" />
                <circle cx="25" cy="63" r="2" fill="#facc15" />
              </svg>
            </div>
          ))}
        </div>
      )}

      {/* 2. GLOWING CRESCENT MOON MOTIF WITH RADIANT STARDUST */}
      {motionConfig.showFloatingMotif && (
        <aside
          aria-label="Celestial Crescent Moon Motif"
          className="fixed top-18 sm:top-20 right-4 sm:right-10 pointer-events-auto z-40 group"
        >
          <div className="relative p-2.5 rounded-2xl bg-teal-950/70 backdrop-blur-md border border-teal-400/40 shadow-[0_10px_30px_rgba(45,212,191,0.35)] flex items-center gap-3">
            {/* Animated Golden Crescent Moon */}
            <div className="relative w-11 h-11 flex items-center justify-center">
              <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-[0_0_12px_rgba(250,204,21,0.85)]">
                <circle cx="50" cy="50" r="38" fill="#facc15" />
                <circle cx="62" cy="42" r="34" fill="#04222a" />
                <polygon
                  points="50,28 53,35 60,35 55,40 57,47 50,43 43,47 45,40 40,35 47,35"
                  fill="#ffffff"
                  className="animate-pulse"
                />
              </svg>
              {/* Moon Glow Aura */}
              <div className="absolute inset-0 rounded-full blur-md bg-yellow-400/30 animate-pulse pointer-events-none" />
            </div>

            <div className="hidden sm:flex flex-col pr-1">
              <span className="text-[10px] font-bold text-yellow-400 uppercase tracking-wider">
                Eid ul-Fitr
              </span>
              <span className="text-xs font-semibold text-teal-100 tracking-tight">
                Festive Radiance
              </span>
            </div>
          </div>
        </aside>
      )}

      {/* 3. TWINKLING STARDUST & SPARKS */}
      {motionConfig.showParticles && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {Array.from({ length: 16 }).map((_, i) => {
            const left = (i * 6.8 + 3) % 96;
            const top = (i * 8.2 + 5) % 85;
            const delay = (i * 0.7).toFixed(1);

            return (
              <div
                key={i}
                className="absolute text-yellow-300/60 animate-ping"
                style={{
                  left: `${left}%`,
                  top: `${top}%`,
                  width: `${6 + (i % 3) * 4}px`,
                  height: `${6 + (i % 3) * 4}px`,
                  animationDuration: `${2 + (i % 3)}s`,
                  animationDelay: `${delay}s`,
                }}
              >
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full">
                  <path d="M12 0l2 8 8 2-8 2-2 8-2-8-8-2 8-2z" />
                </svg>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
