import React from 'react';
import { TemplateMotionConfig } from '../../data/templates';

interface Props {
  motionConfig: TemplateMotionConfig;
}

export const RamadanOverlay: React.FC<Props> = ({ motionConfig }) => {
  if (!motionConfig.enabled) return null;

  const swingDuration =
    motionConfig.speed === 'slow' ? '6.5s' : motionConfig.speed === 'fast' ? '3s' : '4.5s';

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden" aria-hidden="true">
      {/* 1. ROTATING ISLAMIC ARABESQUE GEOMETRIC LATTICE BACKDROP WATERMARK */}
      {motionConfig.showParticles && (
        <div
          className="absolute -top-[10%] -right-[10%] w-[550px] h-[550px] opacity-[0.045] pointer-events-none"
          style={{ animation: 'spinSlow 120s linear infinite' }}
        >
          <svg viewBox="0 0 200 200" className="w-full h-full text-amber-300 fill-current">
            <g transform="translate(100, 100)">
              {Array.from({ length: 8 }).map((_, i) => (
                <g key={i} transform={`rotate(${i * 45})`}>
                  <path d="M0,0 L20,-60 L0,-90 L-20,-60 Z" />
                  <circle cx="0" cy="-60" r="10" fill="none" stroke="currentColor" strokeWidth="2" />
                </g>
              ))}
              <circle cx="0" cy="0" r="35" fill="none" stroke="currentColor" strokeWidth="3" />
            </g>
          </svg>
        </div>
      )}

      {/* 2. STAGGERED HANGING RAMADAN FANOUS LAMPS */}
      {motionConfig.showGarland && (
        <div className="absolute top-0 left-0 right-0 w-full flex justify-around px-4 sm:px-16 select-none">
          {[
            { left: '14%', chainHeight: 140, size: 50, delay: '0s' },
            { left: '38%', chainHeight: 105, size: 44, delay: '1.2s' },
            { left: '64%', chainHeight: 165, size: 56, delay: '0.5s' },
            { left: '86%', chainHeight: 120, size: 46, delay: '1.8s' },
          ].map((lamp, idx) => (
            <div
              key={idx}
              className="flex flex-col items-center"
              style={{
                transformOrigin: 'top center',
                animation: `lanternSwing ${swingDuration} ease-in-out infinite alternate`,
                animationDelay: lamp.delay,
              }}
            >
              {/* Twisted hanging cord */}
              <div
                className="w-[1.5px] bg-gradient-to-b from-amber-400 via-indigo-400 to-amber-500 opacity-75"
                style={{ height: `${lamp.chainHeight}px` }}
              />

              {/* Ornate Ramadan Fanous Lamp */}
              <div className="relative">
                <svg
                  width={lamp.size}
                  height={lamp.size * 1.45}
                  viewBox="0 0 50 72"
                  className="drop-shadow-[0_10px_20px_rgba(251,191,36,0.45)]"
                >
                  {/* Top ring */}
                  <circle cx="25" cy="4" r="3.5" fill="none" stroke="#fbbf24" strokeWidth="1.8" />
                  {/* Dome cap */}
                  <path d="M14 9 L36 9 L32 17 L18 17 Z" fill="#4338ca" stroke="#fbbf24" strokeWidth="1" />
                  <path d="M10 17 L40 17 L44 26 L6 26 Z" fill="#1e1b4b" stroke="#f59e0b" strokeWidth="1.2" />

                  {/* Glass lamp chamber */}
                  <rect x="8" y="26" width="34" height="30" rx="3" fill="#181434" stroke="#fbbf24" strokeWidth="1.2" />

                  {/* Arched stained glass windows */}
                  <path d="M12 40 Q16 29 20 40 L20 52 L12 52 Z" fill="#f59e0b" opacity="0.6" />
                  <path d="M22 38 Q25 27 28 38 L28 52 L22 52 Z" fill="#fef08a" opacity="0.85" className="animate-pulse" />
                  <path d="M30 40 Q34 29 38 40 L38 52 L30 52 Z" fill="#f59e0b" opacity="0.6" />

                  {/* Base and dangling jewel */}
                  <path d="M10 56 L40 56 L34 64 L16 64 Z" fill="#312e81" stroke="#fbbf24" strokeWidth="1" />
                  <circle cx="25" cy="68" r="2.5" fill="#fbbf24" />
                </svg>

                {/* Warm amber heart glow */}
                <div
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full blur-xl bg-amber-400/30 pointer-events-none"
                  style={{ animation: 'lanternGlow 3s ease-in-out infinite alternate' }}
                />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 3. FLOATING BOKEH PARTICLES */}
      {motionConfig.showParticles && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {Array.from({ length: 14 }).map((_, i) => {
            const left = (i * 7.5 + 4) % 95;
            const size = 8 + (i % 4) * 4;
            const duration = 15 + (i % 5) * 3;
            const delay = (i * 1.2).toFixed(1);

            return (
              <div
                key={i}
                className="absolute rounded-full bg-amber-300/35 blur-[1px]"
                style={{
                  left: `${left}%`,
                  bottom: '-25px',
                  width: `${size}px`,
                  height: `${size}px`,
                  animation: `floatUpwards ${duration}s linear infinite`,
                  animationDelay: `${delay}s`,
                }}
              />
            );
          })}
        </div>
      )}
    </div>
  );
};
