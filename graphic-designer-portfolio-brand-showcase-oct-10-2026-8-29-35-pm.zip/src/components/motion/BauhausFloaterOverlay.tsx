import React from 'react';
import { TemplateMotionConfig } from '../../data/templates';

interface Props {
  motionConfig: TemplateMotionConfig;
}

export const BauhausFloaterOverlay: React.FC<Props> = ({ motionConfig }) => {
  if (!motionConfig.enabled) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden" aria-hidden="true">
      {/* 1. TOP BOLD CONSTRUCTIVIST PRIMARY COLOR FRIEZE */}
      {motionConfig.showGarland && (
        <div className="absolute top-0 left-0 right-0 h-2 flex select-none border-b-2 border-black z-50">
          <div className="flex-1 bg-yellow-400 border-r-2 border-black" />
          <div className="flex-1 bg-red-600 border-r-2 border-black" />
          <div className="flex-1 bg-blue-600 border-r-2 border-black" />
          <div className="flex-1 bg-black" />
        </div>
      )}

      {/* 2. REVOLVING 3D BAUHAUS GEOMETRIC PRIMITIVES */}
      {motionConfig.showParticles && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {/* Isometric Cadmium Yellow Cube */}
          <div
            className="absolute top-28 left-6 sm:left-12 w-14 h-14 opacity-90"
            style={{
              animation: 'spinSlow 32s linear infinite',
            }}
          >
            <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-[5px_5px_0px_#000]">
              <polygon points="50,15 90,38 50,60 10,38" fill="#facc15" stroke="#000" strokeWidth="3.5" />
              <polygon points="10,38 50,60 50,95 10,72" fill="#ca8a04" stroke="#000" strokeWidth="3.5" />
              <polygon points="50,60 90,38 90,72 50,95" fill="#eab308" stroke="#000" strokeWidth="3.5" />
            </svg>
          </div>

          {/* Vermilion Red Concentric Target / Disc */}
          <div
            className="absolute top-[42%] right-6 sm:right-14 w-12 h-12 opacity-90"
            style={{
              animation: 'spinSlow 38s linear infinite reverse',
            }}
          >
            <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-[4px_4px_0px_#000]">
              <circle cx="50" cy="50" r="42" fill="#ef4444" stroke="#000" strokeWidth="4" />
              <circle cx="50" cy="50" r="24" fill="#ffffff" stroke="#000" strokeWidth="3" />
              <circle cx="50" cy="50" r="10" fill="#000000" />
            </svg>
          </div>

          {/* Cobalt Blue Isometric Triangular Prism */}
          <div
            className="absolute bottom-28 left-8 sm:left-20 w-14 h-14 opacity-85"
            style={{
              animation: 'spinSlow 44s linear infinite',
            }}
          >
            <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-[5px_5px_0px_#000]">
              <polygon points="50,12 92,86 8,86" fill="#2563eb" stroke="#000" strokeWidth="4" />
              <line x1="50" y1="12" x2="50" y2="86" stroke="#000" strokeWidth="3" />
              <polygon points="50,12 8,86 50,86" fill="#1d4ed8" />
            </svg>
          </div>
        </div>
      )}

      {/* 3. TACTILE CONSTRUCTIVIST CORNER BADGE */}
      {motionConfig.showFloatingMotif && (
        <aside
          aria-label="Bauhaus Constructivist Badge"
          className="fixed top-24 right-4 sm:right-10 pointer-events-auto z-40 hidden sm:block"
        >
          <div className="px-3.5 py-1.5 bg-yellow-400 text-black font-mono font-black text-xs uppercase tracking-wider border-2 border-black shadow-[4px_4px_0px_#000]">
            ⚡ BAUHAUS WEIMAR // 1919
          </div>
        </aside>
      )}
    </div>
  );
};
