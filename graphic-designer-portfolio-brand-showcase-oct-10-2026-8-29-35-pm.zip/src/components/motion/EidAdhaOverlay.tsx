import React from 'react';
import { TemplateMotionConfig } from '../../data/templates';

interface Props {
  motionConfig: TemplateMotionConfig;
}

export const EidAdhaOverlay: React.FC<Props> = ({ motionConfig }) => {
  if (!motionConfig.enabled) return null;

  const swingDuration =
    motionConfig.speed === 'slow' ? '6s' : motionConfig.speed === 'fast' ? '2.8s' : '4.2s';

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden" aria-hidden="true">
      {/* 1. HANGING TRADITIONAL BRASS & EMERALD LANTERNS (FANOOS) */}
      {motionConfig.showGarland && (
        <div className="absolute top-0 left-0 right-0 w-full flex justify-around px-4 sm:px-12 select-none">
          {[
            { left: '10%', chainHeight: 110, size: 46, delay: '0s' },
            { left: '26%', chainHeight: 155, size: 54, delay: '0.8s' },
            { left: '50%', chainHeight: 120, size: 44, delay: '1.4s' },
            { left: '74%', chainHeight: 175, size: 58, delay: '0.4s' },
            { left: '90%', chainHeight: 130, size: 46, delay: '1.1s' },
          ].map((lantern, idx) => (
            <div
              key={idx}
              className="flex flex-col items-center"
              style={{
                transformOrigin: 'top center',
                animation: `lanternSwing ${swingDuration} ease-in-out infinite alternate`,
                animationDelay: lantern.delay,
              }}
            >
              {/* Golden hanging chain with delicate links */}
              <div
                className="w-[1.5px] bg-gradient-to-b from-amber-400 via-amber-600 to-amber-500 opacity-80"
                style={{ height: `${lantern.chainHeight}px` }}
              />

              {/* Lantern Body */}
              <div className="relative group">
                <svg
                  width={lantern.size}
                  height={lantern.size * 1.4}
                  viewBox="0 0 50 70"
                  className="drop-shadow-[0_8px_16px_rgba(217,119,6,0.45)]"
                >
                  {/* Top Crown Ring */}
                  <circle cx="25" cy="5" r="4" fill="none" stroke="#f59e0b" strokeWidth="2" />
                  <path d="M18 9 L32 9 L28 16 L22 16 Z" fill="#d97706" />

                  {/* Lantern Dome */}
                  <path d="M12 16 Q25 10 38 16 L44 26 L6 26 Z" fill="#b45309" stroke="#fbbf24" strokeWidth="1" />

                  {/* Central Glass Chamber with Warm Glowing Lamp */}
                  <rect x="10" y="26" width="30" height="28" rx="2" fill="#064e3b" stroke="#f59e0b" strokeWidth="1.5" />
                  
                  {/* Internal Glow Flame */}
                  <ellipse cx="25" cy="40" rx="6" ry="9" fill="#fef08a" opacity="0.9" className="animate-pulse" />
                  <ellipse cx="25" cy="40" rx="10" ry="12" fill="#f59e0b" opacity="0.4" />

                  {/* Decorative Islamic Lattice bars */}
                  <line x1="20" y1="26" x2="20" y2="54" stroke="#d97706" strokeWidth="1" />
                  <line x1="30" y1="26" x2="30" y2="54" stroke="#d97706" strokeWidth="1" />
                  <path d="M10 40 Q25 45 40 40" stroke="#f59e0b" strokeWidth="1" fill="none" />

                  {/* Lantern Base & Tassel */}
                  <path d="M12 54 L38 54 L32 62 L18 62 Z" fill="#b45309" stroke="#fbbf24" strokeWidth="1" />
                  <circle cx="25" cy="65" r="2.5" fill="#f59e0b" />
                </svg>

                {/* Ambient Radial Warm Glow Pulsing behind the lantern */}
                <div
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 rounded-full blur-xl bg-amber-500/25 pointer-events-none"
                  style={{ animation: 'lanternGlow 2.5s ease-in-out infinite alternate' }}
                />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 2. FLOATING SACRED GEOMETRIC STARBURST PARTICLES */}
      {motionConfig.showParticles && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {Array.from({ length: 12 }).map((_, i) => {
            const left = (i * 8.5 + 5) % 94;
            const size = 14 + (i % 3) * 5;
            const duration = 14 + (i % 5) * 3;
            const delay = (i * 1.5).toFixed(1);

            return (
              <div
                key={i}
                className="absolute text-amber-400/40"
                style={{
                  left: `${left}%`,
                  bottom: '-35px',
                  width: `${size}px`,
                  height: `${size}px`,
                  animation: `floatUpwards ${duration}s linear infinite`,
                  animationDelay: `${delay}s`,
                }}
              >
                {/* 8-Pointed Islamic Starburst (Khatim) */}
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full opacity-70">
                  <path d="M12 0l3 5 5-3-1 6 6 1-4 4 4 4-6 1 1 6-5-3-3 5-3-5-5 3 1-6-6-1 4-4-4-4 6-1-1-6 5 3z" />
                </svg>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
