import React, { useEffect, useState } from 'react';
import { X, FileText, Image as ImageIcon, Download, Printer, ExternalLink, Check, Eye } from 'lucide-react';
import { PortfolioData } from '../data/portfolioData';

interface DownloadCVModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: PortfolioData;
}

export const DownloadCVModal: React.FC<DownloadCVModalProps> = ({
  isOpen,
  onClose,
  data,
}) => {
  const [activeTab, setActiveTab] = useState<'options' | 'preview'>('options');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadFile = (url: string, filename: string) => {
    if (!url) {
      setActiveTab('preview');
      setTimeout(() => window.print(), 300);
      return;
    }
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const hasCustomPdf = Boolean(data.branding.cvPdfUrl);
  const hasCustomImage = Boolean(data.branding.cvImageUrl);
  const hasDirectUrl = Boolean(data.branding.cvDirectUrl);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/90 dark:bg-slate-950/90 light-theme:bg-slate-950/85 backdrop-blur-xl overflow-y-auto animate-in fade-in duration-200 print:p-0 print:bg-white">
      <div className="fixed inset-0 print:hidden" onClick={onClose} aria-hidden="true" />

      <div className="relative w-full max-w-2xl bg-slate-900/95 light-theme:bg-white/95 border border-cyan-500/30 rounded-3xl shadow-2xl shadow-black/80 overflow-hidden z-10 my-auto print:border-none print:shadow-none print:bg-white print:text-black">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-slate-800 light-theme:border-slate-200 bg-slate-950/70 light-theme:bg-slate-50 print:hidden">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-950/80 light-theme:bg-cyan-100 flex items-center justify-center text-cyan-400 light-theme:text-cyan-700">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white light-theme:text-slate-900">Download Curriculum Vitae</h3>
              <p className="text-[11px] text-slate-400 light-theme:text-slate-500">Select your preferred CV download format</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab(activeTab === 'options' ? 'preview' : 'options')}
              className="text-xs text-cyan-400 light-theme:text-cyan-600 hover:text-cyan-300 underline cursor-pointer hidden sm:block"
            >
              {activeTab === 'options' ? 'Interactive CV Preview' : 'Download Options'}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-white light-theme:hover:text-slate-900 hover:bg-slate-800 light-theme:hover:bg-slate-200 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-8 space-y-6 max-h-[80vh] overflow-y-auto">
          
          {activeTab === 'options' ? (
            <div className="space-y-6">
              <p className="text-xs sm:text-sm text-slate-300 light-theme:text-slate-600 leading-relaxed text-center max-w-md mx-auto">
                Download <span className="font-semibold text-white light-theme:text-slate-900">{data.branding.name}</span>&apos;s professional graphic design resume and credentials:
              </p>

              {/* Prominent Download Format Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Option 1: PDF Document */}
                <div className="p-5 rounded-2xl bg-slate-950/60 light-theme:bg-slate-50 border border-cyan-500/30 hover:border-cyan-400/70 transition-all flex flex-col justify-between group">
                  <div>
                    <div className="w-12 h-12 rounded-2xl bg-cyan-950/80 light-theme:bg-cyan-100 border border-cyan-500/40 light-theme:border-cyan-300 flex items-center justify-center text-cyan-400 light-theme:text-cyan-700 mb-3 group-hover:scale-105 transition-transform">
                      <FileText className="w-6 h-6" />
                    </div>
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="text-base font-bold text-white light-theme:text-slate-900">
                        PDF Document
                      </h4>
                      {hasCustomPdf && (
                        <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-800/40">
                          Custom PDF
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 light-theme:text-slate-500 mb-4 leading-relaxed">
                      {hasCustomPdf
                        ? 'Designer-uploaded customized PDF curriculum vitae.'
                        : 'Vector-rendered printable PDF format for print & HR records.'}
                    </p>
                  </div>

                  <button
                    onClick={() =>
                      handleDownloadFile(
                        data.branding.cvPdfUrl,
                        `${data.branding.name.replace(/\s+/g, '_')}_CV.pdf`
                      )
                    }
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-cyan-400 to-cyan-300 hover:from-cyan-300 hover:to-white shadow-md shadow-cyan-500/25 transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>{hasCustomPdf ? 'Download PDF Document' : 'Generate & Print PDF'}</span>
                  </button>
                </div>

                {/* Option 2: Image Format (JPG / PNG) */}
                <div className="p-5 rounded-2xl bg-slate-950/60 light-theme:bg-slate-50 border border-blue-500/30 hover:border-blue-400/70 transition-all flex flex-col justify-between group">
                  <div>
                    <div className="w-12 h-12 rounded-2xl bg-blue-950/80 light-theme:bg-sky-100 border border-blue-500/40 light-theme:border-sky-300 flex items-center justify-center text-blue-400 light-theme:text-sky-700 mb-3 group-hover:scale-105 transition-transform">
                      <ImageIcon className="w-6 h-6" />
                    </div>
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="text-base font-bold text-white light-theme:text-slate-900">
                        High-Res Image
                      </h4>
                      {hasCustomImage && (
                        <span className="text-[10px] font-semibold text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded-full border border-cyan-800/40">
                          Uploaded Image
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 light-theme:text-slate-500 mb-4 leading-relaxed">
                      {hasCustomImage
                        ? 'High-resolution graphic resume image for quick preview.'
                        : 'Visual graphic format for portfolio presentation and instant review.'}
                    </p>
                  </div>

                  <button
                    onClick={() =>
                      handleDownloadFile(
                        data.branding.cvImageUrl || data.branding.cvPdfUrl,
                        `${data.branding.name.replace(/\s+/g, '_')}_CV.jpg`
                      )
                    }
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-xs font-bold text-white bg-slate-800 light-theme:bg-slate-900 hover:bg-slate-700 border border-slate-700 hover:border-blue-400 transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4 text-cyan-400" />
                    <span>Download CV Image</span>
                  </button>
                </div>

              </div>

              {/* Optional External Link if provided by Admin */}
              {hasDirectUrl && (
                <div className="p-3.5 rounded-xl bg-slate-950/80 light-theme:bg-slate-100 border border-slate-800 light-theme:border-slate-300 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <ExternalLink className="w-4 h-4 text-cyan-400" />
                    <span className="text-xs text-slate-300 light-theme:text-slate-700 font-medium">
                      Cloud / Portfolio Resume Link:
                    </span>
                  </div>
                  <a
                    href={data.branding.cvDirectUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs font-semibold text-cyan-400 hover:underline"
                  >
                    Open External CV &rarr;
                  </a>
                </div>
              )}

              {/* Direct Print / Preview trigger */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4 text-center">
                <button
                  onClick={() => setActiveTab('preview')}
                  className="inline-flex items-center gap-1.5 text-xs text-cyan-400 light-theme:text-cyan-600 hover:underline cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Preview Full Resume Details</span>
                </button>
                <span className="hidden sm:inline text-slate-600">&bull;</span>
                <button
                  onClick={handlePrint}
                  className="inline-flex items-center gap-1.5 text-xs text-slate-400 light-theme:text-slate-600 hover:text-cyan-400 transition-colors cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Directly (Ctrl+P)</span>
                </button>
              </div>
            </div>
          ) : (
            /* Printable CV View */
            <div className="space-y-6 text-slate-100 light-theme:text-slate-900">
              <div className="border-b border-slate-800 light-theme:border-slate-200 pb-4">
                <h1 className="text-2xl font-bold text-white light-theme:text-slate-900">{data.branding.name}</h1>
                <p className="text-sm text-cyan-400 light-theme:text-cyan-600 font-semibold">{data.hero.badgeText}</p>
                <p className="text-xs text-slate-400 light-theme:text-slate-500 mt-1">
                  {data.about.email} &middot; {data.contact.phone} &middot; {data.about.location}
                </p>
              </div>

              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400 light-theme:text-cyan-700 mb-1">
                  About &amp; Design Philosophy
                </h3>
                <p className="text-xs text-slate-300 light-theme:text-slate-700 leading-relaxed">{data.about.bioText}</p>
              </div>

              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400 light-theme:text-cyan-700 mb-2">
                  Specialized Software &amp; Tools
                </h3>
                <div className="grid grid-cols-2 gap-2">
                  {data.skills.map((s) => (
                    <div key={s.id} className="p-2 rounded-lg bg-slate-950 light-theme:bg-slate-100 border border-slate-800 light-theme:border-slate-200 text-xs">
                      <span className="font-semibold">{s.name}</span>
                      <span className="text-cyan-400 light-theme:text-cyan-600 font-bold block">{s.level}%</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-3 print:hidden">
                <button
                  onClick={handlePrint}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 transition-colors cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Document</span>
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-3.5 border-t border-slate-800 light-theme:border-slate-200 bg-slate-950/70 light-theme:bg-slate-50 print:hidden">
          <span className="text-xs text-slate-500">
            Managed directly in the Admin Control Panel
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl text-xs font-semibold text-slate-300 light-theme:text-slate-800 bg-slate-800 light-theme:bg-slate-200 hover:bg-slate-700 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
