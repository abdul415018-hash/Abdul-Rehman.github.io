import React, { useEffect, useState } from 'react';

export const MagneticCursor: React.FC = () => {
  const [position, setPosition] = useState({ x: -100, y: -100 });
  const [trailingPos, setTrailingPos] = useState({ x: -100, y: -100 });
  const [cursorMode, setCursorMode] = useState<'default' | 'view' | 'drag' | 'tilt' | 'zoom'>('default');
  const [isVisible, setIsVisible] = useState(false);
  const [isPointer, setIsPointer] = useState(false);

  useEffect(() => {
    // Check if device supports fine mouse pointer (disable on touch-only mobile devices)
    if (typeof window === 'undefined') return;
    const mediaQuery = window.matchMedia('(pointer: fine)');
    if (!mediaQuery.matches) return;

    const handleMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
      if (!isVisible) setIsVisible(true);

      // Check hovered element data attribute for custom cursor modes
      const target = e.target as HTMLElement | null;
      if (target) {
        const mode = target.closest('[data-cursor]')?.getAttribute('data-cursor') as
          | 'view'
          | 'drag'
          | 'tilt'
          | 'zoom'
          | null;
        if (mode) {
          setCursorMode(mode);
        } else {
          setCursorMode('default');
        }

        const isClickable = Boolean(
          target.closest('button') ||
            target.closest('a') ||
            target.closest('input') ||
            target.closest('textarea') ||
            target.closest('[role="button"]') ||
            window.getComputedStyle(target).cursor === 'pointer'
        );
        setIsPointer(isClickable);
      }
    };

    const handleMouseLeave = () => {
      setIsVisible(false);
    };

    const handleMouseEnter = () => {
      setIsVisible(true);
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('mouseenter', handleMouseEnter);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseenter', handleMouseEnter);
    };
  }, [isVisible]);

  // Physics lerp loop for the holographic trailing orb
  useEffect(() => {
    let animationFrameId: number;

    const updatePhysics = () => {
      setTrailingPos((prev) => {
        const dx = position.x - prev.x;
        const dy = position.y - prev.y;
        return {
          x: prev.x + dx * 0.18,
          y: prev.y + dy * 0.18,
        };
      });
      animationFrameId = requestAnimationFrame(updatePhysics);
    };

    animationFrameId = requestAnimationFrame(updatePhysics);
    return () => cancelAnimationFrame(animationFrameId);
  }, [position]);

  if (!isVisible) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-[9999] overflow-hidden transition-opacity duration-300">
      {/* Precision Core Dot */}
      <div
        className="fixed w-2 h-2 rounded-full bg-cyan-400 -translate-x-1/2 -translate-y-1/2 shadow-[0_0_12px_#38bdf8] transition-transform duration-75"
        style={{
          left: `${position.x}px`,
          top: `${position.y}px`,
          transform: `translate(-50%, -50%) scale(${isPointer ? 0.4 : 1})`,
        }}
      />

      {/* Spatial Holographic Magnetic Ring */}
      <div
        className={`fixed rounded-full -translate-x-1/2 -translate-y-1/2 flex items-center justify-center transition-all duration-150 ease-out backdrop-blur-[1px] ${
          cursorMode !== 'default'
            ? 'w-16 h-16 bg-gradient-to-tr from-cyan-500/30 via-purple-500/25 to-pink-500/30 border border-cyan-400/60 shadow-[0_0_25px_rgba(6,182,212,0.4)]'
            : isPointer
            ? 'w-12 h-12 bg-cyan-500/15 border border-cyan-400/50 scale-110 shadow-[0_0_15px_rgba(6,182,212,0.3)]'
            : 'w-8 h-8 border border-cyan-500/30 bg-cyan-500/5'
        }`}
        style={{
          left: `${trailingPos.x}px`,
          top: `${trailingPos.y}px`,
        }}
      >
        {cursorMode !== 'default' && (
          <span className="text-[9px] font-black tracking-widest text-white uppercase drop-shadow-md select-none font-mono">
            {cursorMode}
          </span>
        )}
      </div>
    </div>
  );
};
