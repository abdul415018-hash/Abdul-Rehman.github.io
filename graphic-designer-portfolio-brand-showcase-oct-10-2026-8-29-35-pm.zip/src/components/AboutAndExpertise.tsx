import React from 'react';
import { User, MapPin, Mail, Clock, ArrowRight, Palette } from 'lucide-react';
import { AboutConfig, SkillItem } from '../data/portfolioData';

interface AboutAndExpertiseProps {
  about: AboutConfig;
  skillsTitle: string;
  skills: SkillItem[];
  onOpenCVModal: () => void;
}

export const AboutAndExpertise: React.FC<AboutAndExpertiseProps> = ({
  about,
  skillsTitle,
  skills,
  onOpenCVModal,
}) => {
  return (
    <section id="about" className="py-16 sm:py-20 relative">
      <div id="skills" className="sr-only">Skills Anchor</div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Two-card layout matching reference image */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Card 1: About Me */}
          <div className="lg:col-span-5 glow-card p-6 sm:p-8 rounded-3xl flex flex-col justify-between border border-cyan-500/25">
            <div>
              {/* Card Header */}
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-cyan-950/80 light-theme:bg-cyan-100 border border-cyan-500/30 light-theme:border-cyan-300 flex items-center justify-center text-cyan-400 light-theme:text-cyan-700">
                  <User className="w-5 h-5" />
                </div>
                <h3 className="text-xl font-bold text-white light-theme:text-slate-900 tracking-tight">{about.sectionTitle}</h3>
              </div>

              {/* Bio Narrative */}
              <p className="text-sm sm:text-base text-slate-300 light-theme:text-slate-600 leading-relaxed mb-6">
                {about.bioText}
              </p>

              {/* Information Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-4 border-y border-slate-800/80 light-theme:border-slate-200 my-6">
                <div className="flex items-start gap-3">
                  <User className="w-4 h-4 text-cyan-400 light-theme:text-cyan-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-xs text-slate-400 light-theme:text-slate-500 font-medium block">Name</span>
                    <span className="text-sm font-semibold text-white light-theme:text-slate-900">{about.name}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-cyan-400 light-theme:text-cyan-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-xs text-slate-400 light-theme:text-slate-500 font-medium block">Location</span>
                    <span className="text-sm font-semibold text-white light-theme:text-slate-900">{about.location}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="w-4 h-4 text-cyan-400 light-theme:text-cyan-600 shrink-0 mt-0.5" />
                  <div className="overflow-hidden">
                    <span className="text-xs text-slate-400 light-theme:text-slate-500 font-medium block">Email</span>
                    <span className="text-sm font-semibold text-white light-theme:text-slate-900 truncate block" title={about.email}>
                      {about.email}
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="w-4 h-4 text-cyan-400 light-theme:text-cyan-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-xs text-slate-400 light-theme:text-slate-500 font-medium block">Availability</span>
                    <span className="text-xs font-semibold text-emerald-400 light-theme:text-emerald-600 flex items-center gap-1.5 mt-0.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span>{about.availability}</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Action button */}
            <div className="pt-2">
              <button
                onClick={onOpenCVModal}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold text-cyan-300 light-theme:text-cyan-800 bg-cyan-950/60 light-theme:bg-cyan-100/80 border border-cyan-800/60 light-theme:border-cyan-300 hover:bg-cyan-900/50 light-theme:hover:bg-cyan-200 hover:text-white light-theme:hover:text-cyan-950 transition-all cursor-pointer"
              >
                <span>{about.buttonText}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Card 2: My Expertise & Software Tools */}
          <div className="lg:col-span-7 glow-card p-6 sm:p-8 rounded-3xl flex flex-col justify-between border border-cyan-500/25">
            <div>
              {/* Card Header */}
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-blue-950/80 light-theme:bg-sky-100 border border-blue-500/30 light-theme:border-sky-300 flex items-center justify-center text-blue-400 light-theme:text-sky-700">
                  <Palette className="w-5 h-5" />
                </div>
                <h3 className="text-xl font-bold text-white light-theme:text-slate-900 tracking-tight">{skillsTitle}</h3>
              </div>

              {/* Progress Bars List */}
              <div className="space-y-4 sm:space-y-5">
                {skills.map((skill) => (
                  <div key={skill.id} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs sm:text-sm">
                      <span className="font-medium text-slate-200 light-theme:text-slate-800">{skill.name}</span>
                      <span className="font-bold text-cyan-400 light-theme:text-cyan-600 tabular-nums">{skill.level}%</span>
                    </div>
                    {/* Progress Bar Track */}
                    <div className="h-2 w-full bg-slate-900/90 light-theme:bg-slate-200 rounded-full overflow-hidden p-0.5 border border-slate-800 light-theme:border-slate-300">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-cyan-500 via-sky-400 to-blue-500 transition-all duration-700 shadow-sm shadow-cyan-400/50"
                        style={{ width: `${skill.level}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
