import React from 'react';
import { ArrowRight, MessageSquare, Briefcase, Layers, Star, PenTool, Mail, Linkedin, Globe, Sparkles, Compass } from 'lucide-react';
import { HeroConfig } from '../data/portfolioData';
import { Spatial3DTiltCard } from './Spatial3DTiltCard';

interface HeroProps {
  hero: HeroConfig;
}

export const Hero: React.FC<HeroProps> = ({ hero }) => {
  return (
    <section id="home" className="relative pt-28 pb-16 sm:pt-36 sm:pb-24 lg:pt-40 lg:pb-28 overflow-hidden">
      {/* Volumetric Holographic Refraction Ambient Orbs */}
      <div className="absolute top-1/4 left-1/3 -translate-x-1/2 -translate-y-1/2 w-[350px] sm:w-[650px] h-[350px] sm:h-[650px] bg-gradient-to-tr from-cyan-500/15 via-purple-500/10 to-pink-500/10 rounded-full blur-[110px] sm:blur-[150px] pointer-events-none -z-10 animate-pulse" />
      <div className="absolute top-1/3 right-5 sm:right-10 w-[260px] sm:w-[480px] h-[260px] sm:h-[480px] bg-gradient-to-br from-blue-600/15 via-indigo-500/10 to-cyan-400/10 rounded-full blur-[90px] sm:blur-[130px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          
          {/* Left Column: Kinetic Spatial Headline, Bio & Actions */}
          <div className="lg:col-span-7 flex flex-col items-start text-left z-10">
            {/* Holographic Pill Kicker Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/90 light-theme:bg-white/95 border border-cyan-500/40 text-cyan-400 light-theme:text-cyan-700 text-xs font-mono font-bold tracking-wider mb-5 shadow-[0_0_15px_rgba(6,182,212,0.25)]">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>{hero.badgeText}</span>
            </div>

            {/* Main Headline with Spatial Holographic Sheen */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white light-theme:text-slate-900 tracking-tight leading-[1.12] mb-5 max-w-2xl">
              {hero.headlinePrefix}{' '}
              <span className="holographic-text drop-shadow-[0_0_25px_rgba(6,182,212,0.35)]">
                {hero.headlineHighlight}
              </span>{' '}
              {hero.headlineSuffix}
            </h1>

            {/* Subtitle / Bio */}
            <p className="text-sm sm:text-base lg:text-lg text-slate-300 light-theme:text-slate-600 leading-relaxed max-w-xl mb-8">
              {hero.bioText}
            </p>

            {/* Action Buttons with 3D Holographic Glare */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 mb-9 w-full sm:w-auto">
              <a
                href={hero.primaryBtnLink || '#projects'}
                data-cursor="view"
                className="relative group overflow-hidden inline-flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-2xl font-black text-xs sm:text-sm text-slate-950 bg-gradient-to-r from-cyan-400 via-sky-300 to-cyan-200 hover:from-white hover:to-cyan-300 shadow-[0_10px_25px_rgba(6,182,212,0.35)] hover:shadow-[0_12px_30px_rgba(6,182,212,0.6)] transition-all duration-300 cursor-pointer text-center"
              >
                <span>{hero.primaryBtnText}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>

              <a
                href={hero.secondaryBtnLink || '#contact'}
                data-cursor="view"
                className="inline-flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-2xl font-bold text-xs sm:text-sm text-slate-100 light-theme:text-slate-800 bg-[#0c1024]/80 light-theme:bg-white/90 hover:bg-[#121833] light-theme:hover:bg-slate-100 border border-slate-700/80 light-theme:border-slate-300 hover:border-cyan-400 shadow-[0_8px_20px_rgba(0,0,0,0.4)] light-theme:shadow-[0_8px_20px_rgba(148,163,184,0.2)] transition-all duration-300 cursor-pointer text-center"
              >
                <MessageSquare className="w-4 h-4 text-cyan-400" />
                <span>{hero.secondaryBtnText}</span>
              </a>
            </div>

            {/* Social Channels Strip with Spatial Tactile Buttons */}
            <div className="flex items-center gap-3 pt-1">
              <a
                href={hero.socials.githubOrBehance}
                target="_blank"
                rel="noreferrer"
                data-cursor="view"
                className="w-10 h-10 rounded-xl bg-slate-900/90 light-theme:bg-white border border-slate-800 light-theme:border-slate-200 flex items-center justify-center text-slate-300 light-theme:text-slate-700 hover:text-cyan-400 hover:border-cyan-500/50 hover:shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all"
                title="Behance / Portfolio"
              >
                <span className="font-bold text-xs font-mono">Bē</span>
              </a>
              <a
                href={hero.socials.linkedin}
                target="_blank"
                rel="noreferrer"
                data-cursor="view"
                className="w-10 h-10 rounded-xl bg-slate-900/90 light-theme:bg-white border border-slate-800 light-theme:border-slate-200 flex items-center justify-center text-slate-300 light-theme:text-slate-700 hover:text-cyan-400 hover:border-cyan-500/50 hover:shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all"
                title="LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href={hero.socials.twitter}
                target="_blank"
                rel="noreferrer"
                data-cursor="view"
                className="w-10 h-10 rounded-xl bg-slate-900/90 light-theme:bg-white border border-slate-800 light-theme:border-slate-200 flex items-center justify-center text-slate-300 light-theme:text-slate-700 hover:text-cyan-400 hover:border-cyan-500/50 hover:shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all"
                title="Dribbble"
              >
                <Globe className="w-4 h-4" />
              </a>
              <a
                href={`mailto:${hero.socials.email}`}
                data-cursor="view"
                className="w-10 h-10 rounded-xl bg-slate-900/90 light-theme:bg-white border border-slate-800 light-theme:border-slate-200 flex items-center justify-center text-slate-300 light-theme:text-slate-700 hover:text-cyan-400 hover:border-cyan-500/50 hover:shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all"
                title="Send Email"
              >
                <Mail className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Right Column: 3D Perspective Tilt Card Designer Portrait */}
          <div className="lg:col-span-5 relative flex flex-col items-center">
            {/* Ambient cyan-purple backlight */}
            <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/30 via-purple-500/20 to-pink-500/20 rounded-3xl blur-2xl -z-10" />

            <div className="relative w-full max-w-[340px] sm:max-w-[410px]">
              {/* 3D Tilt Wrapper */}
              <Spatial3DTiltCard
                maxTilt={14}
                perspective={1100}
                dataCursor="tilt"
                className="cursor-grab active:cursor-grabbing"
              >
                <div className="relative rounded-3xl overflow-hidden spatial-surface p-2.5 sm:p-3 border border-cyan-500/35">
                  <div className="relative aspect-[4/4.8] rounded-2xl overflow-hidden bg-slate-950">
                    <img
                      src={hero.portraitImage}
                      alt="Graphic Designer Portrait"
                      className="w-full h-full object-cover object-top filter contrast-105"
                      loading="eager"
                    />
                    {/* Spatial Depth Gradient */}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent opacity-80" />

                    {/* Top Corner Foil Specular Chip */}
                    <div className="absolute top-3 left-3 flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950/85 light-theme:bg-white/90 backdrop-blur-md border border-cyan-400/50 text-[10px] font-mono font-bold text-cyan-300 light-theme:text-cyan-800">
                      <Compass className="w-3 h-3 text-cyan-400 animate-spin" style={{ animationDuration: '8s' }} />
                      <span>3D SPATIAL CANVAS</span>
                    </div>
                  </div>
                </div>
              </Spatial3DTiltCard>

              {/* Desktop Floating Badges (Visible on lg screens) */}
              <div className="hidden lg:block pointer-events-none">
                {/* Top-Right Badge */}
                <div className="absolute -top-3 -right-6 spatial-surface p-3 rounded-2xl border border-cyan-500/40 flex items-center gap-3 backdrop-blur-xl pointer-events-auto">
                  <div className="w-9 h-9 rounded-xl bg-cyan-950/90 light-theme:bg-cyan-100 border border-cyan-500/40 flex items-center justify-center text-cyan-400 light-theme:text-cyan-700 shrink-0">
                    <Briefcase className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-base font-black text-white light-theme:text-slate-900 tabular-nums leading-none">
                      {hero.stat1Value}
                    </div>
                    <div className="text-[11px] text-slate-400 light-theme:text-slate-500 font-medium">{hero.stat1Label}</div>
                  </div>
                </div>

                {/* Middle-Right Badge */}
                <div className="absolute top-28 -right-8 spatial-surface p-3 rounded-2xl border border-purple-500/40 flex items-center gap-3 backdrop-blur-xl pointer-events-auto">
                  <div className="w-9 h-9 rounded-xl bg-purple-950/90 light-theme:bg-purple-100 border border-purple-500/40 flex items-center justify-center text-purple-400 light-theme:text-purple-700 shrink-0">
                    <Layers className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-base font-black text-white light-theme:text-slate-900 tabular-nums leading-none">
                      {hero.stat2Value}
                    </div>
                    <div className="text-[11px] text-slate-400 light-theme:text-slate-500 font-medium">{hero.stat2Label}</div>
                  </div>
                </div>

                {/* Bottom-Right Badge */}
                <div className="absolute bottom-20 -right-6 spatial-surface p-3 rounded-2xl border border-pink-500/40 flex items-center gap-3 backdrop-blur-xl pointer-events-auto">
                  <div className="w-9 h-9 rounded-xl bg-pink-950/90 light-theme:bg-pink-100 border border-pink-500/40 flex items-center justify-center text-pink-400 light-theme:text-pink-700 shrink-0">
                    <Star className="w-4 h-4 fill-pink-400" />
                  </div>
                  <div>
                    <div className="text-base font-black text-white light-theme:text-slate-900 tabular-nums leading-none">
                      {hero.stat3Value}
                    </div>
                    <div className="text-[11px] text-slate-400 light-theme:text-slate-500 font-medium">{hero.stat3Label}</div>
                  </div>
                </div>
              </div>

              {/* Bottom Floating Banner */}
              <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-[92%] spatial-surface p-2.5 sm:p-3 rounded-2xl border border-cyan-500/40 flex items-center justify-center gap-2 text-center backdrop-blur-xl">
                <PenTool className="w-4 h-4 text-cyan-400 shrink-0" />
                <span className="text-[11px] sm:text-xs font-bold text-slate-200 light-theme:text-slate-800 tracking-wide font-mono">
                  {hero.bottomBannerText}
                </span>
              </div>
            </div>

            {/* Mobile Adaptive Stat Ribbon */}
            <div className="lg:hidden grid grid-cols-3 gap-2.5 w-full max-w-[340px] sm:max-w-[400px] mt-8">
              <div className="spatial-surface p-2.5 rounded-xl text-center border border-cyan-500/30">
                <div className="text-sm font-bold text-cyan-400 tabular-nums">{hero.stat1Value}</div>
                <div className="text-[10px] text-slate-400 light-theme:text-slate-500 leading-tight mt-0.5">{hero.stat1Label}</div>
              </div>
              <div className="spatial-surface p-2.5 rounded-xl text-center border border-purple-500/30">
                <div className="text-sm font-bold text-purple-400 tabular-nums">{hero.stat2Value}</div>
                <div className="text-[10px] text-slate-400 light-theme:text-slate-500 leading-tight mt-0.5">{hero.stat2Label}</div>
              </div>
              <div className="spatial-surface p-2.5 rounded-xl text-center border border-pink-500/30">
                <div className="text-sm font-bold text-pink-400 tabular-nums">{hero.stat3Value}</div>
                <div className="text-[10px] text-slate-400 light-theme:text-slate-500 leading-tight mt-0.5">{hero.stat3Label}</div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
