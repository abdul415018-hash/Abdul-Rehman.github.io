import React, { useState, useEffect } from 'react';
import { Download, Menu, X, Sparkles } from 'lucide-react';
import { BrandingConfig } from '../data/portfolioData';

interface NavbarProps {
  branding: BrandingConfig;
  onOpenCVModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ branding, onOpenCVModal }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'About', href: '#about' },
    { label: 'Skills', href: '#skills' },
    { label: 'Services', href: '#services' },
    { label: 'Showcase', href: '#projects' },
    { label: 'Process', href: '#process' },
    { label: 'Reviews', href: '#testimonials' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled
          ? 'py-2.5 sm:py-3'
          : 'py-4 sm:py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Floating Spatial Neomorphic Capsule Container */}
        <div
          className={`flex items-center justify-between gap-4 px-4 sm:px-6 py-2.5 rounded-2xl transition-all duration-300 ${
            scrolled
              ? 'bg-[#060813]/85 dark:bg-[#060813]/85 light-theme:bg-white/88 backdrop-blur-xl border border-cyan-500/30 shadow-[0_10px_30px_rgba(0,0,0,0.5)] light-theme:shadow-[0_10px_30px_rgba(148,163,184,0.25)]'
              : 'bg-[#060813]/40 dark:bg-[#060813]/40 light-theme:bg-white/50 backdrop-blur-md border border-cyan-500/15'
          }`}
        >
          {/* Brand Monogram with Holographic Foil Halo */}
          <a
            href="#home"
            className="flex items-center gap-2.5 sm:gap-3 group shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 rounded-lg"
          >
            <div className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-cyan-400 via-purple-500 to-pink-500 p-[1.5px] shadow-[0_0_15px_rgba(6,182,212,0.4)] group-hover:shadow-[0_0_22px_rgba(6,182,212,0.7)] transition-shadow">
              <div className="w-full h-full rounded-[10px] bg-[#060813] light-theme:bg-white flex items-center justify-center font-black text-sm tracking-widest text-cyan-400 light-theme:text-cyan-600 font-mono">
                {branding.initials || 'AT'}
              </div>
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold text-sm sm:text-base tracking-tight text-white light-theme:text-slate-900 group-hover:text-cyan-400 transition-colors flex items-center gap-1.5">
                {branding.name}
              </span>
              <span className="text-[10px] font-mono tracking-wider text-cyan-400/80 light-theme:text-cyan-600 hidden sm:block uppercase">
                Visual &amp; Brand Architecture
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-8 text-xs font-semibold tracking-wider uppercase text-slate-300 light-theme:text-slate-600 font-mono">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="hover:text-cyan-400 light-theme:hover:text-cyan-600 transition-colors relative py-1 hover:after:w-full after:w-0 after:h-[2px] after:bg-gradient-to-r after:from-cyan-400 after:to-purple-500 after:absolute after:bottom-0 after:left-0 after:transition-all after:duration-250"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Download CV CTA with Holographic Foil Sheen */}
            <button
              onClick={onOpenCVModal}
              data-cursor="view"
              className="relative group overflow-hidden flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-white bg-slate-900/90 light-theme:bg-slate-900 border border-cyan-500/40 hover:border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.25)] hover:shadow-[0_0_20px_rgba(6,182,212,0.5)] transition-all cursor-pointer whitespace-nowrap"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-pink-500/20 opacity-0 group-hover:opacity-100 transition-opacity" />
              <Download className="w-3.5 h-3.5 text-cyan-400 relative z-10" />
              <span className="relative z-10">Download CV</span>
              <Sparkles className="w-3 h-3 text-purple-400 relative z-10 hidden sm:block" />
            </button>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-slate-300 light-theme:text-slate-700 hover:text-cyan-400 hover:bg-slate-800/50 light-theme:hover:bg-slate-200/60 transition-colors cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile dropdown drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden mt-3 pt-3 pb-3 border border-cyan-500/30 bg-[#060813]/95 dark:bg-[#060813]/95 light-theme:bg-white/95 backdrop-blur-2xl rounded-2xl p-4 shadow-[0_20px_40px_rgba(0,0,0,0.6)] animate-in slide-in-from-top-2">
            <div className="flex flex-col gap-1.5">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3.5 py-2.5 rounded-xl text-xs font-mono tracking-wider uppercase font-semibold text-slate-200 light-theme:text-slate-800 hover:text-cyan-400 hover:bg-cyan-500/10 light-theme:hover:bg-cyan-50 transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
