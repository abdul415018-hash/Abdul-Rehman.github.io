import React, { useState, useRef, useCallback } from 'react';
import { ChevronsLeftRight, Sparkles, Wand2 } from 'lucide-react';

interface BeforeAfterSliderProps {
  beforeImage: string;
  afterImage: string;
  beforeLabel?: string;
  afterLabel?: string;
  aspectRatio?: string;
  className?: string;
}

export const BeforeAfterSlider: React.FC<BeforeAfterSliderProps> = ({
  beforeImage,
  afterImage,
  beforeLabel = 'Initial Sketch / Concept',
  afterLabel = 'Final 3D Vector Render',
  aspectRatio = 'aspect-[16/10]',
  className = '',
}) => {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMove = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPosition(percentage);
  }, []);

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length > 0) {
      handleMove(e.touches[0].clientX);
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      handleMove(e.clientX);
    }
  };

  const handleMouseDown = () => {
    setIsDragging(true);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onTouchMove={handleTouchMove}
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      data-cursor="drag"
      className={`relative select-none overflow-hidden rounded-2xl cursor-ew-resize border border-cyan-500/30 shadow-2xl shadow-black/40 ${aspectRatio} ${className}`}
    >
      {/* AFTER IMAGE (Bottom Layer - Final Masterpiece) */}
      <img
        src={afterImage}
        alt="After Masterpiece"
        className="absolute inset-0 w-full h-full object-cover pointer-events-none"
        loading="lazy"
      />

      {/* AFTER LABEL BADGE */}
      <div className="absolute top-3 right-3 z-10 flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950/80 light-theme:bg-white/85 backdrop-blur-md border border-cyan-500/40 text-[11px] font-bold text-cyan-300 light-theme:text-cyan-800 shadow-md">
        <Sparkles className="w-3 h-3 text-cyan-400" />
        <span>{afterLabel}</span>
      </div>

      {/* BEFORE IMAGE (Clipped Layer - Wireframe / Sketch) */}
      <div
        className="absolute inset-0 overflow-hidden pointer-events-none"
        style={{
          clipPath: `polygon(0 0, ${sliderPosition}% 0, ${sliderPosition}% 100%, 0 100%)`,
        }}
      >
        <img
          src={beforeImage}
          alt="Before Concept"
          className="absolute inset-0 w-full h-full object-cover filter contrast-125 grayscale"
          loading="lazy"
        />

        {/* Dynamic Blueprint/Grid Overlay for "Before" state */}
        <div className="absolute inset-0 bg-cyan-950/40 mix-blend-overlay bg-[linear-gradient(to_right,#0891b218_1px,transparent_1px),linear-gradient(to_bottom,#0891b218_1px,transparent_1px)] bg-[size:1.5rem_1.5rem]" />

        {/* BEFORE LABEL BADGE */}
        <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950/80 light-theme:bg-white/85 backdrop-blur-md border border-slate-700/60 light-theme:border-slate-300 text-[11px] font-bold text-slate-300 light-theme:text-slate-800 shadow-md">
          <Wand2 className="w-3 h-3 text-amber-400" />
          <span>{beforeLabel}</span>
        </div>
      </div>

      {/* DRAGGABLE SLIDER DIVIDER LINE */}
      <div
        className="absolute top-0 bottom-0 w-0.5 bg-gradient-to-b from-cyan-400 via-purple-400 to-pink-500 shadow-[0_0_15px_rgba(6,182,212,0.8)] z-20 pointer-events-none"
        style={{ left: `${sliderPosition}%` }}
      >
        {/* Holographic Center Grip Handle */}
        <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-10 h-10 rounded-full bg-slate-950/90 light-theme:bg-white/95 border-2 border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.6)] flex items-center justify-center text-cyan-300 pointer-events-auto cursor-ew-resize">
          <ChevronsLeftRight className="w-5 h-5 text-cyan-400 animate-pulse" />
        </div>
      </div>

      {/* Percentage hint pill at bottom */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-10 px-2.5 py-0.5 rounded-full bg-slate-950/70 light-theme:bg-white/80 backdrop-blur-md text-[10px] font-mono text-slate-400 light-theme:text-slate-600 border border-slate-800">
        Drag to compare ({Math.round(sliderPosition)}%)
      </div>
    </div>
  );
};
