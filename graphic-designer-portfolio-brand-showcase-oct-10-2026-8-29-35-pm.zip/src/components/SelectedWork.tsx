import React, { useState } from 'react';
import { LayoutGrid, ArrowRight, Sparkles, SlidersHorizontal, Eye } from 'lucide-react';
import { ProjectItem } from '../data/portfolioData';
import { Spatial3DTiltCard } from './Spatial3DTiltCard';
import { BeforeAfterSlider } from './BeforeAfterSlider';

interface SelectedWorkProps {
  projectsTitle: string;
  projects: ProjectItem[];
  onSelectProject: (project: ProjectItem) => void;
}

export const SelectedWork: React.FC<SelectedWorkProps> = ({
  projectsTitle,
  projects,
  onSelectProject,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [showSliderMode, setShowSliderMode] = useState<boolean>(false);

  // Extract distinct categories
  const categories = ['All', ...Array.from(new Set(projects.map((p) => p.category || 'Branding')))];

  const filteredProjects =
    selectedCategory === 'All'
      ? projects
      : projects.filter((p) => (p.category || 'Branding') === selectedCategory);

  // Fallback concept sketch image for interactive Before/After preview
  const conceptSketchUrl =
    'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=1200&q=80';

  return (
    <section id="projects" className="py-16 sm:py-24 relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-0 w-[450px] h-[450px] bg-cyan-500/10 rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="absolute bottom-10 right-0 w-[400px] h-[400px] bg-purple-600/10 rounded-full blur-[140px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with Holographic Accents */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 sm:mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/60 light-theme:bg-cyan-50 border border-cyan-500/30 text-cyan-400 light-theme:text-cyan-700 text-xs font-mono font-bold tracking-wider mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>SPATIAL SHOWCASE &amp; 3D ARCHITECTURE</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-white light-theme:text-slate-900 tracking-tight">
              {projectsTitle}
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 light-theme:text-slate-600 mt-2 max-w-lg">
              Interact with genuine physical perspective tilt, holographic foil reflections, and inspect artwork without cropping.
            </p>
          </div>

          {/* Interactive Mode & Filter Switcher */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Interactive Before/After mode toggle button */}
            <button
              onClick={() => setShowSliderMode(!showSliderMode)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold font-mono transition-all cursor-pointer border ${
                showSliderMode
                  ? 'bg-gradient-to-r from-cyan-400 to-purple-500 text-slate-950 border-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                  : 'bg-slate-900/80 light-theme:bg-white text-slate-300 light-theme:text-slate-700 border-slate-800 light-theme:border-slate-300 hover:border-cyan-400'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>{showSliderMode ? 'Back to 3D Cards' : 'Interactive Before/After Slider'}</span>
            </button>
          </div>
        </div>

        {/* Category Filter Pills (Tactile Neomorphic Pressed State) */}
        {!showSliderMode && (
          <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-bold font-mono tracking-wider transition-all whitespace-nowrap cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-cyan-500 text-slate-950 shadow-[0_0_15px_rgba(6,182,212,0.5)] scale-105'
                    : 'bg-slate-900/60 light-theme:bg-white/80 text-slate-400 light-theme:text-slate-600 border border-slate-800 light-theme:border-slate-300 hover:text-white light-theme:hover:text-slate-900 hover:border-cyan-500/40'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        )}

        {/* VIEW MODE 1: Interactive Before & After Transformation Slider Spotlight */}
        {showSliderMode ? (
          <div className="space-y-8 animate-in fade-in duration-300">
            <div className="p-4 sm:p-6 rounded-3xl spatial-surface border border-cyan-500/30">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-white light-theme:text-slate-900">
                    Interactive Transformation Showcase
                  </h3>
                  <p className="text-xs text-slate-400 light-theme:text-slate-600">
                    Drag the holographic divider to compare vector wireframe drafts against final rendered packaging.
                  </p>
                </div>
                <span className="text-xs font-mono text-cyan-400 light-theme:text-cyan-600 font-bold bg-cyan-950/60 light-theme:bg-cyan-50 px-3 py-1 rounded-full border border-cyan-500/30">
                  Slide to Scrub
                </span>
              </div>

              {filteredProjects.length > 0 && (
                <BeforeAfterSlider
                  beforeImage={conceptSketchUrl}
                  afterImage={filteredProjects[0].image}
                  beforeLabel="Draft Vector Wireframe"
                  afterLabel={`${filteredProjects[0].title} (Final Render)`}
                  aspectRatio="aspect-[16/9]"
                />
              )}
            </div>

            <div className="text-center pt-2">
              <button
                onClick={() => setShowSliderMode(false)}
                className="text-xs font-mono text-cyan-400 light-theme:text-cyan-600 hover:underline cursor-pointer"
              >
                &larr; Return to full 3D interactive gallery
              </button>
            </div>
          </div>
        ) : (
          /* VIEW MODE 2: 3-Column Spatial 3D Perspective Tilt Grid */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {filteredProjects.map((project) => (
              <Spatial3DTiltCard
                key={project.id}
                maxTilt={12}
                perspective={1000}
                dataCursor="view"
                onClick={() => onSelectProject(project)}
                className="group cursor-pointer"
              >
                <div className="h-full spatial-surface rounded-3xl overflow-hidden border border-cyan-500/30 light-theme:border-cyan-500/40 flex flex-col">
                  {/* Artwork Image Container with Natural Aspect Ratio Preview */}
                  <div className="relative aspect-[16/10] overflow-hidden bg-slate-950 light-theme:bg-slate-100">
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-108"
                      loading="lazy"
                    />
                    
                    {/* Vignette & holographic shimmer */}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent opacity-85 light-theme:opacity-40" />

                    {/* Floating Holographic Badge */}
                    <div className="absolute top-3.5 right-3.5">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono font-bold text-cyan-300 light-theme:text-cyan-900 bg-slate-950/85 light-theme:bg-white/90 border border-cyan-500/40 backdrop-blur-md shadow-lg">
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                        <span>{project.badge || project.category || 'Brand Identity'}</span>
                      </span>
                    </div>

                    {/* Quick View Tag on Hover */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-slate-950/40 backdrop-blur-[2px]">
                      <span className="px-4 py-2 rounded-xl bg-cyan-400 text-slate-950 text-xs font-black font-mono shadow-[0_0_20px_rgba(6,182,212,0.8)] flex items-center gap-1.5">
                        <Eye className="w-3.5 h-3.5" />
                        <span>INSPECT ARTWORK</span>
                      </span>
                    </div>
                  </div>

                  {/* Card Description Footer */}
                  <div className="p-5 sm:p-6 flex flex-col justify-between flex-grow bg-slate-900/60 light-theme:bg-white/80">
                    <div>
                      <h3 className="text-lg font-black text-white light-theme:text-slate-900 group-hover:text-cyan-400 light-theme:group-hover:text-cyan-600 transition-colors mb-2">
                        {project.title}
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-300 light-theme:text-slate-600 leading-relaxed line-clamp-2 mb-4">
                        {project.description}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-slate-800/80 light-theme:border-slate-200 flex items-center justify-between gap-3">
                      {/* Tool and specialization tags */}
                      <div className="flex flex-wrap items-center gap-1.5">
                        {project.tags.map((tag, idx) => (
                          <span
                            key={idx}
                            className="text-[10px] font-mono font-semibold text-slate-400 light-theme:text-slate-600 bg-slate-950/80 light-theme:bg-slate-100 px-2 py-0.5 rounded-md border border-slate-800 light-theme:border-slate-200"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>

                      {/* Interactive arrow button */}
                      <div className="w-8 h-8 rounded-xl bg-cyan-950/70 light-theme:bg-cyan-100 border border-cyan-800/50 light-theme:border-cyan-300 flex items-center justify-center text-cyan-400 light-theme:text-cyan-700 group-hover:bg-cyan-400 group-hover:text-slate-950 shadow-[0_0_12px_rgba(6,182,212,0.3)] transition-all shrink-0">
                        <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-0.5 transition-transform" />
                      </div>
                    </div>
                  </div>
                </div>
              </Spatial3DTiltCard>
            ))}
          </div>
        )}

      </div>
    </section>
  );
};
