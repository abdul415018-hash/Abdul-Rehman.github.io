import React, { useState } from 'react';
import {
  Palette,
  RotateCcw,
  Sparkles,
  Sliders,
  Check,
  ChevronDown,
  ChevronUp,
  Layout,
  Layers,
  Briefcase,
  User,
  GitBranch,
  MessageSquare,
  Mail,
  Zap,
} from 'lucide-react';
import {
  SiteColorCustomization,
  SectionColorConfig,
  CURATED_COLOR_PRESETS,
  defaultColorCustomization,
} from '../../data/customColors';
import { TemplateTheme } from '../../data/templates';

interface ColorStudioTabProps {
  customization?: SiteColorCustomization;
  activeTemplate: TemplateTheme;
  onChange: (updated: SiteColorCustomization) => void;
}

const COMMON_SWATCHES = [
  '#ffffff',
  '#09090b',
  '#0b0f17',
  '#1e293b',
  '#f8fafc',
  '#2563eb',
  '#06b6d4',
  '#38bdf8',
  '#10b981',
  '#f59e0b',
  '#ef4444',
  '#8b5cf6',
  '#d4af37',
];

interface ColorFieldProps {
  label: string;
  sublabel?: string;
  value?: string;
  placeholder?: string;
  onChange: (val: string) => void;
  onClear: () => void;
}

const ColorField: React.FC<ColorFieldProps> = ({
  label,
  sublabel,
  value,
  placeholder,
  onChange,
  onClear,
}) => {
  const displayVal = value || '';
  const effectivePickerVal = value && value.startsWith('#') && (value.length === 7 || value.length === 4)
    ? value
    : '#06b6d4';

  return (
    <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
      <div className="flex items-center justify-between gap-2">
        <div>
          <span className="text-xs font-bold text-white block">{label}</span>
          {sublabel && <span className="text-[10px] text-slate-400 block">{sublabel}</span>}
        </div>
        {displayVal && (
          <button
            type="button"
            onClick={onClear}
            className="text-[10px] text-rose-400 hover:text-rose-300 underline font-mono cursor-pointer"
          >
            Clear
          </button>
        )}
      </div>

      <div className="flex items-center gap-2">
        {/* Color picker circle */}
        <label className="relative w-8 h-8 rounded-lg overflow-hidden border border-slate-700 shadow-sm cursor-pointer shrink-0 block">
          <input
            type="color"
            value={effectivePickerVal}
            onChange={(e) => onChange(e.target.value)}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          <div
            className="w-full h-full rounded-lg"
            style={{ backgroundColor: displayVal || '#334155' }}
          />
        </label>

        {/* Text Input */}
        <input
          type="text"
          value={displayVal}
          placeholder={placeholder || 'Default (#...)'}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-500 placeholder:text-slate-600"
        />
      </div>

      {/* Quick Swatches */}
      <div className="flex items-center gap-1.5 pt-1 overflow-x-auto pb-0.5">
        {COMMON_SWATCHES.slice(0, 7).map((hex) => (
          <button
            key={hex}
            type="button"
            onClick={() => onChange(hex)}
            className="w-4 h-4 rounded-full border border-slate-700/80 hover:scale-125 transition-transform shrink-0"
            style={{ backgroundColor: hex }}
            title={hex}
          />
        ))}
      </div>
    </div>
  );
};

export const ColorStudioTab: React.FC<ColorStudioTabProps> = ({
  customization,
  activeTemplate,
  onChange,
}) => {
  const current: SiteColorCustomization = customization || defaultColorCustomization;
  const [activeSectionAccordion, setActiveSectionAccordion] = useState<string>('hero');

  const handleToggleEnable = (enabled: boolean) => {
    onChange({
      ...current,
      enabled,
    });
  };

  const handleGlobalChange = (field: keyof typeof current.global, value: string) => {
    onChange({
      ...current,
      enabled: true,
      global: {
        ...current.global,
        [field]: value,
      },
    });
  };

  const handleSectionChange = (
    sectionKey: keyof typeof current.sections,
    field: keyof SectionColorConfig,
    value: string
  ) => {
    onChange({
      ...current,
      enabled: true,
      sections: {
        ...current.sections,
        [sectionKey]: {
          ...(current.sections[sectionKey] || {}),
          [field]: value,
        },
      },
    });
  };

  const handleResetSection = (sectionKey: keyof typeof current.sections) => {
    onChange({
      ...current,
      sections: {
        ...current.sections,
        [sectionKey]: {},
      },
    });
  };

  const handleApplyPreset = (preset: typeof CURATED_COLOR_PRESETS[0]) => {
    onChange({
      ...current,
      enabled: true,
      global: { ...preset.global },
    });
  };

  const handleResetAllToDefaults = () => {
    onChange({
      ...defaultColorCustomization,
      enabled: false,
    });
  };

  const sectionsList = [
    { key: 'hero', label: 'Hero & Intro Section', icon: Sparkles, id: '#home' },
    { key: 'services', label: 'Graphic Design Services', icon: Layout, id: '#services' },
    { key: 'projects', label: 'Selected Work Portfolio', icon: Briefcase, id: '#projects' },
    { key: 'about', label: 'About & Expertise', icon: User, id: '#about' },
    { key: 'process', label: 'Work Process (6-Steps)', icon: GitBranch, id: '#process' },
    { key: 'testimonials', label: 'Client Reviews & Numbers', icon: MessageSquare, id: '#testimonials' },
    { key: 'contact', label: 'Contact & Inquiry Section', icon: Mail, id: '#contact' },
  ] as const;

  return (
    <div className="space-y-8 max-w-5xl">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-mono mb-2">
          <Palette className="w-3.5 h-3.5" />
          <span>Full-Site Granular Color Customizer & Section Theming</span>
        </div>
        <h3 className="text-xl font-bold text-white">Live Color Studio & Section Color Controls</h3>
        <p className="text-xs text-slate-400 mt-1 leading-relaxed">
          Take total creative control over every headline, paragraph, card background, canvas surface, accent glow, and border across your entire portfolio or individually per section. Changes reflect immediately in live preview.
        </p>
      </div>

      {/* Master Enable & Reset Controls Bar */}
      <div className="p-5 rounded-2xl bg-slate-950/90 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">Custom Color Engine</h4>
            <p className="text-xs text-slate-400">
              Active Template: <span className="text-cyan-400 font-semibold">{activeTemplate.name}</span>
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <label className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-cyan-500/50 transition-colors cursor-pointer">
            <input
              type="checkbox"
              checked={current.enabled}
              onChange={(e) => handleToggleEnable(e.target.checked)}
              className="w-4 h-4 accent-cyan-400 cursor-pointer"
            />
            <span className="text-xs font-bold text-white">
              {current.enabled ? 'Custom Colors Active' : 'Enable Overrides'}
            </span>
          </label>

          <button
            type="button"
            onClick={handleResetAllToDefaults}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-rose-400 hover:text-white hover:bg-rose-950/50 hover:border-rose-700/50 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset to Template Defaults</span>
          </button>
        </div>
      </div>

      {/* Curated 1-Click Master Presets */}
      <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold text-slate-200 flex items-center gap-2 uppercase tracking-wider font-mono">
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            <span>Curated 1-Click Master Palettes</span>
          </h4>
          <span className="text-[11px] text-slate-400">Apply master palette with one click</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {CURATED_COLOR_PRESETS.map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => handleApplyPreset(preset)}
              className="p-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/50 transition-all text-left group cursor-pointer"
            >
              <div className="flex items-center gap-1.5 mb-2">
                {preset.preview.map((col, idx) => (
                  <span
                    key={idx}
                    className="w-3.5 h-3.5 rounded-full border border-black/40 shadow-xs"
                    style={{ backgroundColor: col }}
                  />
                ))}
              </div>
              <div className="text-xs font-bold text-white group-hover:text-cyan-300 transition-colors">
                {preset.name}
              </div>
              <div className="text-[10px] text-slate-400 font-mono mt-0.5">{preset.badge}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Part 1: Master Global Color Palette */}
      <div className="p-6 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-5 shadow-xl">
        <div className="border-b border-slate-800 pb-3">
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <Palette className="w-4 h-4 text-cyan-400" />
            <span>Master Global Color Controls</span>
          </h4>
          <p className="text-xs text-slate-400 mt-0.5">
            These colors apply globally across all pages and sections unless overridden specifically below.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <ColorField
            label="Canvas Background Color"
            sublabel="Main page body canvas"
            value={current.global.bgColor}
            placeholder={activeTemplate.bgCanvasDark}
            onChange={(val) => handleGlobalChange('bgColor', val)}
            onClear={() => handleGlobalChange('bgColor', '')}
          />

          <ColorField
            label="Card / Surface Background"
            sublabel="Cards, modals, and container surfaces"
            value={current.global.cardBgColor}
            placeholder={activeTemplate.cardBgDark}
            onChange={(val) => handleGlobalChange('cardBgColor', val)}
            onClear={() => handleGlobalChange('cardBgColor', '')}
          />

          <ColorField
            label="Headlines & Title Color"
            sublabel="H1, H2, H3 main headings"
            value={current.global.headingColor}
            placeholder="#ffffff"
            onChange={(val) => handleGlobalChange('headingColor', val)}
            onClear={() => handleGlobalChange('headingColor', '')}
          />

          <ColorField
            label="Body & Paragraph Text Color"
            sublabel="Descriptions, bios, and subtitles"
            value={current.global.textColor}
            placeholder="#cbd5e1"
            onChange={(val) => handleGlobalChange('textColor', val)}
            onClear={() => handleGlobalChange('textColor', '')}
          />

          <ColorField
            label="Accent & Primary Action Color"
            sublabel="Key highlights, badges, and primary buttons"
            value={current.global.accentColor}
            placeholder={activeTemplate.accentColor}
            onChange={(val) => handleGlobalChange('accentColor', val)}
            onClear={() => handleGlobalChange('accentColor', '')}
          />

          <ColorField
            label="Card & Divider Border Color"
            sublabel="Hairline borders and outlines"
            value={current.global.borderColor}
            placeholder={activeTemplate.cardBorderDark}
            onChange={(val) => handleGlobalChange('borderColor', val)}
            onClear={() => handleGlobalChange('borderColor', '')}
          />
        </div>
      </div>

      {/* Part 2: Section-by-Section Granular Color Controls */}
      <div className="p-6 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-5 shadow-xl">
        <div className="border-b border-slate-800 pb-3">
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            <span>Section-by-Section Color Overrides</span>
          </h4>
          <p className="text-xs text-slate-400 mt-0.5">
            Click any section below to customize its individual headlines, text, background, and cards independently.
          </p>
        </div>

        <div className="space-y-3">
          {sectionsList.map((sec) => {
            const Icon = sec.icon;
            const isOpen = activeSectionAccordion === sec.key;
            const sectionValues = current.sections[sec.key as keyof typeof current.sections] || {};
            const hasOverrides = Object.values(sectionValues).some((v) => !!v);

            return (
              <div
                key={sec.key}
                className="rounded-xl border border-slate-800 overflow-hidden bg-slate-900/60"
              >
                {/* Accordion Header */}
                <button
                  type="button"
                  onClick={() => setActiveSectionAccordion(isOpen ? '' : sec.key)}
                  className="w-full px-4 py-3.5 flex items-center justify-between text-left hover:bg-slate-900/90 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-7 h-7 rounded-lg bg-cyan-950/60 border border-cyan-800/40 flex items-center justify-center text-cyan-400">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-2">
                        <span>{sec.label}</span>
                        <span className="font-mono text-[10px] text-slate-500 font-normal">
                          {sec.id}
                        </span>
                        {hasOverrides && (
                          <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px] font-mono border border-cyan-500/30">
                            Custom Overrides Active
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {isOpen ? (
                      <ChevronUp className="w-4 h-4 text-slate-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400" />
                    )}
                  </div>
                </button>

                {/* Accordion Body */}
                {isOpen && (
                  <div className="p-4 bg-slate-950/80 border-t border-slate-800 space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] text-slate-400">
                        Customize appearance for {sec.label}
                      </span>
                      {hasOverrides && (
                        <button
                          type="button"
                          onClick={() => handleResetSection(sec.key as any)}
                          className="text-[11px] text-rose-400 hover:text-rose-300 underline font-mono cursor-pointer"
                        >
                          Reset This Section
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                      <ColorField
                        label="Heading Color"
                        sublabel="Section title & subheaders"
                        value={sectionValues.headingColor}
                        onChange={(val) =>
                          handleSectionChange(sec.key as any, 'headingColor', val)
                        }
                        onClear={() =>
                          handleSectionChange(sec.key as any, 'headingColor', '')
                        }
                      />

                      <ColorField
                        label="Body Text Color"
                        sublabel="Paragraphs & item details"
                        value={sectionValues.textColor}
                        onChange={(val) =>
                          handleSectionChange(sec.key as any, 'textColor', val)
                        }
                        onClear={() =>
                          handleSectionChange(sec.key as any, 'textColor', '')
                        }
                      />

                      <ColorField
                        label="Section Background"
                        sublabel="Background behind this section"
                        value={sectionValues.bgColor}
                        onChange={(val) =>
                          handleSectionChange(sec.key as any, 'bgColor', val)
                        }
                        onClear={() =>
                          handleSectionChange(sec.key as any, 'bgColor', '')
                        }
                      />

                      <ColorField
                        label="Card / Box Background"
                        sublabel="Inner cards & boxes"
                        value={sectionValues.cardBgColor}
                        onChange={(val) =>
                          handleSectionChange(sec.key as any, 'cardBgColor', val)
                        }
                        onClear={() =>
                          handleSectionChange(sec.key as any, 'cardBgColor', '')
                        }
                      />

                      <ColorField
                        label="Accent / Buttons"
                        sublabel="Buttons & highlight elements"
                        value={sectionValues.accentColor}
                        onChange={(val) =>
                          handleSectionChange(sec.key as any, 'accentColor', val)
                        }
                        onClear={() =>
                          handleSectionChange(sec.key as any, 'accentColor', '')
                        }
                      />

                      <ColorField
                        label="Card Borders"
                        sublabel="Card borders in this section"
                        value={sectionValues.borderColor}
                        onChange={(val) =>
                          handleSectionChange(sec.key as any, 'borderColor', val)
                        }
                        onClear={() =>
                          handleSectionChange(sec.key as any, 'borderColor', '')
                        }
                      />
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
