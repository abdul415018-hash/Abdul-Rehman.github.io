import React, { useState } from 'react';
import {
  X,
  Save,
  CheckCircle2,
  Trash2,
  Plus,
  Shield,
  Layers,
  User,
  Sparkles,
  Briefcase,
  GitBranch,
  MessageSquare,
  BarChart2,
  Mail,
  Inbox,
  Key,
  Download,
  Upload,
  RotateCcw,
  LogOut,
  ExternalLink,
  Lock,
  Eye,
  EyeOff,
  FileText,
  AlertCircle,
  Check,
  Palette,
  Layout,
  Tag,
  DollarSign,
  Zap,
  Globe,
  Phone,
  Sliders
} from 'lucide-react';
import {
  PortfolioData,
  SkillItem,
  ProjectItem,
  ProcessStep,
  TestimonialItem,
  StatItem,
  defaultPortfolioData
} from '../../data/portfolioData';
import {
  TEMPLATES,
  TemplateDefinition,
  ServiceItem,
  ServicesConfig,
  defaultServices
} from '../../data/templates';
import { ImageUploadField } from './ImageUploadField';
import { processLocalImageFile } from '../../utils/imageUpload';
import { ColorStudioTab } from './ColorStudioTab';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  data: PortfolioData;
  onSaveData: (newData: PortfolioData) => void;
  onLogout: () => void;
}

type TabType =
  | 'templates'
  | 'colors'
  | 'services'
  | 'hero'
  | 'about'
  | 'skills'
  | 'projects'
  | 'process'
  | 'testimonials'
  | 'stats'
  | 'contact'
  | 'inbox'
  | 'branding'
  | 'security';

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  isOpen,
  onClose,
  data,
  onSaveData,
  onLogout,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('hero');
  const [formData, setFormData] = useState<PortfolioData>(data);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [adminUsername, setAdminUsername] = useState(data.admin.username);

  // Hardened security verification states
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [securityError, setSecurityError] = useState('');
  const [securitySuccess, setSecuritySuccess] = useState('');
  const [showOldPass, setShowOldPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);
  const [showConfirmPass, setShowConfirmPass] = useState(false);
  const [isProcessingPdf, setIsProcessingPdf] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveData(formData);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  // Template Handlers
  const handleSelectTemplate = (templateId: string) => {
    setFormData((prev) => ({
      ...prev,
      activeTemplateId: templateId,
    }));
  };

  // Service Item Handlers
  const handleAddService = () => {
    const newService: ServiceItem = {
      id: `srv_${Date.now()}`,
      title: 'New Graphic Design Service',
      shortDesc: 'Professional high-impact visual design deliverable crafted in Illustrator & Photoshop.',
      category: 'branding',
      standardPrice: 'Rs 12,000 / $50',
      standardDays: '3 Days',
      expressPrice: 'Rs 18,000 / $75',
      expressDays: '24 Hours',
      revisions: 'Unlimited Revisions',
      deliverablesCount: 'Complete Master Vector Suite',
      features: [
        'High Resolution Print-Ready Files',
        'Source AI, EPS, SVG & PNG',
        'Full Commercial Rights'
      ],
      isPopular: false,
    };
    setFormData((prev) => ({
      ...prev,
      services: [...prev.services, newService],
    }));
  };

  const handleUpdateService = (id: string, field: keyof ServiceItem, val: any) => {
    setFormData((prev) => ({
      ...prev,
      services: prev.services.map((s) => (s.id === id ? { ...s, [field]: val } : s)),
    }));
  };

  const handleDeleteService = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      services: prev.services.filter((s) => s.id !== id),
    }));
  };

  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setSecurityError('');
    setSecuritySuccess('');

    // Step 1: Validate Current Password against stored credentials
    if (currentPassword !== formData.admin.passwordHash) {
      setSecurityError('Current password is incorrect! You must provide your valid existing password to update security settings.');
      return;
    }

    // Step 2: Validate New Password length
    if (!newPassword.trim()) {
      setSecurityError('Please enter a new password.');
      return;
    }

    if (newPassword.trim().length < 6) {
      setSecurityError('New password must be at least 6 characters long.');
      return;
    }

    // Step 3: Validate Confirmation Password Match
    if (newPassword.trim() !== confirmPassword.trim()) {
      setSecurityError('New password and confirmation password do not match.');
      return;
    }

    const updatedAdmin = {
      username: adminUsername.trim() || formData.admin.username,
      passwordHash: newPassword.trim(),
    };

    const updatedData: PortfolioData = {
      ...formData,
      admin: updatedAdmin,
    };

    setFormData(updatedData);
    onSaveData(updatedData);
    setSecuritySuccess('Admin credentials and password updated successfully!');
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setTimeout(() => setSecuritySuccess(''), 4000);
  };

  const handlePdfUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsProcessingPdf(true);
    try {
      const dataUrl = await processLocalImageFile(file);
      setFormData((prev) => ({
        ...prev,
        branding: {
          ...prev.branding,
          cvPdfUrl: dataUrl,
        },
      }));
    } catch (err: any) {
      alert(err.message || 'Failed to upload PDF file.');
    } finally {
      setIsProcessingPdf(false);
    }
  };

  // Skill Handlers
  const handleAddSkill = () => {
    const newSkill: SkillItem = {
      id: `skill_${Date.now()}`,
      name: 'Adobe Creative Suite',
      level: 90,
    };
    setFormData((prev) => ({
      ...prev,
      skills: [...prev.skills, newSkill],
    }));
  };

  const handleUpdateSkill = (id: string, field: keyof SkillItem, val: string | number) => {
    setFormData((prev) => ({
      ...prev,
      skills: prev.skills.map((s) => (s.id === id ? { ...s, [field]: val } : s)),
    }));
  };

  const handleDeleteSkill = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      skills: prev.skills.filter((s) => s.id !== id),
    }));
  };

  // Project Handlers
  const handleAddProject = () => {
    const newProj: ProjectItem = {
      id: `proj_${Date.now()}`,
      title: 'New Branding & Design Project',
      badge: 'Brand Identity',
      category: 'branding',
      description: 'Comprehensive brand identity and vector packaging design.',
      image: '/src/assets/images/brand_identity_mockup_1791553041005.jpg',
      tags: ['Illustrator', 'Photoshop', 'Brand Guide'],
      link: '#',
    };
    setFormData((prev) => ({
      ...prev,
      projects: [...prev.projects, newProj],
    }));
  };

  const handleUpdateProject = (id: string, field: keyof ProjectItem, val: any) => {
    setFormData((prev) => ({
      ...prev,
      projects: prev.projects.map((p) => (p.id === id ? { ...p, [field]: val } : p)),
    }));
  };

  const handleDeleteProject = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      projects: prev.projects.filter((p) => p.id !== id),
    }));
  };

  // Process Handlers
  const handleUpdateProcess = (idx: number, field: keyof ProcessStep, val: string) => {
    setFormData((prev) => {
      const nextProc = [...prev.process];
      nextProc[idx] = { ...nextProc[idx], [field]: val };
      return { ...prev, process: nextProc };
    });
  };

  // Testimonials Handlers
  const handleAddTestimonial = () => {
    const newTest: TestimonialItem = {
      id: `test_${Date.now()}`,
      clientName: 'Client Name',
      role: 'Founder',
      company: 'Brand Studio',
      avatar: '/src/assets/images/hamza_ali_avatar_1791559902602.jpg',
      quote: 'Exceptional craftsmanship and precision vector execution!',
    };
    setFormData((prev) => ({
      ...prev,
      testimonials: [...prev.testimonials, newTest],
    }));
  };

  const handleUpdateTestimonial = (id: string, field: keyof TestimonialItem, val: string) => {
    setFormData((prev) => ({
      ...prev,
      testimonials: prev.testimonials.map((t) => (t.id === id ? { ...t, [field]: val } : t)),
    }));
  };

  const handleDeleteTestimonial = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      testimonials: prev.testimonials.filter((t) => t.id !== id),
    }));
  };

  // Stat Handlers
  const handleUpdateStat = (id: string, field: keyof StatItem, val: string) => {
    setFormData((prev) => ({
      ...prev,
      stats: prev.stats.map((s) => (s.id === id ? { ...s, [field]: val } : s)),
    }));
  };

  // Inbox message handlers
  const handleDeleteMessage = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      messages: prev.messages.filter((m) => m.id !== id),
    }));
  };

  const handleClearMessages = () => {
    if (window.confirm('Delete all messages in the inbox?')) {
      setFormData((prev) => ({ ...prev, messages: [] }));
    }
  };

  // Export JSON Backup
  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(formData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `portfolio-backup-${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Import JSON Backup
  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const imported = JSON.parse(event.target?.result as string);
        setFormData(imported);
        alert('Data imported successfully! Click "Save All Changes" to persist.');
      } catch (err) {
        alert('Invalid JSON file format.');
      }
    };
    reader.readAsText(file);
  };

  // Reset to original defaults
  const handleResetDefaults = () => {
    if (window.confirm('Are you sure you want to restore the default graphic designer configuration?')) {
      setFormData(defaultPortfolioData);
      setAdminUsername(defaultPortfolioData.admin.username);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      onSaveData(defaultPortfolioData);
    }
  };

  const activeTemplate = TEMPLATES.find((t) => t.id === formData.activeTemplateId) || TEMPLATES[0];

  const navItems = [
    { id: 'templates', label: '9 Themed Templates', icon: Palette },
    { id: 'colors', label: 'Color Studio & Overrides', icon: Sliders },
    { id: 'services', label: 'Services & Packages', icon: Tag },
    { id: 'hero', label: 'Hero Section', icon: Sparkles },
    { id: 'about', label: 'About Me', icon: User },
    { id: 'skills', label: 'Skills & Tools', icon: Layers },
    { id: 'projects', label: 'Selected Work', icon: Briefcase },
    { id: 'process', label: 'Work Process', icon: GitBranch },
    { id: 'testimonials', label: 'Testimonials', icon: MessageSquare },
    { id: 'stats', label: 'By The Numbers', icon: BarChart2 },
    { id: 'contact', label: 'Contact Info', icon: Mail },
    { id: 'inbox', label: `Inbox (${formData.messages.length})`, icon: Inbox },
    { id: 'branding', label: 'Branding & Nav', icon: ExternalLink },
    { id: 'security', label: 'Security & Auth', icon: Key },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-slate-950/90 backdrop-blur-2xl overflow-hidden animate-in fade-in duration-200">
      
      {/* Main Admin Card */}
      <div className="relative w-full max-w-6xl h-[92vh] bg-slate-900 border border-cyan-500/30 rounded-3xl shadow-2xl shadow-black/90 flex flex-col overflow-hidden">
        
        {/* Top Navbar */}
        <div className="px-6 py-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/30">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                <span>Master Admin Control Panel</span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800/50">
                  Full Access
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Logged in as <span className="text-cyan-300 font-semibold">{adminUsername}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {saveSuccess && (
              <span className="text-xs text-emerald-400 font-medium flex items-center gap-1.5 bg-emerald-950/60 px-3 py-1.5 rounded-xl border border-emerald-800/50 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4" />
                <span>All Changes Saved!</span>
              </span>
            )}

            <button
              onClick={handleSave}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-cyan-400 to-cyan-300 hover:from-cyan-300 hover:to-white shadow-md shadow-cyan-500/30 transition-all cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save All Changes</span>
            </button>

            <button
              onClick={onLogout}
              title="Logout"
              className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              title="Close Panel"
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Admin Body: Sidebar + Content Area */}
        <div className="flex flex-1 overflow-hidden">
          
          {/* Sidebar Tabs */}
          <aside className="w-56 border-r border-slate-800 bg-slate-950/60 p-3 flex flex-col gap-1 overflow-y-auto shrink-0 hidden md:flex">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as TabType)}
                  className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all text-left cursor-pointer ${
                    isActive
                      ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </aside>

          {/* Mobile Tab Scroller */}
          <div className="md:hidden flex border-b border-slate-800 bg-slate-950/90 overflow-x-auto p-2 gap-1.5 shrink-0 w-full absolute top-16 left-0 right-0 z-20">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as TabType)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap ${
                  activeTab === item.id
                    ? 'bg-cyan-500 text-slate-950'
                    : 'text-slate-400 bg-slate-900'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Tab Content Panels */}
          <main className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-6 bg-slate-900/40">

            {/* TAB: 9 THEMED TEMPLATES & LIVE ATMOSPHERIC MOTION GRAPHICS */}
            {activeTab === 'templates' && (
              <div className="space-y-8 max-w-5xl">
                {/* Header */}
                <div>
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-mono mb-2">
                    <Palette className="w-3.5 h-3.5" />
                    <span>9 Full-Site Aesthetic Transformations & Motion Engines</span>
                  </div>
                  <h3 className="text-xl font-bold text-white">Full-Site Templates & Motion Graphics</h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Select any template below to completely transform the entire portfolio's color scheme, typography, card elevation, and atmospheric lighting. Configure live physics motion overlays (such as Pakistan Independence Day waving flag and hanging bunting garlands, Eid lanterns, and geometric floaters).
                  </p>
                </div>

                {/* 1. ATMOSPHERIC MOTION GRAPHICS CONTROLS */}
                <div className="p-5 sm:p-6 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-5 shadow-xl">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
                    <div>
                      <h4 className="text-sm font-bold text-white flex items-center gap-2">
                        <Zap className="w-4 h-4 text-cyan-400" />
                        <span>Live Atmospheric Motion Graphics Controls</span>
                      </h4>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Toggle physics-animated hanging garlands, floating flags, swinging lanterns, and ambient particles.
                      </p>
                    </div>

                    {/* Master Motion Toggle */}
                    <label className="flex items-center gap-3 cursor-pointer self-start sm:self-auto px-3.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-cyan-500/50 transition-colors">
                      <span className="text-xs font-semibold text-white">
                        Master Motion Engine:
                      </span>
                      <input
                        type="checkbox"
                        checked={formData.motionConfig?.enabled ?? true}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            motionConfig: {
                              ...formData.motionConfig,
                              enabled: e.target.checked,
                            },
                          })
                        }
                        className="w-4 h-4 accent-cyan-400 cursor-pointer"
                      />
                      <span className={`text-[11px] font-bold uppercase tracking-wider ${
                        (formData.motionConfig?.enabled ?? true) ? 'text-cyan-400' : 'text-slate-500'
                      }`}>
                        {(formData.motionConfig?.enabled ?? true) ? 'Active' : 'Off'}
                      </span>
                    </label>
                  </div>

                  {/* Sub-controls */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {/* Hanging Garlands & Lanterns */}
                    <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
                      <div>
                        <div className="text-xs font-bold text-white">Hanging Garlands</div>
                        <div className="text-[11px] text-slate-400">Bunting / Lanterns</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={formData.motionConfig?.showGarland ?? true}
                        disabled={!(formData.motionConfig?.enabled ?? true)}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            motionConfig: {
                              ...formData.motionConfig,
                              showGarland: e.target.checked,
                            },
                          })
                        }
                        className="w-4 h-4 accent-cyan-400 cursor-pointer disabled:opacity-40"
                      />
                    </div>

                    {/* Floating Badges & Waving Flag */}
                    <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
                      <div>
                        <div className="text-xs font-bold text-white">Floating Badges</div>
                        <div className="text-[11px] text-slate-400">Waving Flag / Motifs</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={formData.motionConfig?.showFloatingMotif ?? true}
                        disabled={!(formData.motionConfig?.enabled ?? true)}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            motionConfig: {
                              ...formData.motionConfig,
                              showFloatingMotif: e.target.checked,
                            },
                          })
                        }
                        className="w-4 h-4 accent-cyan-400 cursor-pointer disabled:opacity-40"
                      />
                    </div>

                    {/* Ambient Particles */}
                    <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
                      <div>
                        <div className="text-xs font-bold text-white">Ambient Particles</div>
                        <div className="text-[11px] text-slate-400">Crescent / Starburst</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={formData.motionConfig?.showParticles ?? true}
                        disabled={!(formData.motionConfig?.enabled ?? true)}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            motionConfig: {
                              ...formData.motionConfig,
                              showParticles: e.target.checked,
                            },
                          })
                        }
                        className="w-4 h-4 accent-cyan-400 cursor-pointer disabled:opacity-40"
                      />
                    </div>

                    {/* Animation Physics Speed */}
                    <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800">
                      <div className="text-xs font-bold text-white mb-1.5">Motion Speed</div>
                      <div className="flex items-center gap-1">
                        {(['slow', 'normal', 'fast'] as const).map((spd) => (
                          <button
                            key={spd}
                            type="button"
                            disabled={!(formData.motionConfig?.enabled ?? true)}
                            onClick={() =>
                              setFormData({
                                ...formData,
                                motionConfig: {
                                  ...formData.motionConfig,
                                  speed: spd,
                                },
                              })
                            }
                            className={`flex-1 py-1 rounded text-[10px] font-bold capitalize transition-all cursor-pointer ${
                              (formData.motionConfig?.speed || 'normal') === spd
                                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                                : 'bg-slate-800 text-slate-400 hover:text-white'
                            }`}
                          >
                            {spd}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* 2. TEMPLATES SELECTION CARDS */}
                <div>
                  <h4 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                    <Layout className="w-4 h-4 text-cyan-400" />
                    <span>Choose From 9 Distinct Aesthetic Architectures (1-Click Apply)</span>
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                    {TEMPLATES.map((tmpl) => {
                      const isSelected = (formData.activeTemplateId || 'independence-day') === tmpl.id;
                      return (
                        <div
                          key={tmpl.id}
                          onClick={() => handleSelectTemplate(tmpl.id)}
                          className={`rounded-2xl border transition-all cursor-pointer overflow-hidden p-5 flex flex-col justify-between group relative ${
                            isSelected
                              ? 'bg-slate-950/95 border-cyan-400 shadow-[0_0_35px_rgba(6,182,212,0.4)] ring-2 ring-cyan-400/50'
                              : 'bg-slate-950/50 border-slate-800 hover:border-slate-700 hover:bg-slate-950/80'
                          }`}
                        >
                          {/* Live active indicator badge */}
                          {isSelected && (
                            <div className="absolute top-3 right-3 bg-cyan-400 text-slate-950 font-black text-[10px] tracking-wider uppercase px-2.5 py-0.5 rounded-full shadow-md flex items-center gap-1 z-10">
                              <Check className="w-3 h-3" />
                              <span>Active Theme</span>
                            </div>
                          )}

                          <div>
                            {/* Color Palette Swatch Strip */}
                            <div className="h-20 rounded-xl p-3 flex flex-col justify-between relative overflow-hidden mb-4 border border-white/10 shadow-inner"
                              style={{ backgroundColor: tmpl.bgCanvasDark }}
                            >
                              <div className="flex items-center justify-between">
                                <span className="text-[10px] font-mono font-bold tracking-wider px-2 py-0.5 rounded bg-black/60 text-white backdrop-blur-sm">
                                  {tmpl.badge}
                                </span>
                                <div className="flex items-center gap-1.5">
                                  {tmpl.previewSwatches.map((color, idx) => (
                                    <div
                                      key={idx}
                                      className="w-3.5 h-3.5 rounded-full border border-white/30 shadow-sm"
                                      style={{ backgroundColor: color }}
                                    />
                                  ))}
                                </div>
                              </div>
                              <div>
                                <span className={`text-[11px] font-bold ${tmpl.id === 'bauhaus-brutalist' || tmpl.id === 'swiss-international' ? 'text-black' : 'text-white/90'} drop-shadow-md`}>
                                  {tmpl.category}
                                </span>
                              </div>
                            </div>

                            {/* Template Title & Tagline */}
                            <div className="mb-2">
                              <h4 className="text-base font-bold text-white group-hover:text-cyan-400 transition-colors">
                                {tmpl.name}
                              </h4>
                              <p className="text-[11px] font-medium text-cyan-400/90 mt-0.5">
                                {tmpl.tagline}
                              </p>
                            </div>
                            
                            <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed mb-4">
                              {tmpl.description}
                            </p>
                          </div>

                          {/* Apply Button */}
                          <div className="pt-2">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleSelectTemplate(tmpl.id);
                              }}
                              className={`w-full py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                                isSelected
                                  ? 'bg-cyan-500 text-slate-950 shadow-md'
                                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                              }`}
                            >
                              {isSelected ? (
                                <>
                                  <Check className="w-3.5 h-3.5" />
                                  <span>Applied to Entire Website</span>
                                </>
                              ) : (
                                <>
                                  <Layout className="w-3.5 h-3.5 text-cyan-400" />
                                  <span>Apply This Template</span>
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* TAB: COLOR STUDIO & GRANULAR SECTION COLOR OVERRIDES */}
            {activeTab === 'colors' && (
              <ColorStudioTab
                customization={formData.colorCustomization}
                activeTemplate={activeTemplate}
                onChange={(updated) =>
                  setFormData({
                    ...formData,
                    colorCustomization: updated,
                  })
                }
              />
            )}

            {/* TAB: SERVICES & PACKAGES (GRAPHIC DESIGN OFFERINGS) */}
            {activeTab === 'services' && (
              <div className="space-y-6 max-w-5xl">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-mono mb-2">
                      <Tag className="w-3.5 h-3.5" />
                      <span>Graphic Design Services & Commercial Packages</span>
                    </div>
                    <h3 className="text-xl font-bold text-white">Manage Services & Pricing Matrix</h3>
                    <p className="text-xs text-slate-400 mt-1">
                      Control each service's standard & express price, delivery days, revisions, deliverables count, special offer, and WhatsApp booking phone number.
                    </p>
                  </div>
                  <button
                    onClick={handleAddService}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 transition-colors shadow-lg shadow-cyan-500/20 cursor-pointer self-start sm:self-auto"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add New Service</span>
                  </button>
                </div>

                {/* Section Global Settings (WhatsApp & Banner) */}
                <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-4">
                  <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5" />
                    <span>WhatsApp Order Phone & Festive Promo Banner</span>
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        WhatsApp Contact Number (International format with Country Code):
                      </label>
                      <input
                        type="text"
                        value={formData.servicesConfig?.whatsappNumber || '+923101234567'}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            servicesConfig: {
                              ...formData.servicesConfig,
                              whatsappNumber: e.target.value,
                            },
                          })
                        }
                        placeholder="+923101234567"
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                      />
                      <p className="text-[11px] text-slate-500 mt-1">
                        WhatsApp order messages will be opened directly with this phone number.
                      </p>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1">
                        Services Section Title:
                      </label>
                      <input
                        type="text"
                        value={formData.servicesConfig?.sectionTitle || 'Design Services & Packages'}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            servicesConfig: {
                              ...formData.servicesConfig,
                              sectionTitle: e.target.value,
                            },
                          })
                        }
                        className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2 p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <label className="text-xs font-bold text-white block">
                            Optional Promotional Announcement Banner
                          </label>
                          <p className="text-[11px] text-slate-400">
                            Strictly optional. Enable only if you wish to display a custom announcement across the services section.
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={formData.servicesConfig?.promoBannerEnabled ?? false}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              servicesConfig: {
                                ...formData.servicesConfig,
                                promoBannerEnabled: e.target.checked,
                              },
                            })
                          }
                          className="w-4 h-4 accent-cyan-400 cursor-pointer"
                        />
                      </div>

                      {formData.servicesConfig?.promoBannerEnabled && (
                        <div>
                          <label className="block text-xs font-medium text-slate-300 mb-1">
                            Announcement Text:
                          </label>
                          <input
                            type="text"
                            value={formData.servicesConfig?.promoBannerText || ''}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                servicesConfig: {
                                  ...formData.servicesConfig,
                                  promoBannerText: e.target.value,
                                },
                              })
                            }
                            placeholder="Limited Time: Book any package this week and receive complimentary corporate stationery!"
                            className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Individual Service Items List */}
                <div className="space-y-4">
                  {formData.services?.map((service, idx) => (
                    <div
                      key={service.id || idx}
                      className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-4"
                    >
                      <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-800">
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-400 font-mono text-xs flex items-center justify-center font-bold">
                            {idx + 1}
                          </span>
                          <span className="text-sm font-bold text-white">
                            {service.title || 'Untitled Service'}
                          </span>
                          {service.isPopular && (
                            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-amber-400 text-slate-950">
                              Popular
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() =>
                              handleUpdateService(service.id, 'isPopular', !service.isPopular)
                            }
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-colors cursor-pointer ${
                              service.isPopular
                                ? 'bg-amber-400 text-slate-950'
                                : 'bg-slate-800 text-slate-400 hover:text-white'
                            }`}
                          >
                            {service.isPopular ? '★ Popular' : '☆ Mark Popular'}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteService(service.id)}
                            className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 transition-colors cursor-pointer"
                            title="Delete this service"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Main Service Fields */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div className="sm:col-span-2">
                          <label className="block text-xs font-medium text-slate-300 mb-1">
                            Service Title:
                          </label>
                          <input
                            type="text"
                            value={service.title}
                            onChange={(e) => handleUpdateService(service.id, 'title', e.target.value)}
                            className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-slate-300 mb-1">
                            Category:
                          </label>
                          <select
                            value={service.category}
                            onChange={(e) => handleUpdateService(service.id, 'category', e.target.value)}
                            className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                          >
                            <option value="branding">Brand &amp; Identity</option>
                            <option value="packaging">Packaging &amp; CAD</option>
                            <option value="social">Social Media</option>
                            <option value="print">Print &amp; Editorial</option>
                            <option value="logo">Logo &amp; Vector</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-300 mb-1">
                          Short Description:
                        </label>
                        <input
                          type="text"
                          value={service.shortDesc}
                          onChange={(e) => handleUpdateService(service.id, 'shortDesc', e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                        />
                      </div>

                      {/* Pricing & Timeline Matrix */}
                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                        <div>
                          <label className="block text-[11px] font-semibold text-cyan-400 mb-1">
                            Standard Price:
                          </label>
                          <input
                            type="text"
                            value={service.standardPrice}
                            onChange={(e) => handleUpdateService(service.id, 'standardPrice', e.target.value)}
                            placeholder="Rs 15,000 / $65"
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white font-mono"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-semibold text-cyan-400 mb-1">
                            Standard Delivery:
                          </label>
                          <input
                            type="text"
                            value={service.standardDays}
                            onChange={(e) => handleUpdateService(service.id, 'standardDays', e.target.value)}
                            placeholder="3 Days"
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white font-mono"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-semibold text-amber-400 mb-1">
                            Express Price (Rush):
                          </label>
                          <input
                            type="text"
                            value={service.expressPrice}
                            onChange={(e) => handleUpdateService(service.id, 'expressPrice', e.target.value)}
                            placeholder="Rs 22,000 / $95"
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-amber-500/40 text-xs text-amber-300 font-mono"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-semibold text-amber-400 mb-1">
                            Express Delivery:
                          </label>
                          <input
                            type="text"
                            value={service.expressDays}
                            onChange={(e) => handleUpdateService(service.id, 'expressDays', e.target.value)}
                            placeholder="24 Hours"
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-amber-500/40 text-xs text-amber-300 font-mono"
                          />
                        </div>
                      </div>

                      {/* Revisions & Deliverables Quantity */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-medium text-slate-300 mb-1">
                            Revisions Policy:
                          </label>
                          <input
                            type="text"
                            value={service.revisions}
                            onChange={(e) => handleUpdateService(service.id, 'revisions', e.target.value)}
                            placeholder="Unlimited Revisions or 5 Rounds"
                            className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white font-mono"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-slate-300 mb-1">
                            Deliverables & Quantity:
                          </label>
                          <input
                            type="text"
                            value={service.deliverablesCount}
                            onChange={(e) => handleUpdateService(service.id, 'deliverablesCount', e.target.value)}
                            placeholder="5 Logo Concepts + Brand Manual"
                            className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white font-mono"
                          />
                        </div>
                      </div>

                      {/* Special Offer Sub-Section */}
                      <div className="p-3 rounded-xl bg-purple-950/20 border border-purple-900/40 space-y-2">
                        <label className="block text-xs font-bold text-purple-400 uppercase tracking-wider">
                          Attached Special Offer / Bundle Deal (Optional):
                        </label>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <input
                            type="text"
                            value={service.specialOffer?.title || ''}
                            onChange={(e) =>
                              handleUpdateService(service.id, 'specialOffer', {
                                badge: service.specialOffer?.badge || 'Special Bundle',
                                discountText: service.specialOffer?.discountText || 'Save 30%',
                                description: service.specialOffer?.description || '',
                                title: e.target.value,
                              })
                            }
                            placeholder="Offer Title (e.g. Free Business Card & Letterhead)"
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-purple-800/60 text-xs text-white"
                          />
                          <input
                            type="text"
                            value={service.specialOffer?.description || ''}
                            onChange={(e) =>
                              handleUpdateService(service.id, 'specialOffer', {
                                ...(service.specialOffer || { badge: 'Special', discountText: 'Promo' }),
                                description: e.target.value,
                              })
                            }
                            placeholder="Offer Description Details..."
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-950 border border-purple-800/60 text-xs text-white"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 1: HERO SECTION */}
            {activeTab === 'hero' && (
              <div className="space-y-6 max-w-4xl">
                <div>
                  <h3 className="text-lg font-bold text-white mb-1">Hero Section Settings</h3>
                  <p className="text-xs text-slate-400">Configure your portrait photo (upload directly from your PC), headline, and floating badges.</p>
                </div>

                {/* Direct Image Upload from Computer */}
                <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800">
                  <ImageUploadField
                    label="Your Profile / Portrait Photo (Upload From Your Computer)"
                    value={formData.hero.portraitImage}
                    onChange={(newVal) =>
                      setFormData({ ...formData, hero: { ...formData.hero, portraitImage: newVal } })
                    }
                    aspectRatioLabel="Portrait Photo (Square or 4:5)"
                    helpText="Click 'Choose Image from Computer' to pick any photo from your PC or laptop. It updates live immediately."
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Kicker Badge Text</label>
                    <input
                      type="text"
                      value={formData.hero.badgeText}
                      onChange={(e) =>
                        setFormData({ ...formData, hero: { ...formData.hero, badgeText: e.target.value } })
                      }
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Bottom Floating Banner Text</label>
                    <input
                      type="text"
                      value={formData.hero.bottomBannerText}
                      onChange={(e) =>
                        setFormData({ ...formData, hero: { ...formData.hero, bottomBannerText: e.target.value } })
                      }
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                {/* Headline Construction */}
                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                  <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider block">Headline Parts</span>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Prefix</label>
                      <input
                        type="text"
                        value={formData.hero.headlinePrefix}
                        onChange={(e) =>
                          setFormData({ ...formData, hero: { ...formData.hero, headlinePrefix: e.target.value } })
                        }
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Highlighted (Cyan Gradient)</label>
                      <input
                        type="text"
                        value={formData.hero.headlineHighlight}
                        onChange={(e) =>
                          setFormData({ ...formData, hero: { ...formData.hero, headlineHighlight: e.target.value } })
                        }
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-cyan-700/60 text-xs text-cyan-300"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Suffix</label>
                      <input
                        type="text"
                        value={formData.hero.headlineSuffix}
                        onChange={(e) =>
                          setFormData({ ...formData, hero: { ...formData.hero, headlineSuffix: e.target.value } })
                        }
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Bio Text Paragraph</label>
                  <textarea
                    rows={3}
                    value={formData.hero.bioText}
                    onChange={(e) =>
                      setFormData({ ...formData, hero: { ...formData.hero, bioText: e.target.value } })
                    }
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-cyan-400 resize-none"
                  />
                </div>

                {/* Action Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
                    <span className="text-xs font-semibold text-slate-300 block">Primary Button (Solid Cyan)</span>
                    <input
                      type="text"
                      placeholder="Button Text"
                      value={formData.hero.primaryBtnText}
                      onChange={(e) =>
                        setFormData({ ...formData, hero: { ...formData.hero, primaryBtnText: e.target.value } })
                      }
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                    />
                    <input
                      type="text"
                      placeholder="Button Link (e.g. #projects)"
                      value={formData.hero.primaryBtnLink}
                      onChange={(e) =>
                        setFormData({ ...formData, hero: { ...formData.hero, primaryBtnLink: e.target.value } })
                      }
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white font-mono"
                    />
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
                    <span className="text-xs font-semibold text-slate-300 block">Secondary Button (Outlined)</span>
                    <input
                      type="text"
                      placeholder="Button Text"
                      value={formData.hero.secondaryBtnText}
                      onChange={(e) =>
                        setFormData({ ...formData, hero: { ...formData.hero, secondaryBtnText: e.target.value } })
                      }
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                    />
                    <input
                      type="text"
                      placeholder="Button Link (e.g. #contact)"
                      value={formData.hero.secondaryBtnLink}
                      onChange={(e) =>
                        setFormData({ ...formData, hero: { ...formData.hero, secondaryBtnLink: e.target.value } })
                      }
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white font-mono"
                    />
                  </div>
                </div>

                {/* Floating Metric Badges */}
                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                  <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider block">
                    Floating Portrait Badges
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <span className="text-[11px] text-slate-400 block mb-1">Badge 1</span>
                      <input
                        type="text"
                        placeholder="Value (e.g. 5+)"
                        value={formData.hero.stat1Value}
                        onChange={(e) =>
                          setFormData({ ...formData, hero: { ...formData.hero, stat1Value: e.target.value } })
                        }
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white mb-1.5"
                      />
                      <input
                        type="text"
                        placeholder="Label"
                        value={formData.hero.stat1Label}
                        onChange={(e) =>
                          setFormData({ ...formData, hero: { ...formData.hero, stat1Label: e.target.value } })
                        }
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                      />
                    </div>

                    <div>
                      <span className="text-[11px] text-slate-400 block mb-1">Badge 2</span>
                      <input
                        type="text"
                        placeholder="Value (e.g. 120+)"
                        value={formData.hero.stat2Value}
                        onChange={(e) =>
                          setFormData({ ...formData, hero: { ...formData.hero, stat2Value: e.target.value } })
                        }
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white mb-1.5"
                      />
                      <input
                        type="text"
                        placeholder="Label"
                        value={formData.hero.stat2Label}
                        onChange={(e) =>
                          setFormData({ ...formData, hero: { ...formData.hero, stat2Label: e.target.value } })
                        }
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                      />
                    </div>

                    <div>
                      <span className="text-[11px] text-slate-400 block mb-1">Badge 3</span>
                      <input
                        type="text"
                        placeholder="Value (e.g. 99%)"
                        value={formData.hero.stat3Value}
                        onChange={(e) =>
                          setFormData({ ...formData, hero: { ...formData.hero, stat3Value: e.target.value } })
                        }
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white mb-1.5"
                      />
                      <input
                        type="text"
                        placeholder="Label"
                        value={formData.hero.stat3Label}
                        onChange={(e) =>
                          setFormData({ ...formData, hero: { ...formData.hero, stat3Label: e.target.value } })
                        }
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* Social Links */}
                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-3">
                  <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider block">
                    Social Channel Links
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <span className="text-[11px] text-slate-400 block mb-1">Behance / Portfolio URL</span>
                      <input
                        type="text"
                        value={formData.hero.socials.githubOrBehance}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            hero: {
                              ...formData.hero,
                              socials: { ...formData.hero.socials, githubOrBehance: e.target.value },
                            },
                          })
                        }
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                      />
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block mb-1">LinkedIn URL</span>
                      <input
                        type="text"
                        value={formData.hero.socials.linkedin}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            hero: {
                              ...formData.hero,
                              socials: { ...formData.hero.socials, linkedin: e.target.value },
                            },
                          })
                        }
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                      />
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block mb-1">Dribbble / Instagram URL</span>
                      <input
                        type="text"
                        value={formData.hero.socials.twitter}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            hero: {
                              ...formData.hero,
                              socials: { ...formData.hero.socials, twitter: e.target.value },
                            },
                          })
                        }
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                      />
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block mb-1">Email Address</span>
                      <input
                        type="text"
                        value={formData.hero.socials.email}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            hero: {
                              ...formData.hero,
                              socials: { ...formData.hero.socials, email: e.target.value },
                            },
                          })
                        }
                        className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: ABOUT ME */}
            {activeTab === 'about' && (
              <div className="space-y-6 max-w-4xl">
                <div>
                  <h3 className="text-lg font-bold text-white mb-1">About Me Section Settings</h3>
                  <p className="text-xs text-slate-400">Configure your narrative bio and personal coordinates.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Section Title</label>
                    <input
                      type="text"
                      value={formData.about.sectionTitle}
                      onChange={(e) =>
                        setFormData({ ...formData, about: { ...formData.about, sectionTitle: e.target.value } })
                      }
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Display Name</label>
                    <input
                      type="text"
                      value={formData.about.name}
                      onChange={(e) =>
                        setFormData({ ...formData, about: { ...formData.about, name: e.target.value } })
                      }
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Full Bio Text</label>
                  <textarea
                    rows={4}
                    value={formData.about.bioText}
                    onChange={(e) =>
                      setFormData({ ...formData, about: { ...formData.about, bioText: e.target.value } })
                    }
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-cyan-400 resize-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Location</label>
                    <input
                      type="text"
                      value={formData.about.location}
                      onChange={(e) =>
                        setFormData({ ...formData, about: { ...formData.about, location: e.target.value } })
                      }
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Email</label>
                    <input
                      type="text"
                      value={formData.about.email}
                      onChange={(e) =>
                        setFormData({ ...formData, about: { ...formData.about, email: e.target.value } })
                      }
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Availability Status</label>
                    <input
                      type="text"
                      value={formData.about.availability}
                      onChange={(e) =>
                        setFormData({ ...formData, about: { ...formData.about, availability: e.target.value } })
                      }
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Button Text</label>
                  <input
                    type="text"
                    value={formData.about.buttonText}
                    onChange={(e) =>
                      setFormData({ ...formData, about: { ...formData.about, buttonText: e.target.value } })
                    }
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>
            )}

            {/* TAB 3: SKILLS & EXPERTISE */}
            {activeTab === 'skills' && (
              <div className="space-y-6 max-w-4xl">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-white mb-1">Graphic Design Software &amp; Expertise</h3>
                    <p className="text-xs text-slate-400">Add, edit, adjust percentages, or delete design tools displayed on your profile.</p>
                  </div>
                  <button
                    onClick={handleAddSkill}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Skill</span>
                  </button>
                </div>

                <div className="space-y-3">
                  {formData.skills.map((skill) => (
                    <div
                      key={skill.id}
                      className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 flex flex-col sm:flex-row items-center gap-4"
                    >
                      <div className="flex-1 w-full sm:w-auto">
                        <label className="block text-[11px] text-slate-400 mb-1">Skill / Software Name</label>
                        <input
                          type="text"
                          value={skill.name}
                          onChange={(e) => handleUpdateSkill(skill.id, 'name', e.target.value)}
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                        />
                      </div>

                      <div className="w-full sm:w-48">
                        <div className="flex justify-between text-[11px] mb-1">
                          <span className="text-slate-400">Proficiency</span>
                          <span className="text-cyan-400 font-bold tabular-nums">{skill.level}%</span>
                        </div>
                        <input
                          type="range"
                          min="10"
                          max="100"
                          value={skill.level}
                          onChange={(e) => handleUpdateSkill(skill.id, 'level', Number(e.target.value))}
                          className="w-full accent-cyan-400 cursor-pointer"
                        />
                      </div>

                      <button
                        onClick={() => handleDeleteSkill(skill.id)}
                        className="p-2 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-900 transition-colors cursor-pointer"
                        title="Delete Skill"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 4: SELECTED WORK / PROJECTS */}
            {activeTab === 'projects' && (
              <div className="space-y-6 max-w-4xl">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-white mb-1">Selected Work Projects</h3>
                    <p className="text-xs text-slate-400">
                      Upload project showcase images directly from your computer, set tags, and edit descriptions.
                    </p>
                  </div>
                  <button
                    onClick={handleAddProject}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Project</span>
                  </button>
                </div>

                <div className="space-y-6">
                  {formData.projects.map((proj) => (
                    <div
                      key={proj.id}
                      className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-4"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                          Project #{proj.id.slice(-4)} &middot; {proj.title}
                        </span>
                        <button
                          onClick={() => handleDeleteProject(proj.id)}
                          className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete</span>
                        </button>
                      </div>

                      {/* Direct Project Image Upload from Computer */}
                      <ImageUploadField
                        label="Project Artwork / Mockup Image (Upload from Computer)"
                        value={proj.image}
                        onChange={(newVal) => handleUpdateProject(proj.id, 'image', newVal)}
                        aspectRatioLabel="Landscape 4:3 or 16:9"
                        helpText="Click 'Choose Image from Computer' to upload this project's mockup or vector artwork."
                      />

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] text-slate-400 mb-1">Project Title</label>
                          <input
                            type="text"
                            value={proj.title}
                            onChange={(e) => handleUpdateProject(proj.id, 'title', e.target.value)}
                            className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] text-slate-400 mb-1">Top Badge Tag (e.g. Brand Identity)</label>
                          <input
                            type="text"
                            value={proj.badge}
                            onChange={(e) => handleUpdateProject(proj.id, 'badge', e.target.value)}
                            className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">Description</label>
                        <textarea
                          rows={2}
                          value={proj.description}
                          onChange={(e) => handleUpdateProject(proj.id, 'description', e.target.value)}
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white resize-none"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] text-slate-400 mb-1">Deliverables / Tags (comma-separated)</label>
                          <input
                            type="text"
                            value={proj.tags.join(', ')}
                            onChange={(e) =>
                              handleUpdateProject(
                                proj.id,
                                'tags',
                                e.target.value.split(',').map((t) => t.trim()).filter(Boolean)
                              )
                            }
                            className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] text-slate-400 mb-1">External Case Study Link (Optional)</label>
                          <input
                            type="text"
                            value={proj.link}
                            onChange={(e) => handleUpdateProject(proj.id, 'link', e.target.value)}
                            className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 5: WORK PROCESS */}
            {activeTab === 'process' && (
              <div className="space-y-6 max-w-4xl">
                <div>
                  <h3 className="text-lg font-bold text-white mb-1">Design &amp; Print Process (6 Steps)</h3>
                  <p className="text-xs text-slate-400">Configure each phase of your graphic design and print workflow.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {formData.process.map((step, idx) => (
                    <div key={idx} className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-cyan-400">Step {step.step}</span>
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">Title</label>
                        <input
                          type="text"
                          value={step.title}
                          onChange={(e) => handleUpdateProcess(idx, 'title', e.target.value)}
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">Description</label>
                        <textarea
                          rows={2}
                          value={step.description}
                          onChange={(e) => handleUpdateProcess(idx, 'description', e.target.value)}
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white resize-none"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 6: TESTIMONIALS */}
            {activeTab === 'testimonials' && (
              <div className="space-y-6 max-w-4xl">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-white mb-1">Client Testimonials</h3>
                    <p className="text-xs text-slate-400">Upload client avatars from your computer and manage reviews.</p>
                  </div>
                  <button
                    onClick={handleAddTestimonial}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-950 bg-cyan-400 hover:bg-cyan-300 transition-colors cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Review</span>
                  </button>
                </div>

                <div className="space-y-6">
                  {formData.testimonials.map((test) => (
                    <div
                      key={test.id}
                      className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-cyan-400">{test.clientName}</span>
                        <button
                          onClick={() => handleDeleteTestimonial(test.id)}
                          className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete</span>
                        </button>
                      </div>

                      <ImageUploadField
                        label="Client Avatar Photo (Upload from Computer)"
                        value={test.avatar}
                        onChange={(newVal) => handleUpdateTestimonial(test.id, 'avatar', newVal)}
                        aspectRatioLabel="Square 1:1 Headshot"
                      />

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-[11px] text-slate-400 mb-1">Client Name</label>
                          <input
                            type="text"
                            value={test.clientName}
                            onChange={(e) => handleUpdateTestimonial(test.id, 'clientName', e.target.value)}
                            className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-400 mb-1">Role</label>
                          <input
                            type="text"
                            value={test.role}
                            onChange={(e) => handleUpdateTestimonial(test.id, 'role', e.target.value)}
                            className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-400 mb-1">Company</label>
                          <input
                            type="text"
                            value={test.company}
                            onChange={(e) => handleUpdateTestimonial(test.id, 'company', e.target.value)}
                            className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">Quote Text</label>
                        <textarea
                          rows={2}
                          value={test.quote}
                          onChange={(e) => handleUpdateTestimonial(test.id, 'quote', e.target.value)}
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white resize-none"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 7: STATS (BY THE NUMBERS) */}
            {activeTab === 'stats' && (
              <div className="space-y-6 max-w-4xl">
                <div>
                  <h3 className="text-lg font-bold text-white mb-1">By The Numbers (KPI Stats)</h3>
                  <p className="text-xs text-slate-400">Configure the 4 stat counters showcased on the site.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {formData.stats.map((stat) => (
                    <div key={stat.id} className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] text-slate-400 mb-1">Stat Value</label>
                          <input
                            type="text"
                            value={stat.value}
                            onChange={(e) => handleUpdateStat(stat.id, 'value', e.target.value)}
                            className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-sm font-bold text-cyan-400"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-400 mb-1">Stat Label</label>
                          <input
                            type="text"
                            value={stat.label}
                            onChange={(e) => handleUpdateStat(stat.id, 'label', e.target.value)}
                            className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 8: CONTACT INFO */}
            {activeTab === 'contact' && (
              <div className="space-y-6 max-w-4xl">
                <div>
                  <h3 className="text-lg font-bold text-white mb-1">Contact Section Settings</h3>
                  <p className="text-xs text-slate-400">Manage inquiry prompts, direct email, phone, and location.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Section Title</label>
                    <input
                      type="text"
                      value={formData.contact.title}
                      onChange={(e) =>
                        setFormData({ ...formData, contact: { ...formData.contact, title: e.target.value } })
                      }
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Button Submit Text</label>
                    <input
                      type="text"
                      value={formData.contact.submitBtnText}
                      onChange={(e) =>
                        setFormData({ ...formData, contact: { ...formData.contact, submitBtnText: e.target.value } })
                      }
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Description Subtitle</label>
                  <textarea
                    rows={2}
                    value={formData.contact.description}
                    onChange={(e) =>
                      setFormData({ ...formData, contact: { ...formData.contact, description: e.target.value } })
                    }
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100 resize-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Email</label>
                    <input
                      type="text"
                      value={formData.contact.email}
                      onChange={(e) =>
                        setFormData({ ...formData, contact: { ...formData.contact, email: e.target.value } })
                      }
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Phone / WhatsApp</label>
                    <input
                      type="text"
                      value={formData.contact.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, contact: { ...formData.contact, phone: e.target.value } })
                      }
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Location</label>
                    <input
                      type="text"
                      value={formData.contact.location}
                      onChange={(e) =>
                        setFormData({ ...formData, contact: { ...formData.contact, location: e.target.value } })
                      }
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Availability Label</label>
                    <input
                      type="text"
                      value={formData.contact.availability}
                      onChange={(e) =>
                        setFormData({ ...formData, contact: { ...formData.contact, availability: e.target.value } })
                      }
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* TAB 9: INBOX (RECEIVED MESSAGES) */}
            {activeTab === 'inbox' && (
              <div className="space-y-6 max-w-4xl">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-white mb-1">
                      Received Inquiries ({formData.messages.length})
                    </h3>
                    <p className="text-xs text-slate-400">Review client messages submitted directly through your contact form.</p>
                  </div>
                  {formData.messages.length > 0 && (
                    <button
                      onClick={handleClearMessages}
                      className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Clear All</span>
                    </button>
                  )}
                </div>

                {formData.messages.length === 0 ? (
                  <div className="p-12 text-center rounded-2xl bg-slate-950/40 border border-slate-800">
                    <Mail className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                    <p className="text-sm font-semibold text-slate-300">No Inquiries Yet</p>
                    <p className="text-xs text-slate-500 mt-1">When visitors submit the contact form, their inquiries appear here.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {formData.messages.map((msg) => (
                      <div
                        key={msg.id}
                        className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-white">{msg.name}</span>
                            <span className="text-xs text-cyan-400">&lt;{msg.email}&gt;</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="text-[11px] text-slate-500">{msg.date}</span>
                            <button
                              onClick={() => handleDeleteMessage(msg.id)}
                              className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                              title="Delete Message"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <div className="text-xs font-semibold text-slate-300">
                          Subject: <span className="text-cyan-300">{msg.subject}</span>
                        </div>

                        <p className="text-xs sm:text-sm text-slate-300 bg-slate-900/80 p-3 rounded-xl border border-slate-800/80 leading-relaxed">
                          {msg.message}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 10: BRANDING & NAVIGATION & CV MANAGEMENT */}
            {activeTab === 'branding' && (
              <div className="space-y-6 max-w-4xl">
                <div>
                  <h3 className="text-lg font-bold text-white mb-1">Branding &amp; CV Management</h3>
                  <p className="text-xs text-slate-400">
                    Customize your brand identity wordmark, monogram initials, and upload your CV (both PDF &amp; Graphic Image).
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Brand Full Name</label>
                    <input
                      type="text"
                      value={formData.branding.name}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          branding: { ...formData.branding, name: e.target.value },
                          footer: { ...formData.footer, copyrightName: e.target.value },
                        })
                      }
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Brand Monogram Initials</label>
                    <input
                      type="text"
                      maxLength={4}
                      value={formData.branding.initials}
                      onChange={(e) =>
                        setFormData({ ...formData, branding: { ...formData.branding, initials: e.target.value } })
                      }
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100 uppercase font-mono"
                    />
                  </div>
                </div>

                {/* CV PDF Document Upload Section */}
                <div className="p-5 rounded-2xl bg-slate-950/80 border border-cyan-500/30 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs uppercase tracking-wider">
                      <FileText className="w-4 h-4" />
                      <span>CV Document (PDF Format)</span>
                    </div>
                    {formData.branding.cvPdfUrl && (
                      <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        <span>Custom PDF Attached</span>
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400">
                    Upload your custom curriculum vitae PDF directly from your computer, or enter an external URL.
                  </p>

                  <div className="flex flex-wrap items-center gap-3">
                    <label className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-cyan-400 to-cyan-300 hover:from-cyan-300 hover:to-white shadow-md shadow-cyan-500/20 transition-all cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      <span>{isProcessingPdf ? 'Processing PDF...' : 'Choose PDF from Computer'}</span>
                      <input
                        type="file"
                        accept="application/pdf"
                        disabled={isProcessingPdf}
                        onChange={handlePdfUpload}
                        className="hidden"
                      />
                    </label>

                    {formData.branding.cvPdfUrl && (
                      <>
                        <a
                          href={formData.branding.cvPdfUrl}
                          target="_blank"
                          rel="noreferrer"
                          download={`${formData.branding.name.replace(/\s+/g, '_')}_CV.pdf`}
                          className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium text-cyan-300 bg-cyan-950/70 border border-cyan-800/60 hover:bg-cyan-900 transition-colors"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Test Download</span>
                        </a>

                        <button
                          type="button"
                          onClick={() =>
                            setFormData({
                              ...formData,
                              branding: { ...formData.branding, cvPdfUrl: '' },
                            })
                          }
                          className="flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-medium text-rose-400 hover:bg-rose-950/40 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Remove PDF</span>
                        </button>
                      </>
                    )}
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                      Or Remote PDF Link (Google Drive / Dropbox)
                    </label>
                    <input
                      type="text"
                      value={formData.branding.cvPdfUrl.startsWith('data:') ? 'Custom local file uploaded' : formData.branding.cvPdfUrl}
                      disabled={formData.branding.cvPdfUrl.startsWith('data:')}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          branding: { ...formData.branding, cvPdfUrl: e.target.value },
                        })
                      }
                      placeholder="https://example.com/my-cv.pdf"
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 font-mono disabled:opacity-60"
                    />
                  </div>
                </div>

                {/* CV Graphic Image Upload Section */}
                <div className="p-5 rounded-2xl bg-slate-950/80 border border-blue-500/30 space-y-3">
                  <div className="flex items-center gap-2 text-blue-400 font-bold text-xs uppercase tracking-wider">
                    <Upload className="w-4 h-4" />
                    <span>CV Resume Image (JPG / PNG Format)</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Upload a high-resolution visual/graphic image version of your resume from your computer.
                  </p>

                  <ImageUploadField
                    label="Resume Image File"
                    value={formData.branding.cvImageUrl}
                    onChange={(url) =>
                      setFormData({
                        ...formData,
                        branding: { ...formData.branding, cvImageUrl: url },
                      })
                    }
                    aspectRatioLabel="Recommended: Portrait A4 or Vertical High-Res"
                    helpText="PNG, JPG, or WebP. Automatically optimized for web storage."
                  />
                </div>

                {/* External Portfolio / Direct Cloud Link */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Direct Cloud Portfolio / Drive Link (Optional)
                  </label>
                  <input
                    type="text"
                    value={formData.branding.cvDirectUrl || ''}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        branding: { ...formData.branding, cvDirectUrl: e.target.value },
                      })
                    }
                    placeholder="https://drive.google.com/..."
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100 font-mono"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">
                    Displays an optional direct cloud link button in the public CV modal.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Footer Copyright Year</label>
                  <input
                    type="text"
                    value={formData.footer.year}
                    onChange={(e) =>
                      setFormData({ ...formData, footer: { ...formData.footer, year: e.target.value } })
                    }
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100"
                  />
                </div>
              </div>
            )}

            {/* TAB 11: HARDENED SECURITY & ADMIN AUTH SETTINGS */}
            {activeTab === 'security' && (
              <div className="space-y-6 max-w-4xl">
                <div>
                  <h3 className="text-lg font-bold text-white mb-1">Security &amp; Password Management</h3>
                  <p className="text-xs text-slate-400">
                    Hardened security controls: To change your admin password, you must enter and verify your current password first.
                  </p>
                </div>

                {/* Hardened Password Change Form */}
                <form onSubmit={handleUpdatePassword} className="p-6 rounded-2xl bg-slate-950/80 border border-cyan-500/30 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                      <Lock className="w-4 h-4" />
                      <span>Secure Password &amp; Credential Update</span>
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      Current User: <strong className="text-cyan-300">{formData.admin.username}</strong>
                    </span>
                  </div>

                  {/* Username Field */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Admin Username</label>
                    <input
                      type="text"
                      value={adminUsername}
                      onChange={(e) => setAdminUsername(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-sm text-slate-100 focus:border-cyan-400"
                    />
                  </div>

                  {/* Step 1: Current Password */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center justify-between">
                      <span>Step 1: Current Password (Verification Required) *</span>
                      <span className="text-[10px] text-amber-400 font-normal">Must match existing password</span>
                    </label>
                    <div className="relative">
                      <input
                        type={showOldPass ? 'text' : 'password'}
                        required
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        placeholder="Enter your current password to verify identity"
                        className="w-full pl-3.5 pr-10 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-sm text-slate-100 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-colors"
                      />
                      <button
                        type="button"
                        onClick={() => setShowOldPass(!showOldPass)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer"
                      >
                        {showOldPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Step 2 & 3: New Password and Confirmation */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Step 2: New Password (Min 6 characters) *
                      </label>
                      <div className="relative">
                        <input
                          type={showNewPass ? 'text' : 'password'}
                          required
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          placeholder="Enter strong new password"
                          className="w-full pl-3.5 pr-10 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-sm text-slate-100 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-colors"
                        />
                        <button
                          type="button"
                          onClick={() => setShowNewPass(!showNewPass)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer"
                        >
                          {showNewPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1">
                        Step 3: Confirm New Password *
                      </label>
                      <div className="relative">
                        <input
                          type={showConfirmPass ? 'text' : 'password'}
                          required
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          placeholder="Re-type new password"
                          className="w-full pl-3.5 pr-10 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-sm text-slate-100 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-colors"
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPass(!showConfirmPass)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer"
                        >
                          {showConfirmPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Security Error Alert */}
                  {securityError && (
                    <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-950/70 border border-rose-800 text-rose-300 text-xs animate-in fade-in">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{securityError}</span>
                    </div>
                  )}

                  {/* Security Success Alert */}
                  {securitySuccess && (
                    <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-950/70 border border-emerald-700 text-emerald-300 text-xs animate-in fade-in">
                      <Check className="w-4 h-4 shrink-0" />
                      <span>{securitySuccess}</span>
                    </div>
                  )}

                  <div className="pt-2 flex items-center justify-between">
                    <p className="text-[11px] text-slate-400">
                      * Security rule: Current password must match before updates are committed.
                    </p>
                    <button
                      type="submit"
                      className="px-5 py-2.5 rounded-xl font-bold text-xs text-slate-950 bg-gradient-to-r from-cyan-400 to-cyan-300 hover:from-cyan-300 hover:to-white shadow-lg shadow-cyan-500/25 transition-all cursor-pointer flex items-center gap-1.5"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Verify &amp; Update Password</span>
                    </button>
                  </div>
                </form>

                {/* Backup & Restore */}
                <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-4">
                  <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider block">
                    Data Backup &amp; Migration
                  </span>

                  <div className="flex flex-wrap items-center gap-4">
                    <button
                      onClick={handleExportJSON}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 transition-colors cursor-pointer"
                    >
                      <Download className="w-4 h-4 text-cyan-400" />
                      <span>Export JSON Backup</span>
                    </button>

                    <label className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 transition-colors cursor-pointer">
                      <Upload className="w-4 h-4 text-cyan-400" />
                      <span>Import JSON Backup</span>
                      <input
                        type="file"
                        accept=".json"
                        onChange={handleImportJSON}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>

                {/* Danger Zone */}
                <div className="p-5 rounded-2xl bg-rose-950/20 border border-rose-900/40 space-y-3">
                  <span className="text-xs font-bold text-rose-400 uppercase tracking-wider block">
                    Reset To Original Factory Defaults
                  </span>
                  <p className="text-xs text-slate-400">
                    Restores initial graphic design portfolio data and resets credentials to default.
                  </p>
                  <button
                    onClick={handleResetDefaults}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-rose-300 bg-rose-950/60 border border-rose-800/80 hover:bg-rose-900/60 transition-colors cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reset All Data</span>
                  </button>
                </div>
              </div>
            )}

          </main>

        </div>

      </div>
    </div>
  );
};
