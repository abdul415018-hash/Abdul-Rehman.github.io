import { SiteColorCustomization } from '../data/customColors';

const SECTION_ID_MAP: Record<string, string> = {
  hero: '#home',
  services: '#services',
  projects: '#projects',
  about: '#about',
  process: '#process',
  testimonials: '#testimonials',
  contact: '#contact',
};

export function generateCustomColorStyles(customization?: SiteColorCustomization): string {
  if (!customization || !customization.enabled) {
    return '';
  }

  const rules: string[] = [];
  const { global, sections } = customization;

  // 1. Global Overrides
  if (global.bgColor) {
    rules.push(`
      :root { --bg-canvas: ${global.bgColor} !important; }
      #root > div { background-color: ${global.bgColor} !important; }
      body { background-color: ${global.bgColor} !important; }
    `);
  }

  if (global.headingColor) {
    rules.push(`
      h1, h2, h3, h4, h5, h6,
      .text-white,
      .light-theme\\:text-slate-900 {
        color: ${global.headingColor} !important;
      }
    `);
  }

  if (global.textColor) {
    rules.push(`
      p,
      .text-slate-300,
      .text-slate-400,
      .text-slate-500,
      .text-zinc-400,
      .light-theme\\:text-slate-600 {
        color: ${global.textColor} !important;
      }
    `);
  }

  if (global.cardBgColor) {
    rules.push(`
      .spatial-surface,
      div[class*="bg-slate-900/80"],
      div[class*="bg-slate-900/60"],
      div[class*="bg-slate-900/90"],
      div[class*="bg-[#0c1024]"] {
        background-color: ${global.cardBgColor} !important;
      }
    `);
  }

  if (global.accentColor) {
    rules.push(`
      :root {
        --template-accent: ${global.accentColor} !important;
      }
      .text-cyan-400,
      .text-cyan-300,
      .text-cyan-500 {
        color: ${global.accentColor} !important;
      }
    `);
  }

  if (global.borderColor) {
    rules.push(`
      div[class*="border-slate-800"],
      div[class*="border-slate-700"] {
        border-color: ${global.borderColor} !important;
      }
    `);
  }

  // 2. Section Specific Overrides
  if (sections) {
    Object.entries(sections).forEach(([key, section]) => {
      if (!section) return;
      const selector = SECTION_ID_MAP[key];
      if (!selector) return;

      if (section.bgColor) {
        rules.push(`
          ${selector} {
            background-color: ${section.bgColor} !important;
          }
        `);
      }

      if (section.headingColor) {
        rules.push(`
          ${selector} h1,
          ${selector} h2,
          ${selector} h3,
          ${selector} h4,
          ${selector} .text-white {
            color: ${section.headingColor} !important;
          }
        `);
      }

      if (section.textColor) {
        rules.push(`
          ${selector} p,
          ${selector} .text-slate-300,
          ${selector} .text-slate-400,
          ${selector} .text-slate-500,
          ${selector} .text-zinc-400 {
            color: ${section.textColor} !important;
          }
        `);
      }

      if (section.cardBgColor) {
        rules.push(`
          ${selector} .spatial-surface,
          ${selector} div[class*="bg-slate-900"],
          ${selector} div[class*="bg-[#0c1024]"],
          ${selector} div[class*="rounded-2xl"],
          ${selector} div[class*="rounded-3xl"] {
            background-color: ${section.cardBgColor} !important;
          }
        `);
      }

      if (section.accentColor) {
        rules.push(`
          ${selector} .text-cyan-400,
          ${selector} .text-cyan-300 {
            color: ${section.accentColor} !important;
          }
        `);
      }

      if (section.borderColor) {
        rules.push(`
          ${selector} .spatial-surface,
          ${selector} div[class*="border-slate-800"],
          ${selector} div[class*="border-slate-700"],
          ${selector} div[class*="border-"] {
            border-color: ${section.borderColor} !important;
          }
        `);
      }
    });
  }

  return rules.join('\n');
}
