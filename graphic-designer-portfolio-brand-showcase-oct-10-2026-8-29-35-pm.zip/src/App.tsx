/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  PortfolioData,
  ProjectItem,
  ContactMessage,
  loadPortfolioData,
  savePortfolioData,
  defaultPortfolioData
} from './data/portfolioData';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutAndExpertise } from './components/AboutAndExpertise';
import { SelectedWork } from './components/SelectedWork';
import { WorkProcess } from './components/WorkProcess';
import { TestimonialsAndNumbers } from './components/TestimonialsAndNumbers';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { ProjectLightboxModal } from './components/ProjectLightboxModal';
import { DownloadCVModal } from './components/DownloadCVModal';
import { MagneticCursor } from './components/MagneticCursor';
import { ServicesSection } from './components/ServicesSection';
import { TEMPLATES } from './data/templates';
import { TemplateMotionEngine } from './components/motion/TemplateMotionEngine';
import { AdminLoginModal } from './components/admin/AdminLoginModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { generateCustomColorStyles } from './utils/generateCustomColorStyles';

export default function App() {
  const [data, setData] = useState<PortfolioData>(() => loadPortfolioData());
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const [isCVModalOpen, setIsCVModalOpen] = useState(false);
  
  // Admin authentication and panel states
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [isAdminLoginOpen, setIsAdminLoginOpen] = useState(false);
  const [isAdminDashboardOpen, setIsAdminDashboardOpen] = useState(false);

  // Automatic dark/light mode system detection (strictly follows visitor's OS/device setting)
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return true;
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

    const syncTheme = (matchesDark: boolean) => {
      setIsDarkMode(matchesDark);
      if (matchesDark) {
        document.documentElement.classList.add('dark');
        document.documentElement.classList.remove('light-theme');
      } else {
        document.documentElement.classList.remove('dark');
        document.documentElement.classList.add('light-theme');
      }
    };

    // Initial check
    syncTheme(mediaQuery.matches);

    // Dynamic live listener when user changes system theme
    const handleThemeChange = (e: MediaQueryListEvent) => {
      syncTheme(e.matches);
    };

    mediaQuery.addEventListener('change', handleThemeChange);
    return () => mediaQuery.removeEventListener('change', handleThemeChange);
  }, []);

  // Keyboard shortcut (Ctrl+Shift+A) or hash (#admin) trigger for admin panel
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'A' || e.key === 'a')) {
        e.preventDefault();
        openAdminFlow();
      }
    };

    const handleHashChange = () => {
      if (window.location.hash === '#admin') {
        openAdminFlow();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('hashchange', handleHashChange);
    
    // Check initial hash
    if (window.location.hash === '#admin') {
      openAdminFlow();
    }

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, [isAdminAuthenticated]);

  const openAdminFlow = () => {
    if (isAdminAuthenticated) {
      setIsAdminDashboardOpen(true);
    } else {
      setIsAdminLoginOpen(true);
    }
  };

  const handleLoginSuccess = () => {
    setIsAdminAuthenticated(true);
    setIsAdminLoginOpen(false);
    setIsAdminDashboardOpen(true);
  };

  const handleLogout = () => {
    setIsAdminAuthenticated(false);
    setIsAdminDashboardOpen(false);
  };

  const handleSaveData = (newData: PortfolioData) => {
    savePortfolioData(newData);
    setData(newData);
  };

  const handleNewMessage = (newMsg: ContactMessage) => {
    const updated: PortfolioData = {
      ...data,
      messages: [newMsg, ...data.messages],
    };
    handleSaveData(updated);
  };

  const activeTemplate = TEMPLATES.find((t) => t.id === data.activeTemplateId) || TEMPLATES[0];
  const customStyles = generateCustomColorStyles(data.colorCustomization);

  return (
    <div
      className={`min-h-screen bg-[var(--bg-canvas)] text-[var(--text-primary)] selection:bg-cyan-500 selection:text-slate-950 font-body relative overflow-x-hidden transition-colors duration-500 ${activeTemplate.themeClass}`}
      style={{
        '--template-accent': activeTemplate.accentColor,
        '--template-secondary': activeTemplate.secondaryColor,
      } as React.CSSProperties}
    >
      {/* Injected Granular Custom Color Overrides */}
      {customStyles && <style id="custom-color-overrides">{customStyles}</style>}

      {/* Physics-driven Spatial Magnetic Cursor (Snaps to interactive triggers) */}
      <MagneticCursor />
      
      {/* Live Atmospheric Motion Graphics Engine (Bunting Garlands, Flags, Lanterns, Stars) */}
      <TemplateMotionEngine
        activeTemplate={activeTemplate}
        motionConfig={data.motionConfig}
      />

      {/* Background Ambient Cyber Grid & Glow Accents (Adapts to Active Template & Dark / Light) */}
      <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
        {/* Subtle grid pattern */}
        <div
          className="absolute inset-0 opacity-[0.035] light-theme:opacity-[0.04]"
          style={{
            backgroundImage: `radial-gradient(${activeTemplate.accentColor} 1px, transparent 1px)`,
            backgroundSize: '32px 32px'
          }}
        />
        {/* Top template aura */}
        <div
          className="absolute -top-[280px] left-1/2 -translate-x-1/2 w-[900px] h-[550px] rounded-full blur-[160px] opacity-25"
          style={{ backgroundColor: activeTemplate.accentColor }}
        />
        {/* Mid-page secondary aura */}
        <div
          className="absolute top-[35%] -left-[200px] w-[600px] h-[600px] rounded-full blur-[170px] opacity-20"
          style={{ backgroundColor: activeTemplate.secondaryColor }}
        />
        {/* Lower page aura */}
        <div
          className="absolute top-[70%] -right-[200px] w-[700px] h-[700px] rounded-full blur-[180px] opacity-15"
          style={{ backgroundColor: activeTemplate.accentColor }}
        />
      </div>

      {/* Navigation Bar - 100% Clean Public Interface */}
      <Navbar
        branding={data.branding}
        onOpenCVModal={() => setIsCVModalOpen(true)}
      />

      {/* Main Content Sections */}
      <main>
        {/* Hero Section */}
        <Hero hero={data.hero} />

        {/* About & Technical Capabilities */}
        <AboutAndExpertise
          about={data.about}
          skillsTitle={data.skillsTitle}
          skills={data.skills}
          onOpenCVModal={() => setIsCVModalOpen(true)}
        />

        {/* Graphic Design Services & Commercial Packages Section */}
        <ServicesSection
          servicesConfig={data.servicesConfig || defaultPortfolioData.servicesConfig}
          services={data.services || defaultPortfolioData.services}
          primaryAccent={activeTemplate.accentColor}
        />

        {/* Selected Work Portfolio (3-Card Grid) */}
        <SelectedWork
          projectsTitle={data.projectsTitle}
          projects={data.projects}
          onSelectProject={(project) => setSelectedProject(project)}
        />

        {/* 6-Step Work Process */}
        <WorkProcess
          processTitle={data.processTitle}
          process={data.process}
        />

        {/* What Clients Say & By The Numbers */}
        <TestimonialsAndNumbers
          testimonialsTitle={data.testimonialsTitle}
          testimonials={data.testimonials}
          statsTitle={data.statsTitle}
          stats={data.stats}
        />

        {/* Contact Coordinates & Message Form */}
        <ContactSection
          contact={data.contact}
          onNewMessage={handleNewMessage}
        />
      </main>

      {/* Footer with Discreet Admin Portal Link */}
      <Footer
        branding={data.branding}
        footer={data.footer}
        onOpenAdmin={openAdminFlow}
      />

      {/* Discreet Floating Admin Button */}
      <button
        onClick={openAdminFlow}
        className="fixed bottom-5 right-5 z-30 p-2.5 rounded-full bg-slate-900/90 hover:bg-cyan-950 border border-slate-700/80 hover:border-cyan-400 text-slate-400 hover:text-cyan-300 shadow-xl shadow-black/60 transition-all flex items-center gap-1.5 text-xs font-medium backdrop-blur-md cursor-pointer group"
        title="Admin Control Panel (Password Protected)"
        aria-label="Open Admin Control Panel"
      >
        <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
        <span className="text-[11px] font-semibold text-slate-300">Admin 🔒</span>
      </button>

      {/* Project Lightbox Modal */}
      <ProjectLightboxModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />

      {/* Printable / Downloadable CV Modal */}
      <DownloadCVModal
        isOpen={isCVModalOpen}
        onClose={() => setIsCVModalOpen(false)}
        data={data}
      />

      {/* Admin Login Modal (Username + Password protected) */}
      <AdminLoginModal
        isOpen={isAdminLoginOpen}
        onClose={() => setIsAdminLoginOpen(false)}
        adminCredentials={data.admin}
        onLoginSuccess={handleLoginSuccess}
      />

      {/* Master Admin Dashboard (Controls EVERY SINGLE THING) */}
      <AdminDashboard
        isOpen={isAdminDashboardOpen}
        onClose={() => setIsAdminDashboardOpen(false)}
        data={data}
        onSaveData={handleSaveData}
        onLogout={handleLogout}
      />

    </div>
  );
}
