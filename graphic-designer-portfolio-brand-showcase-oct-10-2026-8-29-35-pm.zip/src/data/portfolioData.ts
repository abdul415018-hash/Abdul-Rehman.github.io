export interface AdminCredentials {
  username: string;
  passwordHash: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  date: string;
  read: boolean;
}

export interface HeroConfig {
  badgeText: string;
  headlinePrefix: string;
  headlineHighlight: string;
  headlineSuffix: string;
  bioText: string;
  primaryBtnText: string;
  primaryBtnLink: string;
  secondaryBtnText: string;
  secondaryBtnLink: string;
  portraitImage: string;
  stat1Value: string;
  stat1Label: string;
  stat2Value: string;
  stat2Label: string;
  stat3Value: string;
  stat3Label: string;
  bottomBannerText: string;
  socials: {
    githubOrBehance: string;
    linkedin: string;
    twitter: string;
    email: string;
  };
}

export interface AboutConfig {
  sectionTitle: string;
  bioText: string;
  name: string;
  location: string;
  email: string;
  availability: string;
  buttonText: string;
}

export interface SkillItem {
  id: string;
  name: string;
  level: number;
}

export interface ProjectItem {
  id: string;
  title: string;
  badge: string;
  category: string;
  description: string;
  image: string;
  tags: string[];
  link: string;
}

export interface ProcessStep {
  step: string;
  title: string;
  description: string;
}

export interface TestimonialItem {
  id: string;
  clientName: string;
  role: string;
  company: string;
  avatar: string;
  quote: string;
}

export interface StatItem {
  id: string;
  value: string;
  label: string;
}

export interface ContactConfig {
  title: string;
  description: string;
  email: string;
  phone: string;
  location: string;
  availability: string;
  submitBtnText: string;
}

import {
  ServiceItem,
  ServicesConfig,
  TemplateMotionConfig,
  defaultServices,
  defaultServicesConfig,
  defaultMotionConfig,
} from './templates';
import {
  SiteColorCustomization,
  defaultColorCustomization,
} from './customColors';

export interface BrandingConfig {
  name: string;
  initials: string;
  cvPdfUrl: string;
  cvImageUrl: string;
  cvDirectUrl?: string;
}

export interface PortfolioData {
  activeTemplateId: string;
  motionConfig: TemplateMotionConfig;
  colorCustomization?: SiteColorCustomization;
  servicesConfig: ServicesConfig;
  services: ServiceItem[];
  branding: BrandingConfig;
  hero: HeroConfig;
  about: AboutConfig;
  skillsTitle: string;
  skills: SkillItem[];
  projectsTitle: string;
  projects: ProjectItem[];
  processTitle: string;
  process: ProcessStep[];
  testimonialsTitle: string;
  testimonials: TestimonialItem[];
  statsTitle: string;
  stats: StatItem[];
  contact: ContactConfig;
  footer: {
    copyrightName: string;
    year: string;
  };
  admin: AdminCredentials;
  messages: ContactMessage[];
}

export const defaultPortfolioData: PortfolioData = {
  activeTemplateId: 'independence-day',
  motionConfig: defaultMotionConfig,
  colorCustomization: defaultColorCustomization,
  servicesConfig: defaultServicesConfig,
  services: defaultServices,
  branding: {
    name: "Abdul Tariq",
    initials: "AT",
    cvPdfUrl: "",
    cvImageUrl: "",
    cvDirectUrl: "",
  },
  hero: {
    badgeText: "Graphic & Brand Designer",
    headlinePrefix: "I create",
    headlineHighlight: "visual identities",
    headlineSuffix: "that leave a mark.",
    bioText: "I'm Abdul Tariq, a dedicated brand identity and graphic designer specializing in precision vector marks, corporate identity systems, and luxury print packaging.",
    primaryBtnText: "View My Work",
    primaryBtnLink: "#projects",
    secondaryBtnText: "Let's Talk",
    secondaryBtnLink: "#contact",
    portraitImage: "/src/assets/images/designer_portrait_1791553021344.jpg",
    stat1Value: "5+",
    stat1Label: "Years Experience",
    stat2Value: "120+",
    stat2Label: "Projects Done",
    stat3Value: "99%",
    stat3Label: "Client Satisfaction",
    bottomBannerText: "Vector Craft · Golden Ratio · Print Prepress",
    socials: {
      githubOrBehance: "https://behance.net",
      linkedin: "https://linkedin.com",
      twitter: "https://dribbble.com",
      email: "abdul415018@gmail.com",
    },
  },
  about: {
    sectionTitle: "About Me",
    bioText: "I'm a graphic designer with a strong focus on brand identities, mathematical vector geometry, packaging die-lines, and editorial print production. I bridge the gap between creative artistry and production-grade prepress.",
    name: "Abdul Tariq",
    location: "Lahore, Pakistan",
    email: "abdul415018@gmail.com",
    availability: "Open to Select Projects",
    buttonText: "More About Me",
  },
  skillsTitle: "My Expertise",
  skills: [
    { id: "sk1", name: "Adobe Illustrator (Vector Mastery & Logos)", level: 96 },
    { id: "sk2", name: "Adobe Photoshop (Digital Imaging & Mockups)", level: 92 },
    { id: "sk3", name: "CorelDraw (Pre-press & Large Format)", level: 88 },
    { id: "sk4", name: "Adobe InDesign (Editorial & Publications)", level: 85 },
    { id: "sk5", name: "Vector Geometry & Golden Ratio Marks", level: 94 },
    { id: "sk6", name: "Packaging Die-lines & Print Prepress", level: 90 },
  ],
  projectsTitle: "Selected Work",
  projects: [
    {
      id: "p1",
      title: "Aeterna Luxury Brand Identity",
      badge: "Brand Identity",
      category: "branding",
      description: "Complete visual identity system, hot foil business stationery, and brand guidelines for luxury goods.",
      image: "/src/assets/images/brand_identity_mockup_1791553041005.jpg",
      tags: ["Illustrator", "Photoshop", "Stationery", "Foil Stamp"],
      link: "#",
    },
    {
      id: "p2",
      title: "Precision Vector Insignia Collection",
      badge: "Logo Design",
      category: "logo",
      description: "Golden ratio circular marks, symmetry explorations, and responsive vector insignias.",
      image: "/src/assets/images/vector_logo_showcase_1791553054766.jpg",
      tags: ["Illustrator", "CorelDraw", "Golden Ratio", "Vector Grid"],
      link: "#",
    },
    {
      id: "p3",
      title: "Aurora Midnight Cosmetic Packaging",
      badge: "Packaging",
      category: "packaging",
      description: "Matte black cosmetic dropper bottle, custom structural box die-line CAD, and spot UV details.",
      image: "/src/assets/images/premium_packaging_mockup_1791553070402.jpg",
      tags: ["Illustrator", "CorelDraw", "Die-lines", "Spot UV"],
      link: "#",
    },
  ],
  processTitle: "My Work Process",
  process: [
    {
      step: "01",
      title: "Discover",
      description: "Understanding brand goals, requirements and creative scope.",
    },
    {
      step: "02",
      title: "Strategy",
      description: "Synthesizing market positioning, competitor audit and moodboards.",
    },
    {
      step: "03",
      title: "Design",
      description: "Pen-to-paper exploratory sketching and golden ratio construction.",
    },
    {
      step: "04",
      title: "Vector",
      description: "Mathematical bezier curve craft and grid balancing in Illustrator.",
    },
    {
      step: "05",
      title: "Proof",
      description: "CMYK prepress calibration, spot UV proofs and 3D mockups.",
    },
    {
      step: "06",
      title: "Delivery",
      description: "Packaging master vector files .AI/.EPS/.SVG/.PDF with brand manual.",
    },
  ],
  testimonialsTitle: "What Clients Say",
  testimonials: [
    {
      id: "t1",
      clientName: "Hamza Ali",
      role: "CEO",
      company: "TechSolutions",
      avatar: "/src/assets/images/hamza_ali_avatar_1791559902602.jpg",
      quote: "Abdul is an exceptional brand designer! He transformed our company identity with razor-sharp precision, golden-ratio elegance, and high-impact print collateral. Highly recommended!",
    },
  ],
  statsTitle: "By The Numbers",
  stats: [
    { id: "s1", value: "45+", label: "Happy Clients" },
    { id: "s2", value: "120+", label: "Projects Completed" },
    { id: "s3", value: "5+", label: "Years Experience" },
    { id: "s4", value: "99%", label: "Satisfaction Rate" },
  ],
  contact: {
    title: "Let's Build Something Great",
    description: "Have a branding project, logo design, packaging die-line, or print publication in mind? I'd love to hear from you.",
    email: "abdul415018@gmail.com",
    phone: "+92 310 1234567",
    location: "Lahore, Pakistan",
    availability: "Open to new opportunities",
    submitBtnText: "Send Message",
  },
  footer: {
    copyrightName: "Abdul Tariq",
    year: "2024",
  },
  admin: {
    username: "admin",
    passwordHash: "admin123",
  },
  messages: [],
};

const STORAGE_KEY = "abdul_graphic_portfolio_v7";

export function loadPortfolioData(): PortfolioData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultPortfolioData;
    const parsed = JSON.parse(raw);
    return {
      ...defaultPortfolioData,
      ...parsed,
      activeTemplateId: parsed.activeTemplateId || defaultPortfolioData.activeTemplateId,
      motionConfig: { ...defaultPortfolioData.motionConfig, ...(parsed.motionConfig || {}) },
      colorCustomization: {
        ...defaultColorCustomization,
        ...(parsed.colorCustomization || {}),
        global: { ...defaultColorCustomization.global, ...(parsed.colorCustomization?.global || {}) },
        sections: {
          hero: { ...(parsed.colorCustomization?.sections?.hero || {}) },
          services: { ...(parsed.colorCustomization?.sections?.services || {}) },
          projects: { ...(parsed.colorCustomization?.sections?.projects || {}) },
          about: { ...(parsed.colorCustomization?.sections?.about || {}) },
          process: { ...(parsed.colorCustomization?.sections?.process || {}) },
          testimonials: { ...(parsed.colorCustomization?.sections?.testimonials || {}) },
          contact: { ...(parsed.colorCustomization?.sections?.contact || {}) },
        }
      },
      servicesConfig: { ...defaultPortfolioData.servicesConfig, ...(parsed.servicesConfig || {}) },
      services: Array.isArray(parsed.services) && parsed.services.length > 0 ? parsed.services : defaultPortfolioData.services,
      branding: { ...defaultPortfolioData.branding, ...(parsed.branding || {}) },
      hero: { ...defaultPortfolioData.hero, ...(parsed.hero || {}) },
      about: { ...defaultPortfolioData.about, ...(parsed.about || {}) },
      contact: { ...defaultPortfolioData.contact, ...(parsed.contact || {}) },
      admin: { ...defaultPortfolioData.admin, ...(parsed.admin || {}) },
      skills: Array.isArray(parsed.skills) && parsed.skills.length > 0 ? parsed.skills : defaultPortfolioData.skills,
      projects: Array.isArray(parsed.projects) && parsed.projects.length > 0 ? parsed.projects : defaultPortfolioData.projects,
      process: Array.isArray(parsed.process) && parsed.process.length > 0 ? parsed.process : defaultPortfolioData.process,
      testimonials: Array.isArray(parsed.testimonials) && parsed.testimonials.length > 0 ? parsed.testimonials : defaultPortfolioData.testimonials,
      stats: Array.isArray(parsed.stats) && parsed.stats.length > 0 ? parsed.stats : defaultPortfolioData.stats,
      messages: Array.isArray(parsed.messages) ? parsed.messages : [],
    };
  } catch {
    return defaultPortfolioData;
  }
}

export function savePortfolioData(data: PortfolioData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (err) {
    console.error("Failed to save portfolio data", err);
  }
}

export function resetPortfolioData(): PortfolioData {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (err) {
    console.error("Failed to reset portfolio data", err);
  }
  return defaultPortfolioData;
}
