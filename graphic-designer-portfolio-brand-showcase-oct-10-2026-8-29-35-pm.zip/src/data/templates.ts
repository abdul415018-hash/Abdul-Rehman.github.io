export interface ServiceOffer {
  badge: string;
  title: string;
  discountText: string;
  validityText?: string;
  description: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  shortDesc: string;
  category: string; // 'branding' | 'packaging' | 'social' | 'print' | 'logo'
  standardPrice: string;
  standardDays: string;
  expressPrice: string;
  expressDays: string;
  revisions: string;
  deliverablesCount: string;
  features: string[];
  isPopular?: boolean;
  specialOffer?: ServiceOffer;
}

export interface ServicesConfig {
  sectionTitle: string;
  sectionSubtitle: string;
  whatsappNumber: string;
  promoBannerEnabled?: boolean;
  promoBannerText?: string;
}

export interface TemplateMotionConfig {
  enabled: boolean;
  showGarland: boolean;
  showFloatingMotif: boolean;
  showParticles: boolean;
  speed: 'slow' | 'normal' | 'fast';
}

export interface TemplateTheme {
  id: string;
  name: string;
  category: 'National Festival' | 'Islamic Celebration' | 'Editorial & Luxury' | 'Neo-Brutalist' | 'Spatial Cyber' | 'Modern Minimalist' | 'Corporate Standard';
  badge: string;
  tagline: string;
  description: string;
  themeClass: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  bgCanvasDark: string;
  bgCanvasLight: string;
  cardBgDark: string;
  cardBorderDark: string;
  fontDisplay: string;
  motionType: 'independence' | 'eid-adha' | 'eid-fitr' | 'ramadan' | 'luxury-gold' | 'bauhaus' | 'cyber' | 'swiss' | 'executive';
  previewSwatches: string[];
}

export type TemplateDefinition = TemplateTheme;

export const TEMPLATES: TemplateTheme[] = [
  {
    id: 'independence-day',
    name: 'Pakistan Independence Day',
    category: 'National Festival',
    badge: '14 August Edition',
    tagline: 'Deep Crescent Emerald, Crisp Pearl White & National Glory',
    description: 'Transforms the entire site into celebratory deep Pakistan green (#00401A) and pristine white, featuring hanging bunting garlands swaying across the top, an animated waving national flag badge, and glowing crescent particles.',
    themeClass: 'theme-independence-day',
    primaryColor: '#059669',
    secondaryColor: '#10b981',
    accentColor: '#34d399',
    bgCanvasDark: '#022413',
    bgCanvasLight: '#f0fdf4',
    cardBgDark: 'rgba(3, 41, 23, 0.78)',
    cardBorderDark: 'rgba(16, 185, 129, 0.35)',
    fontDisplay: "'Plus Jakarta Sans', sans-serif",
    motionType: 'independence',
    previewSwatches: ['#00401a', '#059669', '#10b981', '#ffffff']
  },
  {
    id: 'eid-ul-adha',
    name: 'Eid ul-Adha',
    category: 'Islamic Celebration',
    badge: 'Bari Eid Edition',
    tagline: 'Royal Forest Jade, Antique Bronze Gold & Sacred Radiance',
    description: 'Imbues the whole portfolio with rich royal emerald, antique bronze, and warm amber gold tones. Features ornate brass and emerald lanterns (Fanoos) swinging gently from the top and sacred floating geometric starbursts.',
    themeClass: 'theme-eid-ul-adha',
    primaryColor: '#d97706',
    secondaryColor: '#f59e0b',
    accentColor: '#fbbf24',
    bgCanvasDark: '#071f16',
    bgCanvasLight: '#fefce8',
    cardBgDark: 'rgba(8, 38, 28, 0.82)',
    cardBorderDark: 'rgba(245, 158, 11, 0.35)',
    fontDisplay: "'Plus Jakarta Sans', sans-serif",
    motionType: 'eid-adha',
    previewSwatches: ['#064e3b', '#d97706', '#f59e0b', '#fef3c7']
  },
  {
    id: 'eid-ul-fitr',
    name: 'Eid ul-Fitr',
    category: 'Islamic Celebration',
    badge: 'Meethi Eid Edition',
    tagline: 'Luminous Midnight Turquoise, Champagne Gold & Moon Radiance',
    description: 'Bathes the portfolio in majestic deep turquoise and midnight navy with warm champagne gold accents. Features an illuminated crescent moon with stardust trails, celestial hanging lanterns, and gentle festive particle bursts.',
    themeClass: 'theme-eid-ul-fitr',
    primaryColor: '#0d9488',
    secondaryColor: '#2dd4bf',
    accentColor: '#facc15',
    bgCanvasDark: '#04222a',
    bgCanvasLight: '#f0fdfa',
    cardBgDark: 'rgba(6, 42, 51, 0.8)',
    cardBorderDark: 'rgba(45, 212, 191, 0.35)',
    fontDisplay: "'Plus Jakarta Sans', sans-serif",
    motionType: 'eid-fitr',
    previewSwatches: ['#0f766e', '#2dd4bf', '#facc15', '#e0f2fe']
  },
  {
    id: 'ramadan-mubarak',
    name: 'Ramadan Mubarak',
    category: 'Islamic Celebration',
    badge: 'Holy Month Edition',
    tagline: 'Twilight Sapphire, Spiritual Amber & Glowing Fanous Lanterns',
    description: 'Infuses serene twilight sapphire and glowing golden amber. Features traditional staggered hanging Ramadan Fanous lamps with soft rope physics, warm pulsating light hearts, and an elegant rotating Islamic arabesque background lattice.',
    themeClass: 'theme-ramadan-mubarak',
    primaryColor: '#6366f1',
    secondaryColor: '#fbbf24',
    accentColor: '#f59e0b',
    bgCanvasDark: '#080c1d',
    bgCanvasLight: '#f8fafc',
    cardBgDark: 'rgba(15, 20, 48, 0.82)',
    cardBorderDark: 'rgba(251, 191, 36, 0.35)',
    fontDisplay: "'Plus Jakarta Sans', sans-serif",
    motionType: 'ramadan',
    previewSwatches: ['#1e1b4b', '#6366f1', '#fbbf24', '#fef3c7']
  },
  {
    id: 'luxury-gold',
    name: 'Luxury Gold Editorial',
    category: 'Editorial & Luxury',
    badge: 'Haute Couture Monograph',
    tagline: 'Deep Obsidian Velvet, Luminous Champagne Gold & Haute Typography',
    description: 'Museum-grade editorial elegance with deep obsidian velvet canvas, bright champagne typography, luminous 1px gold borders, radiant ivory highlights, and drifting gold leaf bokeh shimmer.',
    themeClass: 'theme-luxury-gold',
    primaryColor: '#f59e0b',
    secondaryColor: '#fde68a',
    accentColor: '#d4af37',
    bgCanvasDark: '#08080a',
    bgCanvasLight: '#fafaf9',
    cardBgDark: 'rgba(18, 17, 16, 0.94)',
    cardBorderDark: 'rgba(212, 175, 55, 0.45)',
    fontDisplay: "'Playfair Display', Georgia, serif",
    motionType: 'luxury-gold',
    previewSwatches: ['#08080a', '#d4af37', '#fde68a', '#1c1917']
  },
  {
    id: 'bauhaus-brutalist',
    name: 'Bold Bauhaus Neo-Brutalist',
    category: 'Neo-Brutalist',
    badge: 'Constructivist Studio',
    tagline: 'Clean Off-White Canvas, Heavy Black Borders & Cadmium Accents',
    description: 'High-contrast Bauhaus constructivist aesthetic with clean warm off-white canvas, razor-sharp 2px solid black borders, hard tactile drop-shadows, cadmium primary colors, and slowly revolving geometric primitives.',
    themeClass: 'theme-bauhaus-brutalist',
    primaryColor: '#facc15',
    secondaryColor: '#2563eb',
    accentColor: '#ef4444',
    bgCanvasDark: '#fbf9f5',
    bgCanvasLight: '#fbf9f5',
    cardBgDark: '#ffffff',
    cardBorderDark: '#000000',
    fontDisplay: "'Space Grotesk', system-ui, sans-serif",
    motionType: 'bauhaus',
    previewSwatches: ['#fbf9f5', '#000000', '#facc15', '#2563eb']
  },
  {
    id: 'cyber-future',
    name: 'Spatial 3D Cyber-Future',
    category: 'Spatial Cyber',
    badge: 'Signature Spatial Edition',
    tagline: 'High-Contrast Neon Glows, Luminous Glass & Laser Depth',
    description: 'Next-gen spatial interface with high-contrast electric cyan and violet neon glows, brightened glass surfaces, pure white crisp typography, and kinetic perspective grid scanning beams.',
    themeClass: 'theme-cyber-future',
    primaryColor: '#06b6d4',
    secondaryColor: '#c084fc',
    accentColor: '#38bdf8',
    bgCanvasDark: '#050814',
    bgCanvasLight: '#eef2f6',
    cardBgDark: 'rgba(13, 22, 46, 0.88)',
    cardBorderDark: 'rgba(6, 182, 212, 0.45)',
    fontDisplay: "'Plus Jakarta Sans', sans-serif",
    motionType: 'cyber',
    previewSwatches: ['#050814', '#06b6d4', '#c084fc', '#38bdf8']
  },
  {
    id: 'swiss-international',
    name: 'Swiss International Studio',
    category: 'Modern Minimalist',
    badge: 'International Modernist Edition',
    tagline: 'Modernist Grid Precision, Pure Monochrome & Klein Cobalt Accents',
    description: 'World-renowned Zurich & Basel modernist studio standard. Ultra-crisp off-white canvas, sharp ink-black typography, mathematical grid borders, vibrant Klein cobalt and crimson accents, and animated precision micro-coordinate guidelines.',
    themeClass: 'theme-swiss-international',
    primaryColor: '#2563eb',
    secondaryColor: '#dc2626',
    accentColor: '#0284c7',
    bgCanvasDark: '#f8fafc',
    bgCanvasLight: '#f8fafc',
    cardBgDark: '#ffffff',
    cardBorderDark: '#e2e8f0',
    fontDisplay: "'Inter', system-ui, sans-serif",
    motionType: 'swiss',
    previewSwatches: ['#f8fafc', '#09090b', '#2563eb', '#dc2626']
  },
  {
    id: 'executive-slate',
    name: 'Executive Slate Minimal',
    category: 'Corporate Standard',
    badge: 'Executive Architectural Edition',
    tagline: 'Deep Obsidian Slate, Titanium White & Precision Steel Glow',
    description: 'High-echelon corporate agency aesthetic designed for top-tier digital studios and international consulting. Deep obsidian slate backdrop, titanium white typography, cool steel borders, and subtle cyan-indigo ambient lighting.',
    themeClass: 'theme-executive-slate',
    primaryColor: '#38bdf8',
    secondaryColor: '#818cf8',
    accentColor: '#0ea5e9',
    bgCanvasDark: '#0b0f17',
    bgCanvasLight: '#f1f5f9',
    cardBgDark: 'rgba(15, 23, 42, 0.90)',
    cardBorderDark: 'rgba(51, 65, 85, 0.75)',
    fontDisplay: "'Plus Jakarta Sans', system-ui, sans-serif",
    motionType: 'executive',
    previewSwatches: ['#0b0f17', '#f8fafc', '#38bdf8', '#818cf8']
  }
];

export const defaultMotionConfig: TemplateMotionConfig = {
  enabled: true,
  showGarland: true,
  showFloatingMotif: true,
  showParticles: true,
  speed: 'normal'
};

export const defaultServices: ServiceItem[] = [
  {
    id: 'srv-1',
    title: 'Brand Identity & Logo Suite',
    shortDesc: 'Mathematical vector logos, golden-ratio geometry, master color guidelines, and full corporate typography.',
    category: 'branding',
    standardPrice: 'Rs 15,000 / $65',
    standardDays: '3 Days',
    expressPrice: 'Rs 22,000 / $95',
    expressDays: '24 Hours',
    revisions: 'Unlimited Revisions',
    deliverablesCount: '5 Logo Concepts + Brand Manual',
    features: [
      '5 Initial Unique Concepts',
      'AI, EPS, SVG, PDF & Transparent PNG',
      'Full Vector Golden Ratio Geometry',
      'Primary, Secondary & Monogram Variations',
      'Color Palette (CMYK, RGB, HEX, Pantone)',
      'Typography Selection & Font Pairing',
      '3D Realistic Stationery Mockups',
      'Full Commercial Copyrights Handover'
    ],
    isPopular: true,
    specialOffer: {
      badge: 'Bestseller Bundle',
      title: 'Free Business Card + Letterhead Design',
      discountText: 'Complimentary Inclusion',
      validityText: 'Active Package',
      description: 'Includes complete print-ready corporate stationery templates with initial delivery.'
    }
  },
  {
    id: 'srv-2',
    title: 'Packaging & Die-Line CAD',
    shortDesc: 'Production-ready structural packaging, box die-lines, cosmetic jars, pouch designs, and CMYK prepress calibration.',
    category: 'packaging',
    standardPrice: 'Rs 20,000 / $85',
    standardDays: '4 Days',
    expressPrice: 'Rs 28,000 / $120',
    expressDays: '48 Hours',
    revisions: '5 Rounds Revisions',
    deliverablesCount: '1 Full Packaging Unit + Dieline',
    features: [
      '100% Accurate Factory Die-Line CAD',
      'Bleed, Margin, Crease & Fold Lines',
      'CMYK Offset & Flexo Prepress Specs',
      'Spot UV, Foil Stamping & Emboss Plates',
      'Hyper-Realistic 3D Bottle / Box Mockup',
      'Nutritional / Barcode Spec Integration',
      'Print-Ready 300+ DPI Vector PDF'
    ],
    isPopular: false
  },
  {
    id: 'srv-3',
    title: 'Social Media & Marketing Graphics',
    shortDesc: 'High-conversion carousel posts, promotional banners, Instagram story templates, and campaign creatives.',
    category: 'social',
    standardPrice: 'Rs 12,000 / $50',
    standardDays: '2 Days',
    expressPrice: 'Rs 18,000 / $75',
    expressDays: '1 Day',
    revisions: '4 Rounds Revisions',
    deliverablesCount: '10 High-Impact Creatives',
    features: [
      '10 Custom Social Media Posts / Banners',
      'Optimized for Instagram, Facebook, LinkedIn',
      'Source PSD / Illustrator / Canva Files',
      'Engaging Visual Hooks & Modern Aesthetics',
      'Campaign Themed Color Variations',
      'Exported in High Resolution PNG/JPG'
    ],
    isPopular: false
  },
  {
    id: 'srv-4',
    title: 'Corporate Stationery & Print Collateral',
    shortDesc: 'Business cards, letterheads, presentation folders, corporate brochures, and luxury foil-stamped certificates.',
    category: 'print',
    standardPrice: 'Rs 10,000 / $45',
    standardDays: '2 Days',
    expressPrice: 'Rs 15,000 / $65',
    expressDays: '24 Hours',
    revisions: 'Unlimited Revisions',
    deliverablesCount: 'Complete 4-Piece Suite',
    features: [
      'Double-Sided Premium Business Card',
      'Official Letterhead (Word + Vector PDF)',
      'Corporate Envelope (DL + C4)',
      'Presentation Folder / Certificate',
      'Ready for Commercial CMYK Offset Printing',
      'Foil Mask & Spot Gloss layers'
    ],
    isPopular: false
  },
  {
    id: 'srv-5',
    title: 'Company Profile & Editorial Catalog',
    shortDesc: 'Multi-page corporate brochures, annual reports, product catalogs, and investor pitch decks with editorial polish.',
    category: 'print',
    standardPrice: 'Rs 25,000 / $110',
    standardDays: '5 Days',
    expressPrice: 'Rs 35,000 / $150',
    expressDays: '3 Days',
    revisions: '5 Rounds Revisions',
    deliverablesCount: 'Up to 16 Pages',
    features: [
      'Up to 16 Custom Editorial Pages',
      'Adobe InDesign Master Grids & Styles',
      'Infographics & Data Visualization',
      'Interactive Digital PDF with Clickable Links',
      'Print-Ready CMYK Press Quality with Bleeds',
      'Packaged InDesign & PDF Source Archive'
    ],
    isPopular: false
  },
  {
    id: 'srv-6',
    title: 'Vector Artwork & Redraw Mastery',
    shortDesc: 'Low-res bitmap image tracing to crisp infinitely scalable vector files, logo revamps, and technical illustrations.',
    category: 'logo',
    standardPrice: 'Rs 5,000 / $25',
    standardDays: '1 Day',
    expressPrice: 'Rs 8,000 / $38',
    expressDays: '12 Hours',
    revisions: 'Unlimited Revisions',
    deliverablesCount: 'Single Vector Conversion',
    features: [
      '100% Manual Hand-Drawn Vector Bezier Curves',
      'No Automatic Tracing Artifacts or Blur',
      'Infinitely Scalable to Billboard Sizes',
      'AI, EPS, SVG, PDF, High-Res PNG Handover',
      'Color Separation for Screen Printing'
    ],
    isPopular: false
  }
];

export const defaultServicesConfig: ServicesConfig = {
  sectionTitle: 'Design Services & Packages',
  sectionSubtitle: 'Transparent pricing, guaranteed delivery timelines, rapid rush delivery, and custom graphic design solutions.',
  whatsappNumber: '+923101234567',
  promoBannerEnabled: false,
  promoBannerText: 'Welcome! Explore packages below or connect directly on WhatsApp for custom inquiries.'
};
