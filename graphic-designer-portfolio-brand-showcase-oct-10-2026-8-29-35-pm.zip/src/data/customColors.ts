export interface SectionColorConfig {
  headingColor: string;
  textColor: string;
  bgColor: string;
  cardBgColor: string;
  accentColor: string;
  borderColor: string;
}

export interface GlobalColorConfig {
  headingColor: string;
  textColor: string;
  bgColor: string;
  cardBgColor: string;
  accentColor: string;
  borderColor: string;
}

export interface SiteColorCustomization {
  enabled: boolean;
  global: GlobalColorConfig;
  sections: {
    hero: Partial<SectionColorConfig>;
    services: Partial<SectionColorConfig>;
    projects: Partial<SectionColorConfig>;
    about: Partial<SectionColorConfig>;
    process: Partial<SectionColorConfig>;
    testimonials: Partial<SectionColorConfig>;
    contact: Partial<SectionColorConfig>;
  };
}

export const defaultColorCustomization: SiteColorCustomization = {
  enabled: false,
  global: {
    headingColor: '',
    textColor: '',
    bgColor: '',
    cardBgColor: '',
    accentColor: '',
    borderColor: '',
  },
  sections: {
    hero: {},
    services: {},
    projects: {},
    about: {},
    process: {},
    testimonials: {},
    contact: {},
  },
};

export interface ColorPreset {
  id: string;
  name: string;
  badge: string;
  global: GlobalColorConfig;
  preview: string[];
}

export const CURATED_COLOR_PRESETS: ColorPreset[] = [
  {
    id: 'swiss-mono',
    name: 'Swiss Monochrome Minimal',
    badge: 'Ultra High-Contrast',
    global: {
      headingColor: '#09090b',
      textColor: '#334155',
      bgColor: '#f8fafc',
      cardBgColor: '#ffffff',
      accentColor: '#2563eb',
      borderColor: '#e2e8f0',
    },
    preview: ['#f8fafc', '#09090b', '#2563eb', '#e2e8f0'],
  },
  {
    id: 'executive-titanium',
    name: 'Executive Slate & Titanium',
    badge: 'Corporate Standard',
    global: {
      headingColor: '#ffffff',
      textColor: '#94a3b8',
      bgColor: '#0b0f17',
      cardBgColor: '#0f172a',
      accentColor: '#38bdf8',
      borderColor: '#1e293b',
    },
    preview: ['#0b0f17', '#ffffff', '#38bdf8', '#1e293b'],
  },
  {
    id: 'emerald-luxe',
    name: 'Emerald & Champagne Gold',
    badge: 'Luxury Editorial',
    global: {
      headingColor: '#fefce8',
      textColor: '#d4d4d8',
      bgColor: '#022413',
      cardBgColor: '#064e3b',
      accentColor: '#fbbf24',
      borderColor: '#047857',
    },
    preview: ['#022413', '#fefce8', '#fbbf24', '#047857'],
  },
  {
    id: 'cyber-electric',
    name: 'Cyber Electric Neon',
    badge: 'Spatial Glow',
    global: {
      headingColor: '#ffffff',
      textColor: '#a5f3fc',
      bgColor: '#050814',
      cardBgColor: '#0c142b',
      accentColor: '#06b6d4',
      borderColor: '#1e3a8a',
    },
    preview: ['#050814', '#ffffff', '#06b6d4', '#c084fc'],
  },
  {
    id: 'warm-terracotta',
    name: 'Warm Terracotta Editorial',
    badge: 'Artisan Studio',
    global: {
      headingColor: '#1c1917',
      textColor: '#44403c',
      bgColor: '#fafaf9',
      cardBgColor: '#ffffff',
      accentColor: '#ea580c',
      borderColor: '#e7e5e4',
    },
    preview: ['#fafaf9', '#1c1917', '#ea580c', '#e7e5e4'],
  },
];
