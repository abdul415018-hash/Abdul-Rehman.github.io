# Graphic Designer Portfolio & Brand Showcase

A production-grade, responsive Graphic Designer & Brand Showcase web application built with **React 19**, **Vite**, **TypeScript**, and **Tailwind CSS**.

Features include:
- 9 switchable theme templates (including **Swiss International Studio**, **Executive Slate Minimal**, **Independence Day**, **Eid Mubarak**, **Luxury Gold**, **Neo-Brutalist**, and **Cyber Future**).
- Dynamic custom color engine with global tokens and per-section granular color overrides.
- Physics-based motion graphics overlays with master toggle and speed/particle controls.
- Comprehensive in-browser Admin Control Panel with JSON export/import and live data customization.
- Before/After interactive case study comparison slider.
- WhatsApp instant project enquiry direct integration.
- Full responsive design and automatic system dark/light mode detection.

---

## 1. Prerequisites (Windows 10 / Windows 11)

- **Node.js**: Version `18.x`, `20.x`, or `22.x` (LTS recommended)
  - Download from: [https://nodejs.org/](https://nodejs.org/)
- **npm**: Included automatically with Node.js (`npm -v`)
- Terminal: **Command Prompt (`cmd`)**, **PowerShell**, or **Windows Terminal**

---

## 2. Quick Start on Windows

Open Command Prompt or PowerShell in the project root directory:

```bat
:: 1. Install dependencies
npm install

:: 2. Start the local development server (runs at http://localhost:3000)
npm run dev

:: 3. Build for production (outputs to dist/)
npm run build

:: 4. Preview the production build locally
npm run preview
```

---

## 3. Cloudflare Pages Deployment Guide

This project is pre-configured and tested for zero-configuration static deployment on **Cloudflare Pages**.

### Deployment Settings in Cloudflare Dashboard:

1. Log in to [Cloudflare Dashboard](https://dash.cloudflare.com/) and go to **Workers & Pages** > **Create application** > **Pages** > **Connect to Git**.
2. Select your repository.
3. Configure the **Build settings**:
   - **Framework preset**: `Vite` (or `None`)
   - **Build command**: `npm run build`
   - **Build output directory**: `dist`
   - **Root directory**: `/` (leave empty or default)
   - **Node.js Version**: `20` (in Environment Variables set `NODE_VERSION=20` if prompted)
4. Click **Save and Deploy**.

### Single-Page Application (SPA) Routing & Refreshes:
- A `public/_redirects` file is included in this repository:
  ```text
  /*    /index.html   200
  ```
- When Cloudflare Pages builds the project, this rule ensures that direct deep links and browser refreshes route to `dist/index.html` with HTTP 200 without 404 errors.

---

## 4. Admin Control Panel & Security Architecture

### How to Access Admin Panel:
- Press `Ctrl + Shift + A` (Windows) or `Cmd + Shift + A` (Mac) anywhere on the page, OR
- Add `#admin` to the URL (e.g., `http://localhost:3000/#admin`).

### Current Authentication & Data Model:
- **Authentication**: Master credential verification stored in browser local storage.
- **Data Persistence**: Uses browser `localStorage` under key `abdul_graphic_portfolio_v7`.
- **Backup & Migration**: The Admin Panel includes **Export JSON** and **Import JSON** buttons to export your customizations as a file or restore them on any machine.
- **Production Public Notice**: Raw master passwords have been removed from the public UI.

### Production Backend Requirements (For Multi-Device Shared Storage):
If you require administrative edits made on one device to instantly sync across all public visitors without re-deploying or exporting JSON:
1. **Database & API**: Connect a database (e.g., Cloudflare D1, Supabase, Firebase Firestore, or PostgreSQL).
2. **Server-Side Authentication**: Implement secure JWT/session authentication with bcrypt password hashing via Cloudflare Pages Functions (`/functions/api/*`) or a dedicated Node.js backend.
3. **Protected Endpoints**: Move `savePortfolioData` to a server endpoint requiring an `Authorization: Bearer <token>` header.

---

## 5. API Keys & AI Security Best Practices

- **Zero Client-Side Secrets**: There are no private API keys embedded in client bundles.
- **Environment Variables**: Vite variables (`VITE_*`) are embedded into public JavaScript bundles during `npm run build`. Never put secret keys in `VITE_*` variables.
- **AI Server Proxy**: If enabling server-side Gemini AI generation in production, proxy calls through server-side functions (e.g. `/api/generate`) with `GEMINI_API_KEY` stored exclusively in Cloudflare Pages Environment Variables / Secrets.

---

## 6. Project Verification Summary

- **TypeScript Compilation**: `tsc --noEmit` passed (0 errors).
- **Vite Production Build**: `vite build` completed successfully, creating `dist/` with `dist/index.html`, `dist/assets/`, and `dist/_redirects`.
- **Assets**: High-resolution image assets mapped into both `/assets/images/` and `/src/assets/images/` inside `public/` for cross-environment resolution.
