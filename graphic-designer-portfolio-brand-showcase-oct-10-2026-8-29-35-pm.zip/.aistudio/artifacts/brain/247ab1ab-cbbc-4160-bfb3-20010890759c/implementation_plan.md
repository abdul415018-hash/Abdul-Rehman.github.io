# Implementation Plan: 2 International Standard Templates, Granular Admin Color Customizer & Final Production Hardening

## Overview
This plan fulfills the user's requirements:
1. **Two New International Standard Everyday Templates:**
   - **Swiss International Studio:** Clean, modernist grid aesthetic inspired by Helvetica typography, stark contrast, subtle geometric lines, monochromatic poise with vibrant cobalt/crimson accents, and subtle micro-rule animations suitable for world-class design agencies.
   - **Executive Slate Minimal:** Ultra-refined corporate minimalist aesthetic featuring slate charcoals, titanium whites, cool steel accents, subtle ambient glows, and clean executive cards suitable for high-end digital studios and consultants.
2. **Dual Global & Granular Per-Section Color Engine in Admin Control Panel:**
   - **Global Palette Overrides:** Master primary text, secondary text, canvas background, surface background, accent color, and border color.
   - **Section-by-Section Color Customizer:** Dedicated controls for each section (**Hero**, **Services & Packages**, **Selected Work / Portfolio**, **Agency Expertise & About**, **Work Process**, **Testimonials & Stats**, **Contact & Inquiry**).
   - Real-time live reflection in the website DOM via CSS variable bindings and custom style overrides.
   - 1-Click reset per section and master reset to template defaults.
   - Color picker inputs with HEX text display and quick-pick curated swatch presets.
3. **Full Site Audit & Production Finalization:**
   - Audit all sections, buttons, WhatsApp booking modals, template switcher cards, motion overlays, and forms.
   - Ensure strictly 100% English on all frontend website elements (with no placeholder or unintended Urdu copy on public UI).
   - Eliminate contrast flaws, missing styles, and any broken layout behaviors.
   - Clean compilation, lint check, and verify flawless responsiveness across mobile, tablet, and desktop viewports.

---

## User Review Required

> [!IMPORTANT]
> - Total templates will now be **9 distinct templates** (Independence Day, Eid Ul Fitr, Eid Ul Adha, Ramadan Kareem, Luxury Gold Editorial, Bold Bauhaus Neo-Brutalist, Spatial Cyber-Future, **Swiss International Studio**, and **Executive Slate Minimal**).
> - All color customizer settings in the Admin Panel will persist in browser `localStorage` and seamlessly overlay the active template's base styling.
> - Clicking "Reset to Template Defaults" will safely clear any custom overrides and return to the active template's designed aesthetic.

---

## Detailed Step-by-Step Plan

### Phase 1: Two International Everyday Templates Setup
1. **Update `src/data/templates.ts`:**
   - Define `swiss-international`:
     - Accent: `#2563eb` (International Blue)
     - Canvas: `#f8fafc` (Ultra-crisp Swiss matte paper)
     - Text Primary: `#09090b` (Deep ink black)
     - Text Secondary: `#475569` (Charcoal)
     - Typography: Clean modernist sans-serif
     - Tagline: "Modernist Grid Precision, Helvetica Poise & High-Contrast Editorial Balance"
   - Define `executive-slate`:
     - Accent: `#38bdf8` / `#6366f1` (Executive Cyan / Indigo glow)
     - Canvas: `#0b0f17` (Deep obsidian slate)
     - Text Primary: `#f8fafc` (Titanium white)
     - Text Secondary: `#94a3b8` (Cool steel gray)
     - Typography: Sleek contemporary grotesque
     - Tagline: "Refined Corporate Minimal, Executive Titanium & Polished Slate Architecture"
2. **Create Motion Overlays:**
   - `src/components/motion/SwissStudioOverlay.tsx`: Elegant subtle animated Swiss grid guidelines and micro coordinate markers with zero-clutter elegance.
   - `src/components/motion/ExecutiveSlateOverlay.tsx`: Refined ambient gradient pulses and high-tech hairline divider shimmer.
3. **Wire Overlays into `TemplateMotionEngine.tsx`:**
   - Connect the two new templates to render their respective overlays smoothly with admin toggle support.

### Phase 2: CSS Styling & Variable Architecture
1. **Extend `src/index.css`:**
   - Implement `.theme-swiss-international` with pure black/white crisp typography, sharp border lines, elegant card shadows, and flawless badge treatments.
   - Implement `.theme-executive-slate` with luminous dark card surfaces, crisp slate typography, subtle glass borders, and high-contrast buttons.
   - Ensure complete immunity to text-contrast degradation across all sections.

### Phase 3: Comprehensive Dual Global & Per-Section Color Engine
1. **Data Model (`src/types/customization.ts` or `src/data/templates.ts`):**
   - Create `SiteColorOverrides` type structure supporting:
     - `global`: `{ textPrimary, textSecondary, bgCanvas, bgCard, accentColor, borderColor }`
     - `sections`: `{ [sectionId]: { headingColor, textColor, bgColor, cardBgColor, accentColor, borderColor } }`
     - Supported sections: `hero`, `services`, `portfolio`, `expertise`, `process`, `testimonials`, `contact`.
2. **Dynamic Style Injector / Context (`src/context/CustomizationContext.tsx` or dynamic CSS vars):**
   - Apply CSS variables dynamically to the document root and specific section container elements via data attributes or inline CSS variable mapping.
3. **Admin Control Panel UI (`src/components/admin/AdminDashboard.tsx`):**
   - Add a dedicated **"Color Studio & Styling"** tab or section in the Admin Panel:
     - **Global Color Master:** Quick pickers for primary text, secondary text, background, cards, and accent buttons.
     - **Section-by-Section Accordion/Cards:** Granular controls for each individual section.
     - **Live Swatches:** Hex input + visual color picker + one-click reset for each element.
     - **Preset Themes:** Quick one-click palette presets (e.g. Monochrome, Emerald Luxe, Midnight Electric, Warm Terracotta, Pure High-Contrast).
     - **Master Reset Button:** Reverts all color modifications back to the default active template.

### Phase 4: Full Codebase Audit & Production Polish
1. **Audit All Sections & Components:**
   - Check `Navbar`, `Hero`, `ServicesSection`, `SelectedWork`, `AboutAndExpertise`, `WorkProcess`, `TestimonialsAndNumbers`, `ContactFooter`, `AdminDashboard`.
   - Verify WhatsApp order popups have valid encoding and responsive modals.
   - Confirm all text across public pages is professional English without broken fragments or untranslated tokens.
   - Verify responsiveness on mobile screens (avoid overflow-x, text overlaps, or unreadable buttons).
2. **Build and Quality Assurance:**
   - Run `lint_applet` and `compile_applet`.
   - Verify zero console errors, zero build failures, and fast load times.

---

## Verification Plan
1. **Template Switcher Verification:**
   - Open Admin Panel -> Template Switcher.
   - Verify all 9 templates appear with high-contrast cards, badges, and instant 1-click live preview.
   - Switch to **Swiss International Studio** -> Verify crisp off-white canvas, ink-black text, precision grid overlay.
   - Switch to **Executive Slate Minimal** -> Verify deep obsidian slate, titanium text, refined executive styling.
2. **Admin Color Customizer Verification:**
   - Open Admin Panel -> Color Studio.
   - Modify Global Accent Color -> Verify all primary CTA buttons immediately update color.
   - Modify Hero Heading Color -> Verify Hero headline updates instantly without affecting other sections.
   - Modify Services Card Background -> Verify service pricing cards reflect new background.
   - Test "Reset Section" and "Reset All to Defaults" -> Verify colors restore cleanly.
3. **Audit Verification:**
   - Check mobile layout on narrow viewports.
   - Confirm WhatsApp order button opens correct prefilled WhatsApp link.
   - Run compilation and lint tests to ensure 100% production pass.
